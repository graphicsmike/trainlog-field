"""Find and fix odd data: the trains behind a Dashboard row, Find and Replace
in one field, and a Data Check that lists sightings that look wrong."""
from __future__ import annotations

import re
from datetime import date as _date, datetime, timedelta
from typing import Any, Callable, Dict, List, Optional, Tuple

import analytics
import catalog as cat
from models import DIRECTIONS, types_to_storage
from train_types import canonicalize_train_types
from reference import reference_text, symbol_stats_parts
from special_power import POSITIONS, consist_unit_list, normalize_special_power, steam_run_label, steam_runs
from states import normalize_state
from validators import (
    ValidationError,
    _CAR_COUNTS_RE,
    normalize_car_counts,
    normalize_consist,
    normalize_loco_number,
    normalize_railroad,
    normalize_symbol,
    normalize_train_number,
)


def _t(entry: Any, field: str) -> str:
    return (getattr(entry, field, None) or "").strip()


def _symbol_parts(entry: Any) -> Optional[Dict[str, Any]]:
    symbol = _t(entry, "train_symbol").upper()
    if not symbol:
        return None
    return symbol_stats_parts(_t(entry, "railroad"), symbol)


def _sym(key: str) -> Callable[[Any], List[str]]:
    def labels(entry: Any) -> List[str]:
        parts = _symbol_parts(entry)
        return [parts[key]] if parts and parts[key] else []
    return labels


def _lane(entry: Any) -> List[str]:
    parts = _symbol_parts(entry)
    if parts and parts["origin"] and parts["destination"]:
        return ["{} → {}".format(parts["origin"], parts["destination"])]
    return []


def _railroad(entry: Any) -> List[str]:
    return [_t(entry, "railroad") or "Unknown"]


def _symbol_road(entry: Any) -> List[str]:
    return _railroad(entry) if _t(entry, "train_symbol") else []


def _heritage(entry: Any) -> List[Dict[str, Any]]:
    return normalize_special_power(getattr(entry, "special_power", None) or "")["heritage"]


def _steam(entry: Any) -> List[Dict[str, Any]]:
    return normalize_special_power(getattr(entry, "special_power", None) or "")["steam"]


def _heritage_unit(item: Dict[str, Any]) -> str:
    unit = item["unit"] or "Unit not given"
    return "{} · {}".format(unit, item["scheme"]) if item["unit"] and item["scheme"] else unit


def _passenger(entry: Any) -> List[str]:
    number = _t(entry, "train_number").upper()
    if not number:
        return []
    rr = _t(entry, "railroad")
    return ["{} #{}".format(rr, number) if rr else "#" + number]


def _loads(entry: Any) -> List[str]:
    return cat._cmp_loads(entry, {}) or ["Unknown"]


def _media(entry: Any) -> List[str]:
    photo = bool(getattr(entry, "photographed", False))
    video = bool(getattr(entry, "videoed", False))
    out = []
    if photo:
        out.append("Photo")
    if video:
        out.append("Video")
    if photo and video:
        out.append("Photo and video")
    if getattr(entry, "night", False):
        out.append("Night")
    if _t(entry, "notes"):
        out.append("Notes")
    return out


def _cmp(fn: Callable[[Any, Dict[str, Any]], List[str]]) -> Callable[[Any], List[str]]:
    return lambda entry: fn(entry, {})


DRILL_SOURCES: Dict[str, Callable[[Any], List[str]]] = {
    "types": lambda e: [cat._type_label(list(getattr(e, "train_types", None) or []))],
    "railroads": _railroad,
    "roadcards": _railroad,
    "directions": lambda e: [d for d in [cat._direction_label(_t(e, "direction"))] if d in DIRECTIONS],
    "cars": _cmp(cat._cmp_cars),
    "passenger": _passenger,
    "symbols": _sym("base"),
    "symbolseries": _sym("series"),
    "symbollanes": _lane,
    "symbolorigins": _sym("origin"),
    "symboldests": _sym("destination"),
    "symbolroads": _symbol_road,
    "symbolcheck": _sym("check"),
    "heritageunits": lambda e: [_heritage_unit(i) for i in _heritage(e)],
    "heritageschemes": lambda e: [i["scheme"] or "Scheme not given" for i in _heritage(e)],
    "heritageeras": lambda e: ["America 250" for i in _heritage(e) if i["era"] == "a250"],
    "heritagepositions": lambda e: [POSITIONS.get(i["position"], "Position not given") for i in _heritage(e)],
    "heritageroads": lambda e: [i["unit"].split(" ")[0] for i in _heritage(e) if i["unit"]],
    "steamengines": lambda e: [" ".join(p for p in (i["engine"], i["name"]) if p) or "Engine not given" for i in _steam(e)],
    "steamwheels": lambda e: [i["wheels"] or "Not given" for i in _steam(e)],
    "steamstates": lambda e: [_t(e, "location_state").upper()] if _steam(e) and _t(e, "location_state") else [],
    "steamruns": lambda e: [steam_run_label(run) for run in steam_runs(_steam(e))],
    "assistdiesels": lambda e: [unit for run in steam_runs(_steam(e)) for unit in run[0].get("assist") or []],
    "consistunits": lambda e: consist_unit_list(normalize_special_power(getattr(e, "special_power", None) or "")),
    "loads": _loads,
    "locations": lambda e: [_t(e, "location_spot") or "Unknown"],
    "subdivisions": lambda e: cat._one(_t(e, "location_subdivision")),
    "states": lambda e: cat._one(_t(e, "location_state").upper()),
    "zones": lambda e: [cat._zone_label(_t(e, "time_zone"))],
    "trips": lambda e: cat._one(_t(e, "trip_name")),
    "hours": _cmp(cat._cmp_hour),
    "dayparts": _cmp(cat._cmp_part),
    "ampm": lambda e: cat._one(cat._ampm(_t(e, "time"))),
    "weekdays": _cmp(cat._cmp_weekday),
    "months": _cmp(cat._cmp_month),
    "seasons": _cmp(cat._cmp_season),
    "years": lambda e: cat._one(_t(e, "date")[:4]),
    "busiest": lambda e: cat._one(_t(e, "date")),
    "leads": lambda e: cat._one(cat._lead_value(e)),
    "leadrepeats": lambda e: [_t(e, "lead_locomotive").upper()] if re.search(r"\d", _t(e, "lead_locomotive")) else [],
    "consists": lambda e: cat._one(_t(e, "power_consist")),
    "units": _cmp(cat._cmp_units),
    "dp": _cmp(cat._cmp_dp),
    "leadpower": _cmp(cat._cmp_lead_power),
    "leadmarks": lambda e: cat._one(cat._lead_mark(_t(e, "lead_locomotive"))),
    "media": _media,
    "rrgroup": lambda e: [cat._rr_group(_railroad(e)[0])],
    "rrregion": lambda e: [cat._lib_field(e, "region")],
    "rroperation": lambda e: [cat._lib_field(e, "operation")],
    "contrade": cat._con_trade,
    "leadstatus": lambda e: cat._one((getattr(e, "lead_status", "") or "").strip()),
    "trainstatus": cat._train_status,
    "dates": lambda e: cat._one(_t(e, "date")),
    "monthline": lambda e: cat._one(analytics.month_label(_t(e, "date"))),
}

LOG_WIDE_SOURCES: Dict[str, Callable[[List[Any]], Dict[int, str]]] = {
    "waits": analytics.gap_labels,
    "newleads": analytics.first_leads,
    "meets": analytics.meet_labels,
}


def drill(entries: List[Any], source: str, value: str, type_railroad: str = "") -> List[Any]:
    """The trains counted in one row of a Dashboard card, using the same labels the card shows."""
    if source in LOG_WIDE_SOURCES:
        by_id = LOG_WIDE_SOURCES[source](entries)
        return [entry for entry in entries if by_id.get(int(getattr(entry, "id", 0) or 0)) == value]
    if source == "rrclass":
        classes = cat.rr_mod.railroad_classes()
        return [entry for entry in entries if cat._rr_class(_railroad(entry)[0], classes) == value]
    labels = DRILL_SOURCES.get(source)
    if labels is None:
        raise ValueError("That card can't list its trains.")
    rr = (type_railroad or "").strip()
    return [
        entry
        for entry in entries
        if value in labels(entry) and (source != "types" or not rr or (_t(entry, "railroad") or "Unknown") == rr)
    ]


FIX_FIELDS: List[Dict[str, str]] = [
    {"key": "lead_locomotive", "label": "Lead Loco"},
    {"key": "power_consist", "label": "Consist"},
    {"key": "car_counts", "label": "Cars"},
    {"key": "train_types", "label": "Train Type"},
    {"key": "railroad", "label": "Railroad"},
    {"key": "train_symbol", "label": "Symbol"},
    {"key": "train_number", "label": "Train #"},
    {"key": "location_spot", "label": "Location"},
    {"key": "location_subdivision", "label": "Subdivision"},
    {"key": "location_state", "label": "State"},
]
FIX_KEYS = {item["key"]: item["label"] for item in FIX_FIELDS}
REQUIRED = {"railroad": "Railroad", "location_spot": "Location", "train_types": "Train Type"}


def _entry_types(entry: Any) -> List[str]:
    types = entry.get("train_types") if isinstance(entry, dict) else getattr(entry, "train_types", None)
    return [str(t).strip() for t in (types or []) if str(t).strip()]


def entry_values(entry: Any, field: str) -> List[str]:
    """The values one sighting holds in a field: each train type on its own, else the one text value."""
    if field == "train_types":
        return _entry_types(entry) or [""]
    return [_t(entry, field)]


def field_values(entries: List[Any], field: str) -> List[Dict[str, Any]]:
    """Every distinct value in one field with its train count, blank included."""
    if field not in FIX_KEYS:
        raise ValueError("Pick a field to look at.")
    counts: Dict[str, int] = {}
    for entry in entries:
        for value in set(entry_values(entry, field)):
            counts[value] = counts.get(value, 0) + 1
    rows = [{"value": k, "trains": v} for k, v in counts.items()]
    rows.sort(key=lambda row: (-row["trains"], row["value"].lower()))
    return rows


def clean_value(field: str, value: Any) -> str:
    """Tidy a replacement value the way the entry form would, or raise ValidationError."""
    if field not in FIX_KEYS:
        raise ValidationError("Pick a field to change", "field")
    text = str(value if value is not None else "").strip()
    if len(text) > 120:
        raise ValidationError("That value is too long", "to")
    if not text and field in REQUIRED:
        raise ValidationError("{} can't be blank".format(REQUIRED[field]), "to")
    if field == "lead_locomotive":
        return normalize_loco_number(text)
    if field == "power_consist":
        out = normalize_consist(text)
        if out and not re.fullmatch(r"\d+(?:x\d+)*", out):
            raise ValidationError("Consist must be numbers joined by x, like 2x1, 3x0, or 4x2x1", "to")
        return out
    if field == "car_counts":
        out = normalize_car_counts(text)
        if out and not _CAR_COUNTS_RE.match(out):
            raise ValidationError("Car counts must be numeric, like 65 or 105/99", "to")
        return out
    if field == "railroad":
        return normalize_railroad(text)
    if field == "train_symbol":
        return normalize_symbol(text)
    if field == "train_number":
        return normalize_train_number(text)
    if field == "location_state":
        out = normalize_state(text)
        if text and not out:
            raise ValidationError("State must be a two-letter code like AZ", "to")
        return out
    if field == "train_types":
        types = canonicalize_train_types([text])
        if not types:
            raise ValidationError("Train Type can't be blank", "to")
        return "/".join(types)
    return text


def replaced_fields(entry: Dict[str, Any], field: str, new: str, old: str = "") -> Dict[str, Any]:
    """The columns to write when one field changes, with Train Info kept in step."""
    if field == "train_types":
        types: List[str] = []
        for value in _entry_types(entry) or [""]:
            for item in new.split("/") if value == old else [value]:
                if item and item not in types:
                    types.append(item)
        return {"train_types": types_to_storage(types)}
    out: Dict[str, Any] = {field: new}
    if field in ("railroad", "train_symbol", "train_number"):
        rr = new if field == "railroad" else entry.get("railroad") or ""
        sym = new if field == "train_symbol" else entry.get("train_symbol") or ""
        num = new if field == "train_number" else entry.get("train_number") or ""
        info = reference_text(rr, sym, num)
        old_info = entry.get("train_info") or ""
        old_auto = reference_text(entry.get("railroad") or "", entry.get("train_symbol") or "", entry.get("train_number") or "")
        if not info and (sym or num) and old_info != old_auto:
            info = old_info
        out["train_info"] = info
    return out


CARS_MAX = 250
DUP_MINUTES = 10
LIGHT_TYPES = ("LGT HLP", "LGT PWR", "HI-RAIL")
SPELL_FIELDS = (("location_spot", "Location"), ("location_subdivision", "Subdivision"))
SAME_ENTRY_SKIP = ("id", "uid", "created_at", "updated_at")


def _id(entry: Any) -> int:
    return int(getattr(entry, "id", 0) or 0)


def _raw(entry: Any, field: str) -> str:
    return getattr(entry, field, None) or ""


def _fold(text: str) -> str:
    return re.sub(r"\s+", " ", text or "").strip()


def _special(entry: Any) -> Dict[str, Any]:
    return normalize_special_power(getattr(entry, "special_power", None) or "")


def _cached(ctx: Dict[str, Any], key: str, make: Callable[[], Any]) -> Any:
    if key not in ctx:
        ctx[key] = make()
    return ctx[key]


def _consist_slots(entry: Any) -> Dict[str, int]:
    """How many unit numbers fit behind the lead, the way the entry pad lays out its boxes."""
    parts = [min(int(p), 12) if p.isdigit() else 0 for p in _t(entry, "power_consist").split("x")]
    head = max((parts[0] if parts else 0) - 1, 0)
    mid = parts[1] if len(parts) > 1 else 0
    rear = parts[2] if len(parts) > 2 else 0
    if not mid:
        return {"head": head, "mid": rear, "rear": 0}
    return {"head": head, "mid": mid, "rear": rear}


def _units_over(entry: Any) -> bool:
    units = _special(entry).get("units") or {}
    if not units:
        return False
    slots = _consist_slots(entry)
    return any(len(units.get(group) or []) > slots[group] for group in slots)


def _lead_unit(entry: Any) -> str:
    lead = _t(entry, "lead_locomotive").upper()
    if not re.search(r"\d", lead):
        return ""
    if re.match(r"[A-Z]", lead):
        return lead
    rr = _t(entry, "railroad").upper()
    return "{} {}".format(rr, lead) if rr and rr != "OTHER" else lead


def _rosters(ctx: Dict[str, Any]) -> Tuple[Dict[str, Dict[str, Any]], Dict[str, Dict[str, Any]]]:
    def make():
        import special_power as sp

        return (
            {sp.unit_key(row["unit"]): row for row in sp.list_rows("heritage")},
            {sp.unit_key(row["engine"]): row for row in sp.list_rows("steam")},
        )
    return _cached(ctx, "rosters", make)


def _special_missing(entry: Any, ctx: Dict[str, Any]) -> List[Tuple[str, Dict[str, Any]]]:
    """Heritage or steam units on this train, by the lists, that Special Power doesn't name yet."""
    from special_power import unit_key

    heritage, steam = _rosters(ctx)
    special = _special(entry)
    have_h = {unit_key(item["unit"]) for item in special["heritage"] if item["unit"]}
    have_s = {unit_key(item["engine"]) for item in special["steam"] if item["engine"]}
    spots = [(_lead_unit(entry), "lead")] if _lead_unit(entry) else []
    for group, position in (("head", "trail"), ("mid", "dp"), ("rear", "dp")):
        spots += [(unit, position) for unit in (special.get("units") or {}).get(group, [])]
    out: List[Tuple[str, Dict[str, Any]]] = []
    for unit, position in spots:
        key = unit_key(unit)
        if key in heritage and key not in have_h:
            row = heritage[key]
            out.append(("heritage", {"unit": row["unit"], "scheme": row["scheme"], "era": row.get("era") or "", "position": position}))
            have_h.add(key)
        elif position == "lead" and key in steam and key not in have_s:
            row = steam[key]
            out.append(("steam", {"engine": row["engine"], "name": row["name"], "wheels": row["wheels"], "diesel_assist": False}))
            have_s.add(key)
    return out


def _spelling_targets(entries: List[Any], field: str) -> Dict[str, str]:
    """Each spelling to change, mapped to the one most trains use (spaces tidied, capitals preferred)."""
    groups: Dict[str, Dict[str, int]] = {}
    for entry in entries:
        raw = _raw(entry, field)
        if raw.strip():
            variants = groups.setdefault(_fold(raw).lower(), {})
            variants[raw] = variants.get(raw, 0) + 1
    out: Dict[str, str] = {}
    for variants in groups.values():
        tally: Dict[str, int] = {}
        for raw, n in variants.items():
            tally[_fold(raw)] = tally.get(_fold(raw), 0) + n
        target = sorted(tally, key=lambda v: (-tally[v], v == v.lower(), v == v.upper(), v))[0]
        for raw in variants:
            if raw != target:
                out[raw] = target
    return out


def _place_key(entry: Any) -> Tuple[str, str]:
    return _fold(_t(entry, "location_spot")).lower(), _fold(_t(entry, "location_subdivision")).lower()


def _place_states(entries: List[Any]) -> Dict[Tuple[str, str], Dict[str, int]]:
    out: Dict[Tuple[str, str], Dict[str, int]] = {}
    for entry in entries:
        state = normalize_state(_t(entry, "location_state"))
        if _t(entry, "location_spot") and state:
            counts = out.setdefault(_place_key(entry), {})
            counts[state] = counts.get(state, 0) + 1
    return out


def _top_state(counts: Dict[str, int]) -> str:
    """The state most trains at a place have, when one clearly leads."""
    ranked = sorted(counts.items(), key=lambda kv: -kv[1])
    if not ranked or (len(ranked) > 1 and ranked[0][1] == ranked[1][1]):
        return ""
    return ranked[0][0]


def _state_off(entry: Any, ctx: Dict[str, Any]) -> bool:
    if not _t(entry, "location_spot"):
        return False
    state = normalize_state(_t(entry, "location_state"))
    if not state:
        return True
    counts = _cached(ctx, "place_states", lambda: _place_states(ctx["entries"])).get(_place_key(entry), {})
    return len(counts) > 1 and state != _top_state(counts)


def _zone_choices(state: str) -> Tuple[str, ...]:
    from states import ARIZONA, MOUNTAIN, SPLIT_ZONES, STATE_ZONES

    if state == "AZ":
        return (ARIZONA, MOUNTAIN)
    return SPLIT_ZONES.get(state) or ((STATE_ZONES[state],) if state in STATE_ZONES else ())


def _zone_off(entry: Any) -> bool:
    zone = _t(entry, "time_zone")
    choices = _zone_choices(normalize_state(_t(entry, "location_state")))
    return bool(zone and choices and zone not in choices)


def _zone_fixable(entry: Any) -> bool:
    from states import SPLIT_STATES, STATE_ZONES

    state = normalize_state(_t(entry, "location_state"))
    return state in STATE_ZONES and state not in SPLIT_STATES


def _known_marks(ctx: Dict[str, Any]) -> set:
    def make():
        import railroads as rr_mod
        import rrlibrary

        marks = set(rr_mod.grouped_railroads()["all"]) | set(rr_mod.mark_aliases())
        marks |= {row["mark"] for row in rrlibrary.library_rows() if row.get("mark")}
        return {str(mark).upper() for mark in marks}
    return _cached(ctx, "marks", make)


def _known_types(ctx: Dict[str, Any]) -> set:
    def make():
        from train_types import list_types

        return {name.upper() for name in list_types()}
    return _cached(ctx, "types", make)


def _odd_types(entry: Any, ctx: Dict[str, Any]) -> List[str]:
    return [t for t in _entry_types(entry) if t.upper() not in _known_types(ctx)]


def _same_groups(entries: List[Any]) -> List[List[int]]:
    """Sightings saved more than once with every field the same, oldest first."""
    import json

    groups: Dict[str, List[int]] = {}
    for entry in entries:
        row = {k: v for k, v in entry.to_dict().items() if k not in SAME_ENTRY_SKIP}
        groups.setdefault(json.dumps(row, sort_keys=True, default=str), []).append(_id(entry))
    return [sorted(ids) for ids in groups.values() if len(ids) > 1]


def _trip_spans(entries: List[Any]) -> Dict[str, Tuple[str, str, str]]:
    """Each trip's name and first and last day, keyed by the name in lower case."""
    spans: Dict[str, List[str]] = {}
    names: Dict[str, str] = {}
    for entry in entries:
        name = _t(entry, "trip_name")
        if not name:
            continue
        key = name.lower()
        names.setdefault(key, name)
        spans.setdefault(key, []).extend(
            d for d in (_t(entry, "date"), _t(entry, "trip_date_from"), _t(entry, "trip_date_to")) if d
        )
    return {key: (names[key], min(days), max(days)) for key, days in spans.items() if days}


def _trip_overlaps(entries: List[Any]) -> set:
    spans = sorted(_trip_spans(entries).items(), key=lambda kv: kv[1][1])
    keys = set()
    for i, (a_key, (_a, a_start, a_end)) in enumerate(spans):
        for b_key, (_b, b_start, b_end) in spans[i + 1:]:
            if b_start >= a_end:
                break
            if a_start < b_end:
                keys.update((a_key, b_key))
    return {_id(e) for e in entries if _t(e, "trip_name").lower() in keys}


def _empty_plan() -> Dict[str, Any]:
    return {"fields": {}, "zone": [], "trips": [], "renames": [], "delete": []}


def _plan_fields(flagged: List[Any], make: Callable[[Any], Optional[Dict[str, Any]]]) -> Dict[str, Any]:
    plan = _empty_plan()
    for entry in flagged:
        fields = make(entry)
        if fields:
            plan["fields"][_id(entry)] = fields
    return plan


def _trip_groups(flagged: List[Any], entries: List[Any], whole_trip: bool) -> Dict[str, Any]:
    plan = _empty_plan()
    names: Dict[str, str] = {}
    ids: Dict[str, List[int]] = {}
    for entry in flagged:
        key = _t(entry, "trip_name").lower()
        names.setdefault(key, _t(entry, "trip_name"))
        ids.setdefault(key, []).append(_id(entry))
    if whole_trip:
        for entry in entries:
            key = _t(entry, "trip_name").lower()
            if key in ids and _id(entry) not in ids[key]:
                ids[key].append(_id(entry))
    plan["trips"] = [(sorted(ids[key]), names[key]) for key in sorted(ids)]
    return plan


def _plan_doubled(entries: List[Any], flagged: List[Any], ctx: Dict[str, Any]) -> Dict[str, Any]:
    return _plan_fields(flagged, lambda e: {
        "lead_locomotive": re.sub(r"^\s*([A-Za-z]{1,6})\s+\1\s+", r"\1 ", _t(e, "lead_locomotive"), flags=re.I)
    })


def _plan_zone(entries: List[Any], flagged: List[Any], ctx: Dict[str, Any]) -> Dict[str, Any]:
    plan = _empty_plan()
    plan["zone"] = [_id(e) for e in flagged if _zone_fixable(e)]
    return plan


def _plan_spelling(entries: List[Any], flagged: List[Any], ctx: Dict[str, Any]) -> Dict[str, Any]:
    targets = {field: _spelling_targets(entries, field) for field, _label in SPELL_FIELDS}

    def fields(entry: Any) -> Dict[str, Any]:
        return {field: targets[field][_raw(entry, field)] for field in targets if _raw(entry, field) in targets[field]}
    return _plan_fields(flagged, fields)


def _plan_trip_spelling(entries: List[Any], flagged: List[Any], ctx: Dict[str, Any]) -> Dict[str, Any]:
    targets = _spelling_targets(entries, "trip_name")
    plan = _empty_plan()
    seen = set()
    for entry in flagged:
        raw = _raw(entry, "trip_name")
        if raw in targets and raw not in seen:
            seen.add(raw)
            plan["renames"].append((raw, targets[raw]))
    return plan


def _plan_special(entries: List[Any], flagged: List[Any], ctx: Dict[str, Any]) -> Dict[str, Any]:
    from special_power import special_power_storage

    def fields(entry: Any) -> Optional[Dict[str, Any]]:
        missing = _special_missing(entry, ctx)
        if not missing:
            return None
        special = _special(entry)
        for kind, item in missing:
            special[kind].append(item)
        return {"special_power": special_power_storage(special)}
    return _plan_fields(flagged, fields)


def _plan_state(entries: List[Any], flagged: List[Any], ctx: Dict[str, Any]) -> Dict[str, Any]:
    from stations import station_state

    places = _cached(ctx, "place_states", lambda: _place_states(entries))
    book: Dict[Tuple[str, str, str], str] = {}

    def fields(entry: Any) -> Optional[Dict[str, Any]]:
        now = normalize_state(_t(entry, "location_state"))
        top = _top_state(places.get(_place_key(entry), {}))
        named = re.search(r",\s*([A-Za-z]{2})\.?$", _t(entry, "location_spot"))
        if not top and not now and named:
            top = normalize_state(named.group(1))
        if not top and not now:
            key = (_t(entry, "location_spot"), _t(entry, "railroad"), _t(entry, "location_subdivision"))
            if key not in book:
                book[key] = normalize_state(station_state(*key))
            top = book[key]
        return {"location_state": top} if top and top != now else None
    return _plan_fields(flagged, fields)


def _plan_same(entries: List[Any], flagged: List[Any], ctx: Dict[str, Any]) -> Dict[str, Any]:
    plan = _empty_plan()
    keep = {ids[0] for ids in _same_groups(entries)}
    plan["delete"] = [_id(e) for e in flagged if _id(e) not in keep]
    return plan


def _units(entry: Any) -> Optional[int]:
    parts = [p for p in _t(entry, "power_consist").split("x") if p.isdigit()]
    return int(parts[0]) if parts else None


def _when(entry: Any) -> Optional[datetime]:
    try:
        return datetime.strptime("{} {}".format(_t(entry, "date"), _t(entry, "time")[:5]), "%Y-%m-%d %H:%M")
    except ValueError:
        return None


def _outside_trip(entry: Any) -> bool:
    start, end, day = _t(entry, "trip_date_from"), _t(entry, "trip_date_to"), _t(entry, "date")
    if not _t(entry, "trip_name") or not day:
        return False
    return bool((start and day < start) or (end and day > end))


def _bad_time(entry: Any) -> bool:
    text = _t(entry, "time")
    if not text:
        return True
    match = re.fullmatch(r"(\d{1,2}):(\d{2})(?::\d{2})?", text)
    return not match or int(match.group(1)) > 23 or int(match.group(2)) > 59


CHECKS: List[Dict[str, Any]] = [
    {"id": "lead_no_number", "title": "Lead loco with no number",
     "hint": "Only a mark like BNSF was saved. Add the number, clear it, or pick Missed, Hidden, Too dark to see, Too far, or Weather.",
     "fn": lambda e: bool(_t(e, "lead_locomotive")) and not _t(e, "lead_status") and not re.search(r"\d", _t(e, "lead_locomotive"))},
    {"id": "lead_doubled", "title": "Lead loco with the mark twice",
     "hint": "Like BNSF BNSF 4410. Drop the extra mark.",
     "fn": lambda e: bool(re.match(r"\s*([A-Za-z]{1,6})\s+\1\s+\S*\d", _t(e, "lead_locomotive"), re.I)),
     "fix": "Drop the extra mark", "plan": _plan_doubled},
    {"id": "units_zero", "title": "No units on the head end",
     "hint": "The consist starts with 0, like 0x2.",
     "fn": lambda e: _units(e) == 0},
    {"id": "cars_many", "title": "More than {} cars".format(CARS_MAX),
     "hint": "Check the car count for a slip, like 1050 for 105.",
     "fn": lambda e: cat._car_total(_t(e, "car_counts")) > CARS_MAX},
    {"id": "no_railroad", "title": "No railroad",
     "hint": "Every sighting needs a railroad.",
     "fn": lambda e: not _t(e, "railroad")},
    {"id": "no_direction", "title": "No direction, or one the Dashboard can't read",
     "hint": "Direction should be North, South, East, or West. Trains marked Stopped, In Siding, Crew Change, or No Crew Onboard can go without one.",
     "fn": lambda e: cat._direction_label(_t(e, "direction")) not in DIRECTIONS
     and not any(getattr(e, flag, False) for flag in ("stopped", "in_siding", "crew_change", "no_crew"))},
    {"id": "no_location", "title": "No location",
     "hint": "These count as Unknown on the Locations card.",
     "fn": lambda e: not _t(e, "location_spot")},
    {"id": "no_type", "title": "No train type",
     "hint": "These count as Unknown on the Train Types card.",
     "fn": lambda e: not [t for t in (getattr(e, "train_types", None) or []) if t]},
    {"id": "bad_time", "title": "No time, or a time that can't be read",
     "hint": "These are left out of the hour and time of day cards.",
     "fn": _bad_time},
    {"id": "no_zone", "title": "No time zone",
     "hint": "Fix sets the time zone from the state. States with two time zones, or no state, need an Edit.",
     "fn": lambda e: not _t(e, "time_zone"),
     "fix": "Set the time zone from the state", "plan": _plan_zone},
    {"id": "zone_state", "title": "Time zone doesn't fit the state",
     "hint": "Like an Arizona train in Pacific time. Fix sets the zone from the state; states with two time zones need an Edit.",
     "fn": _zone_off,
     "fix": "Set the time zone from the state", "plan": _plan_zone},
    {"id": "future_date", "title": "Date in the future",
     "hint": "Likely the wrong year or month.",
     "fn": lambda e: _t(e, "date") > _date.today().isoformat()},
    {"id": "trip_outside", "title": "Date outside its trip's dates",
     "hint": "Fix stretches the trip dates to cover these days.",
     "fn": _outside_trip,
     "fix": "Stretch the trip dates", "plan": lambda entries, flagged, ctx: _trip_groups(flagged, entries, False)},
    {"id": "trip_no_dates", "title": "Trip with no trip dates",
     "hint": "Fix sets the trip dates from the first and last day of its trains.",
     "fn": lambda e: bool(_t(e, "trip_name")) and not (_t(e, "trip_date_from") and _t(e, "trip_date_to")),
     "fix": "Set the trip dates from its trains", "plan": lambda entries, flagged, ctx: _trip_groups(flagged, entries, True)},
    {"id": "trip_overlap", "title": "Trips whose dates overlap",
     "hint": "Two trips running on the same days. If they're one trip, rename one to the other's name under Trips; otherwise Edit the trains on the wrong trip.",
     "wide": lambda entries, ctx: _trip_overlaps(entries)},
    {"id": "trip_spelling", "title": "Trip name spelled different ways",
     "hint": "Like Route 66 and route 66. Fix renames each to the spelling most trains use, and keeps every trip's details.",
     "wide": lambda entries, ctx: {_id(e) for e in entries if _raw(e, "trip_name") in _spelling_targets(entries, "trip_name")},
     "fix": "Use one spelling", "plan": _plan_trip_spelling, "row_fix": False},
    {"id": "place_spelling", "title": "Location or subdivision spelled different ways",
     "hint": "Like Flagstaff and flagstaff, or extra spaces. Fix uses the spelling most trains have.",
     "wide": lambda entries, ctx: {
         _id(e) for e in entries
         for field, _label in SPELL_FIELDS
         if _raw(e, field) in _cached(ctx, "spell_" + field, lambda field=field: _spelling_targets(entries, field))
     },
     "fix": "Use one spelling", "plan": _plan_spelling},
    {"id": "state_off", "title": "Location with no state, or a different state than its other trains",
     "hint": "Fix uses the state most trains at that location and subdivision have, or the station book's state when none of them has one. For the rest, open the check and set a state for each place.",
     "wide": lambda entries, ctx: {_id(e) for e in entries if _state_off(e, ctx)},
     "fix": "Use the location's usual state", "plan": _plan_state, "places": True,
     "left": "Set a state for the rest by place below."},
    {"id": "rr_unknown", "title": "Railroad not on the Railroad menu or in the Library",
     "hint": "Pick Replace next to a mark to change it to a known one in Find and Replace.",
     "wide": lambda entries, ctx: {_id(e) for e in entries if _t(e, "railroad") and _t(e, "railroad").upper() not in _known_marks(ctx)},
     "values": "railroad"},
    {"id": "type_unknown", "title": "Train type not on the Train Types list",
     "hint": "Like a type typed under Other, or one taken off the list. Replace changes it to a listed type; Add to List keeps it as a chip.",
     "wide": lambda entries, ctx: {_id(e) for e in entries if _odd_types(e, ctx)},
     "values": "train_types"},
    {"id": "light_cars", "title": "Light power with a car count",
     "hint": "Light Help, Light Power, and Hi-Rail run without cars. Fix clears the car count.",
     "fn": lambda e: bool(_entry_types(e)) and all(t in LIGHT_TYPES for t in _entry_types(e)) and cat._car_total(_t(e, "car_counts")) > 0,
     "fix": "Clear the car count", "plan": lambda entries, flagged, ctx: _plan_fields(flagged, lambda e: {"car_counts": ""})},
    {"id": "units_over", "title": "More unit numbers than the consist has room for",
     "hint": "Like 3x0 with four unit numbers. Edit the train to fix the consist or the numbers.",
     "fn": _units_over},
    {"id": "special_missing", "title": "Heritage or steam unit not under Special Power",
     "hint": "The lead or a unit number is on the Heritage & Steam List. Fix adds it to Special Power.",
     "wide": lambda entries, ctx: {_id(e) for e in entries if _special_missing(e, ctx)},
     "fix": "Add it to Special Power", "plan": _plan_special},
    {"id": "same_entry", "title": "Saved more than once (every field the same)",
     "hint": "Fix deletes the extra copies and keeps the first one saved. Activity keeps what was deleted.",
     "wide": lambda entries, ctx: {i for ids in _same_groups(entries) for i in ids},
     "fix": "Delete the extra copies", "plan": _plan_same, "left": "The first one saved stays."},
    {"id": "dup_lead", "title": "Same lead loco within {} minutes".format(DUP_MINUTES),
     "hint": "Could be the same train logged twice. Delete one if so.",
     "wide": lambda entries, ctx: _dup_lead_ids(entries)},
]
CHECKS_BY_ID = {check["id"]: check for check in CHECKS}


def _dup_lead_ids(entries: List[Any]) -> set:
    by_lead: Dict[Tuple[str, str], List[Tuple[datetime, int]]] = {}
    for entry in entries:
        lead = _t(entry, "lead_locomotive").upper()
        when = _when(entry)
        if not lead or not re.search(r"\d", lead) or when is None:
            continue
        by_lead.setdefault((lead, _t(entry, "date")), []).append((when, int(getattr(entry, "id", 0) or 0)))
    out = set()
    window = timedelta(minutes=DUP_MINUTES)
    for items in by_lead.values():
        items.sort()
        for (a_when, a_id), (b_when, b_id) in zip(items, items[1:]):
            if b_when - a_when <= window:
                out.update((a_id, b_id))
    return out


def _new_ctx(entries: List[Any]) -> Dict[str, Any]:
    return {"entries": entries}


def check_ids(entries: List[Any], check_id: str, ctx: Optional[Dict[str, Any]] = None) -> List[int]:
    check = CHECKS_BY_ID.get(check_id)
    if check is None:
        raise ValueError("Pick a check.")
    ctx = ctx if ctx is not None else _new_ctx(entries)
    if "wide" in check:
        found = check["wide"](entries, ctx)
        return [_id(e) for e in entries if _id(e) in found]
    return [_id(e) for e in entries if check["fn"](e)]


def plan_ids(plan: Dict[str, Any]) -> List[int]:
    ids = set(plan["fields"]) | set(plan["zone"]) | set(plan["delete"])
    for trip_ids, _name in plan["trips"]:
        ids.update(trip_ids)
    return sorted(ids)


def fix_plan(entries: List[Any], check_id: str, ctx: Optional[Dict[str, Any]] = None,
             only: Optional[set] = None) -> Dict[str, Any]:
    """What one check's Fix would change, limited to some trains when `only` is given."""
    check = CHECKS_BY_ID.get(check_id)
    if check is None:
        raise ValueError("Pick a check.")
    if "plan" not in check:
        raise ValueError("This check has no automatic fix. Edit the trains instead.")
    ctx = ctx if ctx is not None else _new_ctx(entries)
    flagged_ids = set(check_ids(entries, check_id, ctx))
    flagged = [e for e in entries if _id(e) in flagged_ids]
    plan = check["plan"](entries, flagged, ctx)
    if only is None:
        return plan
    if plan["renames"]:
        raise ValueError("This fix works on the whole trip. Use Fix All.")
    return {
        "fields": {i: f for i, f in plan["fields"].items() if i in only},
        "zone": [i for i in plan["zone"] if i in only],
        "trips": [([i for i in ids if i in only], name) for ids, name in plan["trips"] if set(ids) & only],
        "renames": [],
        "delete": [i for i in plan["delete"] if i in only],
    }


def fixable_ids(entries: List[Any], check_id: str, ctx: Optional[Dict[str, Any]] = None) -> List[int]:
    check = CHECKS_BY_ID[check_id]
    if "plan" not in check:
        return []
    ctx = ctx if ctx is not None else _new_ctx(entries)
    plan = fix_plan(entries, check_id, ctx)
    flagged = set(check_ids(entries, check_id, ctx))
    if plan["renames"]:
        olds = {old for old, _new in plan["renames"]}
        return [_id(e) for e in entries if _raw(e, "trip_name") in olds and _id(e) in flagged]
    return [i for i in plan_ids(plan) if i in flagged]


def state_places(entries: List[Any], ctx: Optional[Dict[str, Any]] = None) -> List[Dict[str, Any]]:
    """For the state check, each flagged place with its trains and a suggested state."""
    from stations import station_state

    ctx = ctx if ctx is not None else _new_ctx(entries)
    flagged = set(check_ids(entries, "state_off", ctx))
    places = _cached(ctx, "place_states", lambda: _place_states(entries))
    subs: Dict[str, Dict[str, int]] = {}
    for entry in entries:
        state = normalize_state(_t(entry, "location_state"))
        sub = _fold(_t(entry, "location_subdivision")).lower()
        if state and sub:
            subs.setdefault(sub, {})
            subs[sub][state] = subs[sub].get(state, 0) + 1
    groups: Dict[Tuple[str, str], Dict[str, Any]] = {}
    for entry in entries:
        if _id(entry) not in flagged:
            continue
        group = groups.setdefault(_place_key(entry), {
            "spot": _t(entry, "location_spot"), "subdivision": _t(entry, "location_subdivision"),
            "railroad": _t(entry, "railroad"), "ids": [], "states": set(),
        })
        group["ids"].append(_id(entry))
        state = normalize_state(_t(entry, "location_state"))
        if state:
            group["states"].add(state)
    out = []
    for key, group in groups.items():
        guess = _top_state(places.get(key, {}))
        why = "Most trains here are in {}.".format(guess) if guess else ""
        named = re.search(r",\s*([A-Za-z]{2})\.?$", group["spot"])
        if not guess and named and normalize_state(named.group(1)):
            guess = normalize_state(named.group(1))
            why = "The location name ends in {}.".format(guess)
        if not guess:
            guess = normalize_state(station_state(group["spot"], group["railroad"], group["subdivision"]))
            if not guess and group["subdivision"]:
                guess = normalize_state(station_state(group["spot"], "", group["subdivision"]))
            why = "The station book has it in {}.".format(guess) if guess else ""
        if not guess and key[1]:
            counts = subs.get(key[1], {})
            guess = _top_state(counts)
            if guess:
                why = "{} of {} trains on {} with a state are in {}.".format(
                    counts[guess], sum(counts.values()), group["subdivision"], guess)
        out.append({
            "spot": group["spot"], "subdivision": group["subdivision"], "ids": sorted(group["ids"]),
            "count": len(group["ids"]), "now": ", ".join(sorted(group["states"])), "guess": guess, "why": why,
        })
    out.sort(key=lambda p: (-p["count"], p["subdivision"].lower(), p["spot"].lower()))
    return out


def check_values(entries: List[Any], check_id: str, ctx: Optional[Dict[str, Any]] = None) -> List[Dict[str, Any]]:
    """For checks about a value (an unknown mark or type), each value and its train count."""
    check = CHECKS_BY_ID[check_id]
    field = check.get("values")
    if not field:
        return []
    ctx = ctx if ctx is not None else _new_ctx(entries)
    flagged = set(check_ids(entries, check_id, ctx))
    counts: Dict[str, int] = {}
    for entry in entries:
        if _id(entry) not in flagged:
            continue
        values = _odd_types(entry, ctx) if field == "train_types" else [_t(entry, field)]
        for value in set(values):
            counts[value] = counts.get(value, 0) + 1
    return [{"value": k, "trains": v} for k, v in sorted(counts.items(), key=lambda kv: (-kv[1], kv[0].lower()))]


def check_summary(entries: List[Any]) -> List[Dict[str, Any]]:
    ctx = _new_ctx(entries)
    out = []
    for c in CHECKS:
        count = len(check_ids(entries, c["id"], ctx))
        out.append({
            "id": c["id"],
            "title": c["title"],
            "hint": c["hint"],
            "count": count,
            "fix": c.get("fix", ""),
            "fixable": len(fixable_ids(entries, c["id"], ctx)) if count and c.get("fix") else 0,
        })
    return out
