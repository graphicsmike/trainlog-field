"""Station book and symbol list updates that arrive without a new version of TRAIN LOG.

A data pack is a zip with manifest.json, manifest.sig, subdivisions/*.csv, and reference/*.json.
Installed packs live in Application Support/data-updates/current and take the place of the
lists shipped inside the app. The user's own subdivision files, hidden list, heritage edits,
and log are separate and never touched. An app whose built-in data is newer ignores the pack.
"""
from __future__ import annotations

import base64
import hashlib
import io
import json
import os
import re
import shutil
import secrets
import zipfile
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, Optional

from paths import resource_root, support_dir
from version import APP_VERSION

# Packs are published to the releases repository named in updater.REPO.
PUBLIC_KEY = "iwN4QeFfMKHD4OzReFJwEl8hblSHIuvRhwlJTQ9BIqw="

PACK_FORMAT = 1
MAX_PACK_BYTES = 60 * 1024 * 1024
MAX_UNPACKED_BYTES = 200 * 1024 * 1024
REFERENCE_FILES = (
    "freight_symbols.json", "passenger_trains.json", "special_power.json",
    "railroad_library.csv", "railroad_library_extra.csv",
)
_MEMBER = re.compile(
    r"^(subdivisions/[^/\\]+\.csv|reference/(?:freight_symbols|passenger_trains|special_power)\.json"
    r"|reference/railroad_library(?:_extra)?\.csv)$"
)


class DataUpdateError(Exception):
    def __init__(self, message: str) -> None:
        super().__init__(message)
        self.message = message


def updates_dir() -> Path:
    return support_dir() / "data-updates"


def current_dir() -> Path:
    return updates_dir() / "current"


def bundled_assets() -> Path:
    return resource_root() / "assets"


def _version_tuple(text: Any) -> tuple:
    return tuple(int(part) for part in re.findall(r"\d+", str(text or "0"))[:4]) or (0,)


def _read_json(path: Path) -> Dict[str, Any]:
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return {}
    return data if isinstance(data, dict) else {}


def bundled_info() -> Dict[str, Any]:
    data = _read_json(bundled_assets() / "reference" / "data-version.json")
    return {"data_version": int(data.get("data_version") or 0), "created": str(data.get("created") or "")}


def _installed(folder: Path) -> Optional[Dict[str, Any]]:
    manifest = _read_json(folder / "manifest.json")
    if not manifest:
        return None
    meta = _read_json(folder / "installed.json")
    return {
        "data_version": int(manifest.get("data_version") or 0),
        "min_app_version": str(manifest.get("min_app_version") or ""),
        "created": str(manifest.get("created") or ""),
        "notes": str(manifest.get("notes") or ""),
        "sha256": str(meta.get("sha256") or ""),
        "installed_at": str(meta.get("installed_at") or ""),
    }


def _usable(pack: Optional[Dict[str, Any]]) -> bool:
    if not pack:
        return False
    if pack["data_version"] <= bundled_info()["data_version"]:
        return False
    return _version_tuple(pack["min_app_version"]) <= _version_tuple(APP_VERSION)


def active_pack() -> Optional[Dict[str, Any]]:
    pack = _installed(current_dir())
    return pack if _usable(pack) else None


def reference_path(name: str) -> Path:
    pack = active_pack()
    if pack:
        candidate = current_dir() / "reference" / name
        if candidate.is_file():
            return candidate
    return bundled_assets() / "reference" / name


def subdivisions_dir() -> Path:
    pack = active_pack()
    if pack and (current_dir() / "subdivisions").is_dir():
        return current_dir() / "subdivisions"
    return bundled_assets() / "subdivisions"


def apply(changed: bool = False) -> None:
    """Point the station book and symbol lists at the active pack, or back at the built-in data."""
    import reference
    import special_power
    import stations

    folder = subdivisions_dir()
    reference._load.cache_clear()
    special_power.shipped_roster.cache_clear()
    if changed or stations.CSV_DIR != folder:
        stations.CSV_DIR = folder
        stations.reload_gazetteer()


def status() -> Dict[str, Any]:
    import updater

    pack = active_pack()
    built_in = bundled_info()
    return {
        "configured": updater.has_key(),
        "source": "update" if pack else "built-in",
        "data_version": pack["data_version"] if pack else built_in["data_version"],
        "created": pack["created"] if pack else built_in["created"],
        "notes": pack["notes"] if pack else "",
        "installed_at": pack["installed_at"] if pack else "",
        "sha256": pack["sha256"] if pack else "",
        "built_in": built_in,
        "app_version": APP_VERSION,
    }


# --- checking and downloading ---------------------------------------------------------------

def _feed() -> Dict[str, Any]:
    import updater

    token = updater.get_key()
    if not token:
        raise DataUpdateError(updater.NEED_KEY)
    latest = updater.latest_data(updater.releases(token), token)
    if not latest:
        raise DataUpdateError("There are no data updates yet.")
    return latest


def check() -> Dict[str, Any]:
    latest = _feed()
    current = status()
    newer = latest["data_version"] > current["data_version"]
    fits = _version_tuple(latest["min_app_version"]) <= _version_tuple(APP_VERSION)
    if not newer:
        message = "You have the latest station book and symbol lists."
    elif not fits:
        message = "A data update is available, but it needs TRAIN LOG {} or newer.".format(latest["min_app_version"])
    else:
        message = "A data update is available."
    public = {key: value for key, value in latest.items() if key != "asset"}
    return {"available": newer and fits, "latest": public, "current": current, "message": message, "_asset": latest["asset"]}


def install_latest() -> Dict[str, Any]:
    import updater

    found = check()
    if not found["available"]:
        raise DataUpdateError(found["message"])
    latest = found["latest"]
    data = updater.asset_bytes(found["_asset"], updater.get_key(), MAX_PACK_BYTES)
    if latest["sha256"] and hashlib.sha256(data).hexdigest() != latest["sha256"]:
        raise DataUpdateError("The download didn't match what the update server listed. Nothing was changed.")
    return install_pack(data)


# --- installing -------------------------------------------------------------------------------

def _verify_signature(manifest: bytes, signature: bytes) -> None:
    from cryptography.exceptions import InvalidSignature
    from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey

    key = Ed25519PublicKey.from_public_bytes(base64.b64decode(PUBLIC_KEY))
    try:
        key.verify(base64.b64decode(signature.strip()), manifest)
    except (InvalidSignature, ValueError) as exc:
        raise DataUpdateError("This data update isn't signed by TRAIN LOG. Nothing was changed.") from exc


def _check_member(name: str, data: bytes) -> None:
    if name.endswith(".json"):
        try:
            json.loads(data.decode("utf-8"))
        except ValueError as exc:
            raise DataUpdateError("{} in the data update couldn't be read. Nothing was changed.".format(name)) from exc
        return
    from stations import _read_csv

    probe = updates_dir() / ".probe-{}.csv".format(secrets.token_hex(4))
    probe.write_bytes(data)
    try:
        railroads, rows = _read_csv(probe)
    finally:
        probe.unlink()
    if not railroads or not rows:
        raise DataUpdateError("{} in the data update couldn't be read. Nothing was changed.".format(name))


def install_pack(data: bytes, trusted: bool = False) -> Dict[str, Any]:
    """Install a pack. trusted skips the signature for a pack relayed by the paired Mac, which checked it."""
    if len(data) > MAX_PACK_BYTES:
        raise DataUpdateError("That data update is too large.")
    try:
        archive = zipfile.ZipFile(io.BytesIO(data))
    except zipfile.BadZipFile as exc:
        raise DataUpdateError("That data update isn't a valid file. Nothing was changed.") from exc
    with archive:
        names = set(archive.namelist())
        if "manifest.json" not in names or "manifest.sig" not in names:
            raise DataUpdateError("That data update is missing its manifest. Nothing was changed.")
        manifest_bytes = archive.read("manifest.json")
        if not trusted:
            _verify_signature(manifest_bytes, archive.read("manifest.sig"))
        try:
            manifest = json.loads(manifest_bytes.decode("utf-8"))
            version = int(manifest["data_version"])
            files = dict(manifest["files"])
        except (ValueError, KeyError, TypeError) as exc:
            raise DataUpdateError("That data update's manifest couldn't be read. Nothing was changed.") from exc
        if int(manifest.get("format") or 0) != PACK_FORMAT:
            raise DataUpdateError("That data update needs a newer version of TRAIN LOG.")
        if _version_tuple(manifest.get("min_app_version")) > _version_tuple(APP_VERSION):
            raise DataUpdateError("That data update needs TRAIN LOG {} or newer.".format(manifest.get("min_app_version")))
        if version <= bundled_info()["data_version"]:
            raise DataUpdateError("This copy of TRAIN LOG already has newer station data built in.")
        members = names - {"manifest.json", "manifest.sig"}
        members = {name for name in members if not name.endswith("/")}
        if members != set(files) or not all(_MEMBER.match(name) for name in members):
            raise DataUpdateError("That data update has unexpected files. Nothing was changed.")
        if sum(archive.getinfo(name).file_size for name in members) > MAX_UNPACKED_BYTES:
            raise DataUpdateError("That data update is too large.")

        root = updates_dir()
        root.mkdir(parents=True, exist_ok=True)
        incoming = root / ".incoming-{}".format(secrets.token_hex(4))
        try:
            for name in sorted(members):
                content = archive.read(name)
                if hashlib.sha256(content).hexdigest() != str(files[name]).lower():
                    raise DataUpdateError("{} in the data update is damaged. Nothing was changed.".format(name))
                _check_member(name, content)
                dest = incoming / name
                dest.parent.mkdir(parents=True, exist_ok=True)
                dest.write_bytes(content)
            (incoming / "manifest.json").write_bytes(manifest_bytes)
            (incoming / "manifest.sig").write_bytes(archive.read("manifest.sig"))
            (incoming / "pack.zip").write_bytes(data)
            (incoming / "installed.json").write_text(
                json.dumps(
                    {
                        "sha256": hashlib.sha256(data).hexdigest(),
                        "installed_at": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
                    }
                ),
                encoding="utf-8",
            )
            _swap_in(incoming)
        except BaseException:
            shutil.rmtree(incoming, ignore_errors=True)
            raise
    apply(changed=True)
    return status()


def _swap_in(incoming: Path) -> None:
    current = current_dir()
    previous = updates_dir() / "previous"
    if previous.exists():
        shutil.rmtree(previous)
    if current.exists():
        os.replace(current, previous)
    os.replace(incoming, current)


def use_built_in() -> Dict[str, Any]:
    current = current_dir()
    if current.exists():
        previous = updates_dir() / "previous"
        if previous.exists():
            shutil.rmtree(previous)
        os.replace(current, previous)
    apply(changed=True)
    return status()


def pack_bytes() -> Optional[bytes]:
    """The installed pack as downloaded, for relaying to a paired phone."""
    if not active_pack():
        return None
    path = current_dir() / "pack.zip"
    return path.read_bytes() if path.is_file() else None


# --- publishing (used by scripts/build_data_pack.py and the tests) ---------------------------

def make_pack(files: Dict[str, bytes], data_version: int, private_key: Any, min_app_version: str = APP_VERSION,
              notes: str = "", created: str = "") -> bytes:
    for name in files:
        if not _MEMBER.match(name):
            raise ValueError("Not allowed in a data pack: " + name)
    manifest = {
        "format": PACK_FORMAT,
        "data_version": int(data_version),
        "min_app_version": min_app_version,
        "created": created or datetime.now().strftime("%Y-%m-%d"),
        "notes": notes,
        "files": {name: hashlib.sha256(content).hexdigest() for name, content in sorted(files.items())},
    }
    manifest_bytes = (json.dumps(manifest, indent=1) + "\n").encode("utf-8")
    signature = base64.b64encode(private_key.sign(manifest_bytes))
    out = io.BytesIO()
    with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as archive:
        archive.writestr("manifest.json", manifest_bytes)
        archive.writestr("manifest.sig", signature + b"\n")
        for name, content in sorted(files.items()):
            archive.writestr(name, content)
    return out.getvalue()
