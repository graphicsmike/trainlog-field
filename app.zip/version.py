"""App version shown in the Mac bundle, About box, and API."""

APP_VERSION = "1.0.27"
