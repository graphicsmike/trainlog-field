"""Best guesses for subdivision and time zone on imported sightings.

Every guess carries a short reason so Import Review can show why it was
picked. Only fields left blank in the file are guessed.
"""
from __future__ import annotations

import re
from collections import Counter, defaultdict
from typing import Any, Dict, Iterable, List, Optional, Tuple

import stations

from states import (
    ALASKA as _ALASKA,
    ARIZONA as _ARIZONA,
    CENTRAL as _CENTRAL,
    EASTERN as _EASTERN,
    HAWAII as _HAWAII,
    MOUNTAIN as _MOUNTAIN,
    PACIFIC as _PACIFIC,
    SPLIT_STATES,
    SPLIT_ZONES,
    STATE_ZONES,
    normalize_state,
    state_from_region,
)

_ZONE_SHORT = {
    _EASTERN: "Eastern", _CENTRAL: "Central", _MOUNTAIN: "Mountain", _ARIZONA: "Arizona",
    _PACIFIC: "Pacific", _ALASKA: "Alaska", _HAWAII: "Hawaii",
}

NEAR_MINUTES = 90
DAY_MINUTES = 180
TRIP_MINUTES = 360


def _key(text: Any) -> str:
    return re.sub(r"[^a-z0-9]+", "", str(text or "").lower())


def _spot_key(location: Any) -> str:
    return _key(stations.spot_name(str(location or "")))


def _minutes(value: Any) -> Optional[int]:
    match = re.match(r"^(\d{1,2}):(\d{2})", str(value or ""))
    if not match:
        return None
    return int(match.group(1)) * 60 + int(match.group(2))


def zone_name(zone: str) -> str:
    return _ZONE_SHORT.get(zone, zone)


def parse_coordinates(value: Any) -> Optional[Tuple[float, float]]:
    if value in (None, ""):
        return None
    if isinstance(value, dict):
        lat = value.get("lat", value.get("latitude"))
        lon = value.get("lon", value.get("lng", value.get("longitude")))
    elif isinstance(value, (list, tuple)) and len(value) >= 2:
        lat, lon = value[0], value[1]
    else:
        text = str(value)
        if text.strip().startswith(("{", "[")):
            import json

            try:
                return parse_coordinates(json.loads(text))
            except (TypeError, ValueError):
                return None
        nums = re.findall(r"-?\d+(?:\.\d+)?", text)
        if len(nums) < 2:
            return None
        lat, lon = nums[0], nums[1]
    try:
        lat_f, lon_f = float(lat), float(lon)
    except (TypeError, ValueError):
        return None
    if not (-90 <= lat_f <= 90 and -180 <= lon_f <= 180):
        return None
    return lat_f, lon_f


def zone_from_coordinates(lat: float, lon: float) -> str:
    """Rough US zone from a point. Close to a zone line it can be wrong."""
    if 18 <= lat <= 23 and -161 <= lon <= -154:
        return _HAWAII
    if lat >= 51 and lon <= -129:
        return _ALASKA
    if not (24 <= lat <= 50 and -125 <= lon <= -66):
        return ""
    if 31.3 <= lat <= 37.0 and -114.82 <= lon <= -109.04:
        return _ARIZONA
    if lat < 36.5:
        east = -85.0
    elif lat < 38:
        east = -86.5
    else:
        east = -87.5
    if lon >= east:
        return _EASTERN
    if lat < 32:
        central = -104.5
    elif lat < 37:
        central = -103.04
    elif lat < 40:
        central = -101.8
    else:
        central = -101.0
    if lon >= central:
        return _CENTRAL
    if lat >= 45.5:
        mountain = -116.0
    elif lat >= 42:
        mountain = -117.0
    else:
        mountain = -114.05
    if lon >= mountain:
        return _MOUNTAIN
    return _PACIFIC


class _Pool:
    """What the log and the file already say, used as evidence."""

    def __init__(self) -> None:
        self.sub_by_rr_spot: Dict[Tuple[str, str], Counter] = defaultdict(Counter)
        self.sub_by_spot: Dict[str, Counter] = defaultdict(Counter)
        self.sub_by_rr: Dict[str, Counter] = defaultdict(Counter)
        self.zone_by_sub: Dict[str, Counter] = defaultdict(Counter)
        self.zone_by_spot: Dict[str, Counter] = defaultdict(Counter)
        self.by_day: Dict[str, List[Dict[str, Any]]] = defaultdict(list)

    def add(self, row: Dict[str, Any], *, sub_known: bool = True, zone_known: bool = True) -> None:
        rr = _key(row.get("railroad"))
        spot = _spot_key(row.get("location_spot"))
        sub = str(row.get("location_subdivision") or "").strip() if sub_known else ""
        zone = str(row.get("time_zone") or "").strip() if zone_known else ""
        if sub:
            if spot:
                self.sub_by_rr_spot[(rr, spot)][sub] += 1
                self.sub_by_spot[spot][sub] += 1
            if rr:
                self.sub_by_rr[rr][sub] += 1
        if zone:
            if sub:
                self.zone_by_sub[_key(sub)][zone] += 1
            if spot:
                self.zone_by_spot[spot][zone] += 1
        date = str(row.get("date") or "")
        if date and (sub or zone):
            self.by_day[date].append(
                {
                    "rr": rr,
                    "sub": sub,
                    "zone": zone,
                    "minutes": _minutes(row.get("time")),
                    "trip": _key(row.get("trip_name")),
                    "time": str(row.get("time") or ""),
                    "railroad": str(row.get("railroad") or ""),
                }
            )

    def nearest(
        self, row: Dict[str, Any], field: str, *, same_rr: bool, limit: int, allowed: Optional[Iterable[str]] = None
    ) -> Optional[Dict[str, Any]]:
        date = str(row.get("date") or "")
        mins = _minutes(row.get("time"))
        rr = _key(row.get("railroad"))
        trip = _key(row.get("trip_name"))
        allowed_set = set(allowed) if allowed is not None else None
        best = None
        best_gap = None
        for item in self.by_day.get(date, []):
            value = item[field]
            if not value:
                continue
            if same_rr and item["rr"] != rr:
                continue
            if allowed_set is not None and value not in allowed_set:
                continue
            if mins is None or item["minutes"] is None:
                continue
            gap = abs(mins - item["minutes"])
            cap = TRIP_MINUTES if trip and item["trip"] == trip else limit
            if gap > cap:
                continue
            if best_gap is None or gap < best_gap:
                best, best_gap = item, gap
        return best


def _top(counter: Counter, among: Optional[Iterable[str]] = None) -> str:
    if not counter:
        return ""
    if among is not None:
        allowed = set(among)
        items = [(value, n) for value, n in counter.items() if value in allowed]
    else:
        items = list(counter.items())
    if not items:
        return ""
    items.sort(key=lambda pair: (-pair[1], pair[0]))
    return items[0][0]


def _plural(n: int, word: str) -> str:
    return "{} {}{}".format(n, word, "" if n == 1 else "s")


def _pick_among(row: Dict[str, Any], pool: _Pool, candidates: List[str], what: str) -> Tuple[str, str]:
    rr = _key(row.get("railroad"))
    n = len(candidates)
    near = pool.nearest(row, "sub", same_rr=False, limit=DAY_MINUTES, allowed=candidates)
    if near:
        return near["sub"], "{} is on {} subdivisions; the sighting at {} that day was on {}".format(
            what, n, near["time"], near["sub"]
        )
    pick = _top(pool.sub_by_rr.get(rr, Counter()), among=candidates)
    if pick:
        return pick, "{} is on {} subdivisions; {} is the one you log most".format(what, n, pick)
    shown = ", ".join(candidates[:4]) + ("…" if n > 4 else "")
    return candidates[0], "{} is on {} subdivisions ({}); picked the first".format(what, n, shown)


def _state_fit(row: Dict[str, Any]):
    """A test for subdivisions when the file gave the sighting's state."""
    state = normalize_state(row.get("location_state")) if row.get("_state_given") else ""
    if not state:
        return None
    railroad = str(row.get("railroad") or "")
    label = str(row.get("location_spot") or "")

    def fits(sub: str) -> bool:
        at = stations.station_state(label, railroad, sub, by_name_only=True)
        if at:
            return at == state
        states = stations.subdivision_states(sub, railroad)
        return not states or state in states

    return fits


def _guess_subdivision(row: Dict[str, Any], pool: _Pool, strong: bool) -> Tuple[str, str]:
    """Strong guesses rest on the location itself; the rest lean on nearby sightings."""
    railroad = str(row.get("railroad") or "").strip()
    rr = _key(railroad)
    label = str(row.get("location_spot") or "")
    location = stations.spot_name(label)
    spot = _spot_key(location)
    rr_known = stations.railroad_has_stations(railroad)
    fits = _state_fit(row)

    def keep(subs: Iterable[str]) -> List[str]:
        return [s for s in subs if fits is None or fits(s)]

    def top(counts: Optional[Counter], among: Optional[Iterable[str]] = None) -> str:
        if not counts:
            return ""
        allowed = keep(among if among is not None else counts.keys())
        return _top(counts, among=allowed)

    if spot:
        pick = top(pool.sub_by_rr_spot.get((rr, spot)))
        if pick:
            return pick, "Other {} sightings at {} are on {}".format(railroad, location, pick)
        on_rr = keep(stations.station_subdivision_candidates(label, railroad)) if rr_known else []
        if len(on_rr) == 1:
            how = "at that milepost " if stations.milepost_of(label) else ""
            return on_rr[0], "Only {} station named {} {}is on {}".format(railroad, location, how, on_rr[0])
        pick = top(pool.sub_by_spot.get(spot), among=on_rr or None)
        if pick:
            return pick, "Other sightings at {} are on {}".format(location, pick)
        if not on_rr:
            anywhere = keep(stations.station_subdivision_candidates(label, ""))
            if len(anywhere) == 1:
                return anywhere[0], "Only station named {} in the station book is on {}".format(location, anywhere[0])
            if not strong and anywhere:
                return _pick_among(row, pool, anywhere, "A station named {}".format(location))
        elif not strong:
            return _pick_among(row, pool, on_rr, "{} station {}".format(railroad, location))
        if not strong and rr_known and not on_rr:
            loose = keep(stations.station_subdivision_candidates(label, railroad, fuzzy=True))
            if len(loose) == 1:
                return loose[0], "Only {} station like {} is on {}".format(railroad, location, loose[0])
            if loose:
                return _pick_among(row, pool, loose, "A {} station like {}".format(railroad, location))

    if strong:
        return "", ""
    near = pool.nearest(row, "sub", same_rr=True, limit=DAY_MINUTES)
    if near and keep([near["sub"]]):
        return near["sub"], "The {} sighting at {} that day was on {}".format(railroad, near["time"], near["sub"])
    rr_subs = keep(stations.grouped_subdivisions().get(railroad.upper(), []))
    if len(rr_subs) == 1:
        return rr_subs[0], "{} has only one subdivision in the station book".format(railroad)
    counts = pool.sub_by_rr.get(rr)
    pick = top(counts)
    if pick:
        return pick, "Your most-logged {} subdivision ({})".format(railroad, _plural(counts[pick], "sighting"))
    return "", ""


def _fill_state(row: Dict[str, Any], by_name_only: bool = False) -> None:
    if row.get("location_state") or not row.get("location_spot"):
        return
    state = stations.station_state(
        str(row.get("location_spot") or ""),
        str(row.get("railroad") or ""),
        str(row.get("location_subdivision") or ""),
        by_name_only=by_name_only,
    )
    if state:
        row["location_state"] = state


def _guess_zone(
    row: Dict[str, Any], pool: _Pool, region_given: bool, strong: bool, sub_trusted: bool = True
) -> Tuple[str, str]:
    """The sighting's state comes first; the log and nearby sightings only
    decide states that are split between two zones. A subdivision that was
    itself a loose guess is not used as evidence."""
    sub = str(row.get("location_subdivision") or "").strip() if sub_trusted else ""
    location = stations.spot_name(str(row.get("location_spot") or ""))
    state = normalize_state(row.get("location_state"))
    state_zone = STATE_ZONES.get(state, "")
    if state_zone and state not in SPLIT_STATES:
        return state_zone, "{} is in {} ({} time)".format(location or "The location", state, zone_name(state_zone))
    allowed = SPLIT_ZONES.get(state)
    if sub:
        counts = pool.zone_by_sub.get(_key(sub))
        pick = _top(counts, among=allowed) if counts else ""
        if pick:
            return pick, "Other {} sightings are {}".format(sub, zone_name(pick))
    spot = _spot_key(location)
    if spot:
        counts = pool.zone_by_spot.get(spot)
        pick = _top(counts, among=allowed) if counts else ""
        if pick:
            return pick, "Other sightings at {} are {}".format(location, zone_name(pick))
    if state_zone:
        return state_zone, "{} is in {}; most of {} is {} time".format(
            location or "The location", state, state, zone_name(state_zone)
        )
    if region_given:
        state = state_from_region(row.get("location_region"))
        if state and state in STATE_ZONES:
            zone = STATE_ZONES[state]
            return zone, "Region is in {} ({} for most of the state)".format(state, zone_name(zone))
    if strong:
        return "", ""
    near = pool.nearest(row, "zone", same_rr=False, limit=NEAR_MINUTES)
    if near:
        return near["zone"], "The sighting at {} that day was {}".format(near["time"], zone_name(near["zone"]))
    coords = parse_coordinates(row.get("location_coordinates"))
    if coords:
        zone = zone_from_coordinates(*coords)
        if zone:
            return zone, "Rough guess from the coordinates ({})".format(zone_name(zone))
    near = pool.nearest(row, "zone", same_rr=False, limit=DAY_MINUTES)
    if near:
        return near["zone"], "The sighting at {} that day was {}".format(near["time"], zone_name(near["zone"]))
    return "", ""


def fill_guesses(items: List[Dict[str, Any]], history: Iterable[Dict[str, Any]]) -> None:
    """Fill blank subdivision and time zone on cleaned import rows in place.

    Each item has `cleaned` plus the flags `sub_blank`, `zone_blank` and
    `region_given` read from the file before validation. Adds a `review`
    dict with status (guessed or missing) and reason for each blank field.
    """
    history = list(history)
    reviews: List[Dict[str, str]] = [{} for _ in items]
    for item, review in zip(items, reviews):
        cleaned = item["cleaned"]
        if item.get("state_given"):
            cleaned["_state_given"] = True
        _fill_state(cleaned)
        if item["sub_blank"] and cleaned.get("location_subdivision"):
            review["sub_status"] = "guessed"
            review["sub_reason"] = "Only {} station named {} is on {}".format(
                cleaned.get("railroad") or "",
                stations.spot_name(cleaned.get("location_spot") or ""),
                cleaned["location_subdivision"],
            )

    def build_pool() -> _Pool:
        pool = _Pool()
        for row in history:
            pool.add(row)
        for item, review in zip(items, reviews):
            pool.add(
                item["cleaned"],
                sub_known=not item["sub_blank"] or review.get("sub_status") == "guessed",
                zone_known=not item["zone_blank"] or review.get("zone_status") == "guessed",
            )
        return pool

    for strong in (True, False):
        for _round in range(1 if strong else 2):
            pool = build_pool()
            for item, review in zip(items, reviews):
                cleaned = item["cleaned"]
                if item["sub_blank"] and not review.get("sub_status"):
                    sub, reason = _guess_subdivision(cleaned, pool, strong)
                    if sub:
                        cleaned["location_subdivision"] = sub
                        review["sub_status"] = "guessed"
                        review["sub_reason"] = reason
                        if not strong:
                            review["sub_loose"] = "1"
                        _fill_state(cleaned, by_name_only=not strong)
                if item["zone_blank"] and not review.get("zone_status"):
                    zone, reason = _guess_zone(
                        cleaned, pool, item["region_given"], strong, sub_trusted=not review.get("sub_loose")
                    )
                    if zone:
                        cleaned["time_zone"] = zone
                        review["zone_status"] = "guessed"
                        review["zone_reason"] = reason

    for item, review in zip(items, reviews):
        if item["sub_blank"] and not review.get("sub_status"):
            review["sub_status"] = "missing"
            review["sub_reason"] = "No station or nearby sighting to go on"
        if item["zone_blank"] and not review.get("zone_status"):
            review["zone_status"] = "missing"
            review["zone_reason"] = "No region, coordinates, or nearby sighting to go on"
        review.pop("sub_loose", None)
        item["cleaned"].pop("_state_given", None)
        item["review"] = review
