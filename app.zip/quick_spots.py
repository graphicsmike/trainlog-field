"""Favorite trackside spots for one-tap fill on the pad (Quick spots).

Stored in Application Support as quick_spots.json. Empty until you star a place.
"""
from __future__ import annotations

import json
import re
from typing import Any, Dict, List

from paths import support_dir

MAX_SPOTS = 40
MAX_FIELD = 120
MAX_LABEL = 80


def spots_path():
    return support_dir() / "quick_spots.json"


def _clean_text(raw: Any, limit: int) -> str:
    return re.sub(r"\s+", " ", str(raw or "")).strip()[:limit]


def _clean_state(raw: Any) -> str:
    return re.sub(r"[^A-Za-z]", "", str(raw or "")).upper()[:2]


def clean_spot(raw: Any) -> Dict[str, str] | None:
    if not isinstance(raw, dict):
        return None
    railroad = _clean_text(raw.get("railroad"), 80)
    subdivision = _clean_text(raw.get("subdivision"), MAX_FIELD)
    location = _clean_text(raw.get("location"), MAX_FIELD)
    state = _clean_state(raw.get("state"))
    label = _clean_text(raw.get("label"), MAX_LABEL)
    if not subdivision and not location:
        return None
    spot = {
        "railroad": railroad,
        "subdivision": subdivision,
        "location": location,
        "state": state,
    }
    if label:
        spot["label"] = label
    return spot


def spot_key(spot: Dict[str, str]) -> str:
    return "|".join(
        [
            (spot.get("railroad") or "").lower(),
            (spot.get("subdivision") or "").lower(),
            (spot.get("location") or "").lower(),
            (spot.get("state") or "").lower(),
        ]
    )


def clean_spots(raw: Any) -> List[Dict[str, str]]:
    kept: List[Dict[str, str]] = []
    seen = set()
    for item in raw if isinstance(raw, list) else []:
        spot = clean_spot(item)
        if not spot:
            continue
        key = spot_key(spot)
        if key in seen:
            continue
        seen.add(key)
        kept.append(spot)
        if len(kept) >= MAX_SPOTS:
            break
    return kept


def list_favorites() -> List[Dict[str, str]]:
    path = spots_path()
    if not path.is_file():
        return []
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return []
    if isinstance(data, dict):
        data = data.get("favorites")
    return clean_spots(data)


def save_favorites(raw: Any) -> List[Dict[str, str]]:
    favorites = clean_spots(raw)
    payload = {"favorites": favorites}
    spots_path().write_text(json.dumps(payload, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    return favorites


def add_favorite(raw: Any) -> List[Dict[str, str]]:
    spot = clean_spot(raw)
    if not spot:
        return list_favorites()
    current = list_favorites()
    key = spot_key(spot)
    current = [item for item in current if spot_key(item) != key]
    current.insert(0, spot)
    return save_favorites(current[:MAX_SPOTS])


def remove_favorite(raw: Any) -> List[Dict[str, str]]:
    spot = clean_spot(raw)
    if not spot:
        return list_favorites()
    key = spot_key(spot)
    return save_favorites([item for item in list_favorites() if spot_key(item) != key])
