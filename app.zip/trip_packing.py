"""Per-Mac field packing kit, plus helpers for per-trip checklists.

Your default kit lives in Application Support so each person's gear list is
their own. A trip stores its own copy with tick marks in trip_details.packing.
"""
from __future__ import annotations

import json
import re
from typing import Any, Dict, List

from paths import support_dir

MAX_LABEL = 80
MAX_GROUP = 24
MAX_ITEMS = 40

SHIPPED_KIT: List[Dict[str, str]] = [
    {"label": "Canon 80D #1", "group": "photo"},
    {"label": "Canon 80D #2", "group": "photo"},
    {"label": "18-135 lens", "group": "photo"},
    {"label": "55-250 lens", "group": "photo"},
    {"label": "100-400 lens", "group": "photo"},
    {"label": "Tripod — stills", "group": "photo"},
    {"label": "Tripod — video", "group": "photo"},
    {"label": "Stabilizer mount", "group": "photo"},
    {"label": "Memory cards", "group": "photo"},
    {"label": "Camera batteries", "group": "photo"},
    {"label": "Microphone", "group": "photo"},
    {"label": "Mic extension cable", "group": "photo"},
    {"label": "iPhone + charging cable", "group": "power"},
    {"label": "iPad + charging cable", "group": "power"},
    {"label": "Charging bricks", "group": "power"},
    {"label": "Ice chest", "group": "kit"},
    {"label": "Water", "group": "kit"},
    {"label": "Extra gasoline", "group": "kit"},
    {"label": "Thermos", "group": "kit"},
    {"label": "Coffee pot", "group": "kit"},
    {"label": "Coffee / milk / sugar", "group": "kit"},
    {"label": "Day glasses", "group": "kit"},
    {"label": "Night glasses", "group": "kit"},
    {"label": "Shovel", "group": "safety"},
    {"label": "First aid kit", "group": "safety"},
]


def kit_path():
    return support_dir() / "trip_packing_kit.json"


def _clean_group(raw: Any) -> str:
    return re.sub(r"\s+", " ", str(raw or "")).strip().lower()[:MAX_GROUP]


def _clean_label(raw: Any) -> str:
    return re.sub(r"\s+", " ", str(raw or "")).strip()[:MAX_LABEL]


def clean_kit(raw: Any) -> List[Dict[str, str]]:
    rows: List[Dict[str, str]] = []
    seen = set()
    for item in raw if isinstance(raw, list) else []:
        if isinstance(item, dict):
            label = _clean_label(item.get("label") or item.get("n") or item.get("name"))
            group = _clean_group(item.get("group"))
        else:
            label = _clean_label(item)
            group = ""
        if not label:
            continue
        key = label.casefold()
        if key in seen:
            continue
        seen.add(key)
        row = {"label": label}
        if group:
            row["group"] = group
        rows.append(row)
        if len(rows) >= MAX_ITEMS:
            break
    return rows


def clean_packing(raw: Any) -> List[Dict[str, Any]]:
    """Per-trip checklist: kit rows plus a done flag."""
    rows: List[Dict[str, Any]] = []
    seen = set()
    for item in raw if isinstance(raw, list) else []:
        if not isinstance(item, dict):
            label = _clean_label(item)
            group = ""
            done = False
        else:
            label = _clean_label(item.get("label") or item.get("n") or item.get("name"))
            group = _clean_group(item.get("group"))
            done = bool(item.get("done") or item.get("packed") or item.get("checked"))
        if not label:
            continue
        key = label.casefold()
        if key in seen:
            continue
        seen.add(key)
        row: Dict[str, Any] = {"label": label, "done": done}
        if group:
            row["group"] = group
        rows.append(row)
        if len(rows) >= MAX_ITEMS:
            break
    return rows


def packing_from_kit(kit: Any = None) -> List[Dict[str, Any]]:
    base = clean_kit(kit if kit is not None else list_kit())
    return [{"label": row["label"], "group": row["group"], "done": False} if "group" in row else {"label": row["label"], "done": False} for row in base]


def shipped_kit() -> List[Dict[str, str]]:
    return [dict(row) for row in SHIPPED_KIT]


def list_kit() -> List[Dict[str, str]]:
    path = kit_path()
    if not path.is_file():
        return shipped_kit()
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return shipped_kit()
    if isinstance(data, dict):
        data = data.get("items") or data.get("kit") or []
    cleaned = clean_kit(data)
    return cleaned if cleaned else shipped_kit()


def save_kit(raw: Any) -> List[Dict[str, str]]:
    kit = clean_kit(raw)
    if not kit:
        raise ValueError("Add at least one packing item.")
    kit_path().write_text(json.dumps({"items": kit}, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    return kit


def reset_kit() -> List[Dict[str, str]]:
    path = kit_path()
    if path.exists():
        path.unlink()
    return shipped_kit()


def packing_text(raw: Any) -> str:
    rows = clean_packing(raw)
    return json.dumps(rows, separators=(",", ":"), ensure_ascii=False) if rows else ""


def packing_list(text: Any) -> List[Dict[str, Any]]:
    if isinstance(text, list):
        return clean_packing(text)
    raw = str(text or "").strip()
    if not raw:
        return []
    try:
        data = json.loads(raw)
    except ValueError:
        return []
    return clean_packing(data)
