"""Railroad names from CSVs in assets/railroads/.

Row 1 is group headers (Freight, Pass/Comm, Tourist). Each column is one group.
Other stays a typed choice in the UI, not in these files. Edits are saved
to Application Support so the packaged app can change the list.
"""
from __future__ import annotations

import csv
import io
import json
import re
from pathlib import Path
from typing import Any, Dict, List, Tuple

from paths import resource_root, shipped_json, support_dir

CSV_DIR = resource_root() / "assets" / "railroads"

_FALLBACK_GROUPS = (
    ("Freight", ("BNSF", "UP", "NS", "CN", "CPKC", "CSX")),
    ("Passenger / Commuter", ("AMTK", "ACEX", "JPBX", "SCAX", "SDNX")),
    ("Tourist", ("DSNG", "GCRX", "SRC", "CTSR", "NVRR", "NN")),
)

GROUP_ORDER = ("Freight", "Passenger / Commuter", "Tourist")
_CSV_HEADERS = {"Freight": "Freight", "Passenger / Commuter": "Pass/Comm", "Tourist": "Tourist"}

_ALIASES = {
    "BN": "BNSF",
    "ATSF": "BNSF",
    "SF": "BNSF",
    "SP": "UP",
    "AMTRAK": "AMTK",
    "METROLINK": "SCAX",
    "CALTRAIN": "JPBX",
    "COASTER": "SDNX",
    "FRONTRUNNER": "UTAX",
}

_MARK_CACHE: Dict[str, Any] = {"key": None, "map": {}}


def mark_aliases() -> Dict[str, str]:
    """Other marks for the same railroad (GCRY for GCRX, NJT for NJTR), from the Railroad Library's Aliases.

    Only marks of one railroad, never a merger like SP into UP, so a unit number
    under either mark is the same locomotive.
    """
    import rrlibrary

    paths = (rrlibrary.shipped_path(), rrlibrary.user_path())
    key = tuple(p.stat().st_mtime if p.is_file() else 0 for p in paths) + tuple(str(p) for p in paths)
    if _MARK_CACHE["key"] == key:
        return _MARK_CACHE["map"]
    rows = rrlibrary.library_rows()
    marks = {row["mark"] for row in rows if row["mark"]}
    found: Dict[str, str] = {}
    for row in rows:
        for alias in filter(None, (row["aliases"] or "").split(" / ")):
            if row["mark"] and alias not in marks and alias not in found:
                found[alias] = row["mark"]
    _MARK_CACHE.update(key=key, map=found)
    return found


def canonical_mark(mark: str) -> str:
    """BNSF for BN, GCRX for GCRY, for lookups only: a saved mark is never changed."""
    text = str(mark or "").strip().upper()
    return mark_aliases().get(text) or _ALIASES.get(text) or text

FREIGHT_CLASSES = ("Class I", "Regional", "Shortline", "Tourist")

_DEFAULT_CLASSES = {mark: "Class I" for mark in ("BNSF", "UP", "NS", "CN", "CPKC", "CSX")}

_CLASS_KEYS = {
    "classi": "Class I",
    "class1": "Class I",
    "i": "Class I",
    "1": "Class I",
    "regional": "Regional",
    "classii": "Regional",
    "class2": "Regional",
    "shortline": "Shortline",
    "short": "Shortline",
    "classiii": "Shortline",
    "class3": "Shortline",
    "tourist": "Tourist",
    "heritage": "Tourist",
    "excursion": "Tourist",
}

CLASS_CHOICES: Dict[str, Tuple[str, ...]] = {
    "Freight": FREIGHT_CLASSES,
    "Passenger / Commuter": ("Nationwide", "Commuter", "Light Rail"),
    "Tourist": ("Heritage", "Scenic", "Dinner Train"),
}
ALL_CLASSES: Tuple[str, ...] = tuple(label for choices in CLASS_CHOICES.values() for label in choices)

_GROUP_CLASS_KEYS = {
    "Passenger / Commuter": {
        "nationwide": "Nationwide",
        "national": "Nationwide",
        "intercity": "Nationwide",
        "longdistance": "Nationwide",
        "commuter": "Commuter",
        "regionalrail": "Commuter",
        "lightrail": "Light Rail",
        "light": "Light Rail",
        "streetcar": "Light Rail",
    },
    "Tourist": {
        "heritage": "Heritage",
        "historic": "Heritage",
        "scenic": "Scenic",
        "excursion": "Scenic",
        "dinner": "Dinner Train",
        "dinnertrain": "Dinner Train",
    },
}

_N = re.compile(r"[^a-z0-9]+")

RAILROAD_GROUPS: List[Tuple[str, List[str]]] = []
KNOWN_RAILROADS: Tuple[str, ...] = ()
FREIGHT_RAILROADS: Tuple[str, ...] = ()
PASSENGER_RAILROADS: Tuple[str, ...] = ()
TOURIST_RAILROADS: Tuple[str, ...] = ()
RR_ORDER: Tuple[str, ...] = ()
RR_ALIASES: Dict[str, str] = {}


def _n(text: str) -> str:
    return _N.sub("", (text or "").lower())


def _group_label(raw: str) -> str:
    key = _n(raw)
    if key in ("freight", "frt"):
        return "Freight"
    if key in ("passcomm", "passenger", "passengers", "commuter", "passengercommuter"):
        return "Passenger / Commuter"
    if key in ("tourist", "touristlines", "tourists", "excursion", "heritage", "scenic"):
        return "Tourist"
    return (raw or "").strip() or "Freight"


def user_railroads_path() -> Path:
    return support_dir() / "railroads.csv"


def user_classes_path() -> Path:
    return support_dir() / "railroad_classes.json"


def freight_class_label(raw: str) -> str:
    return _CLASS_KEYS.get(_n(raw), "")


def class_label(raw: str, group: str) -> str:
    """The class name for a railroad in one group, or blank if it isn't one of that group's choices."""
    if group == "Freight":
        return freight_class_label(raw)
    return _GROUP_CLASS_KEYS.get(group, {}).get(_n(raw), "")


def group_of(mark: str) -> str:
    if not RAILROAD_GROUPS:
        reload_railroads()
    for label, names in RAILROAD_GROUPS:
        if mark in names:
            return label
    return ""


def _class_error(group: str) -> str:
    choices = list(CLASS_CHOICES.get(group, ()))
    if not choices:
        return "{} railroads don't have classes".format(group)
    return "Pick " + ", ".join(choices[:-1]) + ", or " + choices[-1]


def shipped_classes() -> Dict[str, str]:
    data = shipped_json("railroads", "rr-classes.json")
    if not isinstance(data, dict):
        return dict(_DEFAULT_CLASSES)
    return {str(mark).strip().upper(): str(value) for mark, value in data.items()}


def _saved_classes() -> Dict[str, str]:
    path = user_classes_path()
    if not path.is_file():
        return {}
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return {}
    if not isinstance(data, dict):
        return {}
    return {str(mark).strip().upper(): str(value) for mark, value in data.items()}


def railroad_classes() -> Dict[str, str]:
    """Class per railroad, from its group's choices in CLASS_CHOICES.

    A saved blank means the user cleared it, so it hides the shipped default.
    A class that doesn't fit the railroad's current group is left out.
    """
    if not RAILROAD_GROUPS:
        reload_railroads()
    merged = shipped_classes()
    merged.update(_saved_classes())
    return {
        mark: label
        for mark, label in ((mark, class_label(value, group_of(mark))) for mark, value in merged.items())
        if label
    }


def set_railroad_class(name: str, rr_class: str) -> Dict[str, Any]:
    from validators import ValidationError

    mark = str(name or "").strip().upper()
    group = group_of(mark)
    if not group:
        raise ValidationError("Add that railroad first", "name")
    label = class_label(rr_class, group)
    if rr_class and not label:
        raise ValidationError(_class_error(group), "rr_class")
    saved = _saved_classes()
    saved[mark] = label
    user_classes_path().write_text(json.dumps(saved, indent=2, sort_keys=True), encoding="utf-8")
    return grouped_railroads()


def _read_csv(path: Path) -> List[Tuple[str, List[str]]]:
    rows = list(csv.reader(path.read_text(encoding="utf-8-sig").splitlines()))
    if not rows:
        return []
    headers = [_group_label(cell) for cell in rows[0]]
    grouped: List[Tuple[str, List[str]]] = []
    seen_names = set()
    for index, header in enumerate(headers):
        if not header:
            continue
        names: List[str] = []
        for row in rows[1:]:
            if index >= len(row):
                continue
            name = (row[index] or "").strip().upper()
            if not name or name in seen_names:
                continue
            seen_names.add(name)
            names.append(name)
        if header in [item[0] for item in grouped]:
            for label, existing in grouped:
                if label == header:
                    existing.extend(names)
                    break
        else:
            grouped.append((header, names))
    return [(label, names) for label, names in grouped if names]


def _apply(groups: List[Tuple[str, List[str]]]) -> None:
    global RAILROAD_GROUPS, KNOWN_RAILROADS, FREIGHT_RAILROADS, PASSENGER_RAILROADS, TOURIST_RAILROADS, RR_ORDER, RR_ALIASES
    RAILROAD_GROUPS = [(label, list(names)) for label, names in groups]
    KNOWN_RAILROADS = tuple(name for _label, names in RAILROAD_GROUPS for name in names)
    FREIGHT_RAILROADS = tuple(
        name
        for label, names in RAILROAD_GROUPS
        if _n(label) == "freight"
        for name in names
    )
    PASSENGER_RAILROADS = tuple(name for name in KNOWN_RAILROADS if name not in FREIGHT_RAILROADS)
    TOURIST_RAILROADS = tuple(name for label, names in RAILROAD_GROUPS if label == "Tourist" for name in names)
    RR_ORDER = KNOWN_RAILROADS
    RR_ALIASES = {name: name for name in KNOWN_RAILROADS}
    RR_ALIASES.update(_ALIASES)
    RR_ALIASES.update(mark_aliases())


def _headers(path: Path) -> List[str]:
    rows = list(csv.reader(path.read_text(encoding="utf-8-sig").splitlines()[:1]))
    return [_group_label(cell) for cell in rows[0]] if rows else []


def _shipped() -> List[Tuple[str, List[str]]]:
    found: List[Tuple[str, List[str]]] = []
    if CSV_DIR.is_dir():
        for path in sorted(CSV_DIR.glob("*.csv")):
            found.extend(_read_csv(path))
    if found:
        return found
    return [(label, list(names)) for label, names in _FALLBACK_GROUPS]


def _load() -> List[Tuple[str, List[str]]]:
    user = user_railroads_path()
    if user.is_file():
        found = _read_csv(user)
        if found:
            if "Tourist" not in _headers(user):
                have = {name for _label, names in found for name in names}
                for label, names in _shipped():
                    extra = [name for name in names if name not in have]
                    if label == "Tourist" and extra:
                        found.append((label, extra))
            return found
    return _shipped()


def reload_railroads() -> Dict[str, Any]:
    _apply(_load())
    return grouped_railroads()


def grouped_railroads() -> Dict[str, Any]:
    if not RAILROAD_GROUPS:
        reload_railroads()
    return {
        "groups": [{"label": label, "railroads": list(names)} for label, names in RAILROAD_GROUPS],
        "all": list(KNOWN_RAILROADS),
        "freight": list(FREIGHT_RAILROADS),
        "passenger": list(PASSENGER_RAILROADS),
        "tourist": list(TOURIST_RAILROADS),
        "classes": railroad_classes(),
        "freight_classes": list(FREIGHT_CLASSES),
        "class_choices": {label: list(choices) for label, choices in CLASS_CHOICES.items()},
        "mark_aliases": dict(mark_aliases()),
    }


def add_railroad(name: str, group_label: str = "Freight", rr_class: str = "") -> Dict[str, Any]:
    from validators import ValidationError

    mark = str(name or "").strip().upper()
    if not mark:
        raise ValidationError("Railroad mark is required", "name")
    if not re.fullmatch(r"[A-Z0-9][A-Z0-9 .&/-]{0,11}", mark):
        raise ValidationError("Railroad marks use letters and numbers, like BNSF or SCAX", "name")
    groups = grouped_railroads()["groups"]
    label = _group_label(group_label)
    if rr_class and not class_label(rr_class, label):
        raise ValidationError(_class_error(label), "rr_class")
    found = False
    for group in groups:
        if group["label"] == label:
            roads = group.setdefault("railroads", [])
            if mark not in roads:
                roads.append(mark)
            found = True
            break
    if not found:
        groups.append({"label": label, "railroads": [mark]})
    saved = save_railroads(groups)
    if rr_class:
        saved = set_railroad_class(mark, rr_class)
    saved["name"] = mark
    return saved


def save_railroads(groups: List[Dict[str, Any]]) -> Dict[str, Any]:
    from validators import ValidationError

    cleaned: List[Tuple[str, List[str]]] = []
    seen = set()
    for group in groups or []:
        label = _group_label(str(group.get("label") or ""))
        names = []
        for raw in group.get("railroads") or []:
            name = str(raw or "").strip().upper()
            if not name or name in seen:
                continue
            if not re.fullmatch(r"[A-Z0-9][A-Z0-9 .&/-]{0,11}", name):
                raise ValidationError("Railroad marks use letters and numbers, like BNSF or SCAX", "railroads")
            seen.add(name)
            names.append(name)
        if names:
            cleaned.append((label, names))
    if not cleaned:
        raise ValidationError("Keep at least one railroad", "railroads")
    text, cleaned = _csv_text(cleaned)
    user_railroads_path().write_text(text, encoding="utf-8")
    _apply(cleaned)
    return grouped_railroads()


def _csv_text(groups: List[Tuple[str, List[str]]]) -> Tuple[str, List[Tuple[str, List[str]]]]:
    """Every standard group gets a column, even an empty one, so an emptied
    Tourist list stays empty instead of refilling from the shipped file."""
    merged: Dict[str, List[str]] = {}
    for label, names in groups:
        merged.setdefault(label, []).extend(names)
    labels = list(GROUP_ORDER) + [label for label in merged if label not in GROUP_ORDER]
    columns = [(label, merged.get(label, [])) for label in labels]
    rows = [[_CSV_HEADERS.get(label, label) for label in labels]]
    for index in range(max(len(names) for _label, names in columns)):
        rows.append([names[index] if index < len(names) else "" for _label, names in columns])
    buffer = io.StringIO()
    csv.writer(buffer, lineterminator="\n").writerows(rows)
    return buffer.getvalue(), [(label, names) for label, names in columns if names]


def railroads_csv() -> str:
    """The list in effect on this Mac, written the way rr-list.csv is."""
    if not RAILROAD_GROUPS:
        reload_railroads()
    return _csv_text(RAILROAD_GROUPS)[0]


def reset_railroads() -> Dict[str, Any]:
    for path in (user_railroads_path(), user_classes_path()):
        if path.exists():
            path.unlink()
    return reload_railroads()


def is_passenger_railroad(name: str) -> bool:
    if not RAILROAD_GROUPS:
        reload_railroads()
    return (name or "").strip().upper() in PASSENGER_RAILROADS


reload_railroads()
