"""Dashboard stats for the log, subdivisions, railroads, and train types."""
from __future__ import annotations

import re
from collections import defaultdict
from datetime import date as _date
from typing import Any, Dict, List, Optional

import analytics
import railroads as rr_mod
import rrlibrary
import stations as st_mod
from models import DIRECTION_ALIASES, DIRECTIONS
from reference import symbol_stats_parts
from special_power import (
    ERAS,
    POSITIONS,
    STEAM_RUN_LABELS,
    assist_text,
    consist_unit_list,
    doubleheader_partner,
    normalize_special_power,
    steam_run_label,
    steam_runs,
)
from acronyms import list_meanings, reload_acronyms
from train_types import list_type_filters, list_types, reload_type_filters, reload_types

DIRECTION_ORDER = ("North", "East", "South", "West")


def _lead_value(entry: Any) -> str:
    """The lead loco to count. A lead marked Missed, Hidden, Too dark to see, or Too far counts only if it has a number."""
    lead = (getattr(entry, "lead_locomotive", None) or "").strip()
    if getattr(entry, "lead_status", "") and not re.search(r"\d", lead):
        return ""
    return lead


def _direction_label(value: str) -> str:
    raw = (value or "").strip()
    if not raw:
        return ""
    return DIRECTION_ALIASES.get(raw.upper(), raw)


def _type_label(types: List[str]) -> str:
    names = [item for item in (types or []) if item]
    return "/".join(names) if names else "Unknown"


def _ampm(time_str: str) -> str:
    text = (time_str or "").strip()
    if not text or ":" not in text:
        return ""
    try:
        hour = int(text.split(":", 1)[0])
    except ValueError:
        return ""
    if hour < 0 or hour > 23:
        return ""
    return "AM" if hour < 12 else "PM"


ZONE_NAMES = {
    "America/New_York": "Eastern",
    "America/Chicago": "Central",
    "America/Denver": "Mountain",
    "America/Phoenix": "Arizona",
    "America/Los_Angeles": "Pacific",
    "America/Anchorage": "Alaska",
    "Pacific/Honolulu": "Hawaii",
}
WEEKDAYS = ("Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun")
MONTHS = ("Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec")


def _zone_label(zone: str) -> str:
    zone = (zone or "").strip()
    if not zone:
        return "No zone"
    return ZONE_NAMES.get(zone, zone.split("/")[-1].replace("_", " "))


def _hour(time_str: str) -> Optional[int]:
    text = (time_str or "").strip()
    if ":" not in text:
        return None
    try:
        hour = int(text.split(":", 1)[0])
    except ValueError:
        return None
    return hour if 0 <= hour <= 23 else None


def _hour_label(hour: int) -> str:
    suffix = "AM" if hour < 12 else "PM"
    return "{} {}".format(hour % 12 or 12, suffix)


SEASONS = ("Winter", "Spring", "Summer", "Fall")
DAY_PARTS = (
    ("Night", range(0, 6)),
    ("Morning", range(6, 12)),
    ("Afternoon", range(12, 18)),
    ("Evening", range(18, 24)),
)
CAR_BUCKETS = ((1, 24), (25, 49), (50, 74), (75, 99), (100, 124), (125, 149), (150, None))


def _season(month: int) -> str:
    return SEASONS[(month % 12) // 3]


def _car_total(text: str) -> int:
    return sum(int(part) for part in re.findall(r"\d+", text or ""))


def _car_bucket(cars: int) -> str:
    for low, high in CAR_BUCKETS:
        if high is None or cars <= high:
            return "{}+ cars".format(low) if high is None else "{}–{} cars".format(low, high)
    return ""


def _lead_mark(lead: str) -> str:
    match = re.match(r"\s*([A-Za-z]{1,6})\b", lead or "")
    return match.group(1).upper() if match else ""


RR_GROUP_ORDER = ("Freight", "Passenger / Commuter", "Tourist", "Other")


def _rr_class(railroad: str, classes: Dict[str, str]) -> str:
    return classes.get(railroad, "") or "Class not set"


def _rr_group(railroad: str) -> str:
    return rr_mod.group_of(railroad) or "Other"


def _ranked(counter: Dict[str, int], limit: Optional[int] = None) -> List[Dict[str, Any]]:
    rows = [{"name": key, "trains": count} for key, count in counter.items() if key]
    rows.sort(key=lambda item: (-item["trains"], item["name"]))
    if limit is not None:
        return rows[:limit]
    return rows



CON_TRADE_ORDER = ("Overseas", "Domestic", "Overseas and domestic", "CON, trade not marked")
TRAIN_STATUS_FLAGS = (
    ("stopped", "Stopped"),
    ("in_siding", "In siding"),
    ("crew_change", "Crew change"),
    ("no_crew", "No crew"),
)


def _listed_states(text: str) -> set:
    """State codes when the library lists them. "Multiple" is not a list of states."""
    cleaned = (text or "").strip().upper()
    if not re.fullmatch(r"[A-Z]{2}(?:\s*/\s*[A-Z]{2})*", cleaned):
        return set()
    return {part.strip() for part in cleaned.split("/")}


def _lib_field(entry: Any, field: str, index: Optional[Dict[str, Dict[str, Any]]] = None) -> str:
    """One library value for this train. Missing railroads share one bucket, so the train is counted once."""
    rows = index if index is not None else rrlibrary.by_mark()
    row = rows.get(_text(entry, "railroad").upper())
    if row and row.get(field):
        return str(row[field])
    return "Not in the library"


def _con_trade(entry: Any) -> List[str]:
    types = list(getattr(entry, "train_types", None) or [])
    overseas = bool(getattr(entry, "con_overseas", False))
    domestic = bool(getattr(entry, "con_domestic", False))
    if "CON" not in types and not overseas and not domestic:
        return []
    if overseas and domestic:
        return ["Overseas and domestic"]
    if overseas:
        return ["Overseas"]
    if domestic:
        return ["Domestic"]
    return ["CON, trade not marked"]


def _train_status(entry: Any) -> List[str]:
    parts = [label for attr, label in TRAIN_STATUS_FLAGS if getattr(entry, attr, False)]
    return [", ".join(parts)] if parts else []


def _ordered_count(counter: Dict[str, int], order: tuple) -> List[str]:
    names = [name for name in order if counter.get(name)]
    names.extend(sorted(name for name in counter if name not in order and counter[name]))
    return names


def log_stats(entries: Optional[List[Any]] = None, all_entries: Optional[List[Any]] = None) -> Dict[str, Any]:
    entries = entries or []
    grouped = rr_mod.grouped_railroads()
    lib_index = rrlibrary.by_mark()
    unknown_marks = set()
    outside_states = 0
    region_counts: Dict[str, int] = defaultdict(int)
    operation_counts: Dict[str, int] = defaultdict(int)
    con_counts: Dict[str, int] = defaultdict(int)
    lead_condition_counts: Dict[str, int] = defaultdict(int)
    train_status_counts: Dict[str, int] = defaultdict(int)
    rr_counts: Dict[str, int] = defaultdict(int)
    type_counts: Dict[str, int] = defaultdict(int)
    dir_counts: Dict[str, int] = defaultdict(int)
    loc_counts: Dict[str, int] = defaultdict(int)
    sub_counts: Dict[str, int] = defaultdict(int)
    lead_counts: Dict[str, int] = defaultdict(int)
    consist_counts: Dict[str, int] = defaultdict(int)
    ampm_counts: Dict[str, int] = defaultdict(int)
    load_counts: Dict[str, int] = defaultdict(int)
    trip_counts: Dict[str, int] = defaultdict(int)
    rr_atomic: Dict[str, Dict[str, int]] = defaultdict(lambda: defaultdict(int))
    rr_combined: Dict[str, Dict[str, int]] = defaultdict(lambda: defaultdict(int))
    days = set()
    photos = 0
    videos = 0
    both_media = 0
    night = 0
    lead_missed = 0
    stopped = 0
    in_siding = 0
    crew_change = 0
    no_crew = 0
    notes = 0
    zone_counts: Dict[str, int] = defaultdict(int)
    hour_counts: Dict[int, int] = defaultdict(int)
    weekday_counts: Dict[int, int] = defaultdict(int)
    month_counts: Dict[int, int] = defaultdict(int)
    year_counts: Dict[str, int] = defaultdict(int)
    day_counts: Dict[str, int] = defaultdict(int)
    unit_counts: Dict[int, int] = defaultdict(int)
    dp_counts: Dict[str, int] = defaultdict(int)
    zones_by_day: Dict[str, List[Any]] = defaultdict(list)
    state_counts: Dict[str, int] = defaultdict(int)
    symbol_counts: Dict[str, int] = defaultdict(int)
    symbol_series_counts: Dict[str, int] = defaultdict(int)
    symbol_lane_counts: Dict[str, int] = defaultdict(int)
    symbol_origin_counts: Dict[str, int] = defaultdict(int)
    symbol_dest_counts: Dict[str, int] = defaultdict(int)
    symbol_check_counts: Dict[str, int] = defaultdict(int)
    symbol_road_counts: Dict[str, int] = defaultdict(int)
    passenger_counts: Dict[str, int] = defaultdict(int)
    heritage_scheme_counts: Dict[str, int] = defaultdict(int)
    heritage_era_counts: Dict[str, int] = defaultdict(int)
    heritage_unit_counts: Dict[str, int] = defaultdict(int)
    heritage_position_counts: Dict[str, int] = defaultdict(int)
    heritage_road_counts: Dict[str, int] = defaultdict(int)
    steam_engine_counts: Dict[str, int] = defaultdict(int)
    steam_wheel_counts: Dict[str, int] = defaultdict(int)
    steam_state_counts: Dict[str, int] = defaultdict(int)
    special_sightings: List[Dict[str, Any]] = []
    heritage_trains = 0
    steam_trains = 0
    steam_run_counts: Dict[str, int] = defaultdict(int)
    assist_diesel_counts: Dict[str, int] = defaultdict(int)
    consist_unit_counts: Dict[str, int] = defaultdict(int)
    noted_unit_trains = 0
    car_bucket_counts: Dict[str, int] = defaultdict(int)
    season_counts: Dict[str, int] = defaultdict(int)
    lead_mark_counts: Dict[str, int] = defaultdict(int)
    lead_power = {"Home road leading": 0, "Foreign power leading": 0}
    car_totals: List[Any] = []
    for entry in entries:
        state = (getattr(entry, "location_state", None) or "").strip().upper()
        if state:
            state_counts[state] += 1
        symbol = (getattr(entry, "train_symbol", None) or "").strip().upper()
        if symbol:
            symbol_rr = (getattr(entry, "railroad", "") or "").strip()
            parts = symbol_stats_parts(symbol_rr, symbol)
            symbol_counts[parts["base"]] += 1
            symbol_check_counts[parts["check"]] += 1
            symbol_road_counts[symbol_rr or "Unknown"] += 1
            if parts["series"]:
                symbol_series_counts[parts["series"]] += 1
            if parts["origin"]:
                symbol_origin_counts[parts["origin"]] += 1
            if parts["destination"]:
                symbol_dest_counts[parts["destination"]] += 1
            if parts["origin"] and parts["destination"]:
                symbol_lane_counts["{} → {}".format(parts["origin"], parts["destination"])] += 1
        special = normalize_special_power(getattr(entry, "special_power", None) or "")
        noted_units = consist_unit_list(special)
        if noted_units:
            noted_unit_trains += 1
        for unit in noted_units:
            consist_unit_counts[unit] += 1
        for run in steam_runs(special["steam"]):
            steam_run_counts[steam_run_label(run)] += 1
            for unit in run[0].get("assist") or []:
                assist_diesel_counts[unit] += 1
        if special["heritage"] or special["steam"]:
            where = {
                "date": getattr(entry, "date", "") or "",
                "time": getattr(entry, "time", "") or "",
                "railroad": (getattr(entry, "railroad", "") or "").strip(),
                "location": (getattr(entry, "location_spot", "") or "").strip(),
                "state": (getattr(entry, "location_state", "") or "").strip().upper(),
                "id": getattr(entry, "id", None),
            }
            if special["heritage"]:
                heritage_trains += 1
            if special["steam"]:
                steam_trains += 1
            for item in special["heritage"]:
                scheme = item["scheme"] or "Scheme not given"
                heritage_scheme_counts[scheme] += 1
                if item["era"] == "a250":
                    heritage_era_counts["America 250"] += 1
                heritage_position_counts[POSITIONS.get(item["position"], "Position not given")] += 1
                unit = item["unit"] or "Unit not given"
                heritage_unit_counts["{} · {}".format(unit, item["scheme"]) if item["unit"] and item["scheme"] else unit] += 1
                if item["unit"]:
                    heritage_road_counts[item["unit"].split(" ")[0]] += 1
                detail = ", ".join(p for p in (item["scheme"], ERAS.get(item["era"], ""), POSITIONS.get(item["position"], "")) if p)
                special_sightings.append(dict(where, kind="Heritage", unit=item["unit"], detail=detail))
            for index, item in enumerate(special["steam"]):
                label = " ".join(p for p in (item["engine"], item["name"]) if p) or "Engine not given"
                steam_engine_counts[label] += 1
                steam_wheel_counts[item["wheels"] or "Not given"] += 1
                if where["state"]:
                    steam_state_counts[where["state"]] += 1
                partner = doubleheader_partner(special["steam"], index)
                paired = "doubleheader with " + partner if partner else ""
                detail = ", ".join(p for p in (item["name"], item["wheels"], paired, assist_text(item)) if p)
                special_sightings.append(dict(where, kind="Steam", unit=item["engine"], detail=detail))
        train_no = (getattr(entry, "train_number", None) or "").strip().upper()
        if train_no:
            rr = (getattr(entry, "railroad", "") or "").strip()
            passenger_counts["{} #{}".format(rr, train_no) if rr else "#" + train_no] += 1
        cars = _car_total(getattr(entry, "car_counts", "") or "")
        if cars:
            car_bucket_counts[_car_bucket(cars)] += 1
            car_totals.append((cars, getattr(entry, "date", "") or "", (getattr(entry, "railroad", "") or "").strip()))
        mark = _lead_mark(getattr(entry, "lead_locomotive", "") or "")
        if mark:
            lead_mark_counts[mark] += 1
            home = (getattr(entry, "railroad", "") or "").strip().upper()
            if home:
                lead_power["Home road leading" if mark == home else "Foreign power leading"] += 1
        zone = (getattr(entry, "time_zone", None) or "").strip()
        zone_counts[_zone_label(zone)] += 1
        hour = _hour(getattr(entry, "time", "") or "")
        if hour is not None:
            hour_counts[hour] += 1
        entry_date = getattr(entry, "date", None) or ""
        if entry_date:
            day_counts[entry_date] += 1
            year_counts[entry_date[:4]] += 1
            try:
                parsed = _date.fromisoformat(entry_date)
                weekday_counts[parsed.weekday()] += 1
                month_counts[parsed.month] += 1
                season_counts[_season(parsed.month)] += 1
            except ValueError:
                pass
            zones_by_day[entry_date].append((getattr(entry, "id", 0) or 0, zone))
        consist_parts = [p for p in str(getattr(entry, "power_consist", "") or "").split("x") if p.isdigit()]
        if consist_parts:
            unit_counts[int(consist_parts[0])] += 1
            helpers = sum(int(p) for p in consist_parts[1:])
            dp_counts["With helpers / DP" if helpers else "No helpers / DP"] += 1
        railroad = (getattr(entry, "railroad", None) or "Unknown").strip() or "Unknown"
        region_counts[_lib_field(entry, "region", lib_index)] += 1
        operation_counts[_lib_field(entry, "operation", lib_index)] += 1
        lib = lib_index.get(railroad.upper())
        if lib:
            listed = _listed_states(lib.get("states") or "")
            if listed and state and state not in listed:
                outside_states += 1
        elif railroad != "Unknown":
            unknown_marks.add(railroad.upper())
        for label in _con_trade(entry):
            con_counts[label] += 1
        lead_label = (getattr(entry, "lead_status", "") or "").strip()
        if lead_label:
            lead_condition_counts[lead_label] += 1
        for label in _train_status(entry):
            train_status_counts[label] += 1
        types = list(getattr(entry, "train_types", None) or [])
        combined = _type_label(types)
        rr_counts[railroad] += 1
        type_counts[combined] += 1
        rr_combined[railroad][combined] += 1
        for name in types:
            if name:
                rr_atomic[railroad][name] += 1
        direction = _direction_label(getattr(entry, "direction", "") or "")
        if direction in DIRECTIONS:
            dir_counts[direction] += 1
        location = (getattr(entry, "location_spot", None) or "").strip() or "Unknown"
        loc_counts[location] += 1
        subdivision = (getattr(entry, "location_subdivision", None) or "").strip()
        if subdivision:
            sub_counts[subdivision] += 1
        lead = _lead_value(entry)
        if lead:
            lead_counts[lead] += 1
        consist = (getattr(entry, "power_consist", None) or "").strip()
        if consist:
            consist_counts[consist] += 1
        period = _ampm(getattr(entry, "time", "") or "")
        if period:
            ampm_counts[period] += 1
        date = getattr(entry, "date", None) or ""
        if date:
            days.add(date)
        photo = bool(getattr(entry, "photographed", False))
        video = bool(getattr(entry, "videoed", False))
        if photo:
            photos += 1
        if video:
            videos += 1
        if photo and video:
            both_media += 1
        if getattr(entry, "night", False):
            night += 1
        if getattr(entry, "lead_status", ""):
            lead_missed += 1
        if getattr(entry, "stopped", False):
            stopped += 1
        if getattr(entry, "in_siding", False):
            in_siding += 1
        if getattr(entry, "crew_change", False):
            crew_change += 1
        if getattr(entry, "no_crew", False):
            no_crew += 1
        if (getattr(entry, "notes", None) or "").strip():
            notes += 1
        load_parts = [
            part for part in str(getattr(entry, "load_status", None) or "").split("/") if part
        ]
        has_loads = "Loads" in load_parts
        has_empties = "Empties" in load_parts
        if has_loads and has_empties:
            load_counts["Loads/Empties"] += 1
        elif has_loads:
            load_counts["Loads"] += 1
        elif has_empties:
            load_counts["Empties"] += 1
        else:
            load_counts["Unknown"] += 1
        trip = (getattr(entry, "trip_name", None) or "").strip()
        if trip:
            trip_counts[trip] += 1

    def type_rows(counter: Dict[str, int]) -> List[Dict[str, Any]]:
        return [
            {"type": name, "trains": count}
            for name, count in sorted(counter.items(), key=lambda item: (-item[1], item[0]))
        ]

    railroad_rows: List[Dict[str, Any]] = []
    known = set()
    for group in grouped["groups"]:
        for name in group["railroads"]:
            known.add(name)
            railroad_rows.append(
                {
                    "railroad": name,
                    "group": group["label"],
                    "trains": rr_counts.get(name, 0),
                    "types": type_rows(rr_atomic.get(name, {})),
                }
            )
    for name in sorted(set(rr_counts) - known):
        railroad_rows.append(
            {
                "railroad": name,
                "group": "Other",
                "trains": rr_counts[name],
                "types": type_rows(rr_atomic.get(name, {})),
            }
        )
    dates = sorted(days)
    zone_change_days = 0
    zone_changes = 0
    for items in zones_by_day.values():
        last = None
        changed = False
        for _id, zone in sorted(items):
            if not zone:
                continue
            if last is not None and zone != last:
                zone_changes += 1
                changed = True
            last = zone
        if changed:
            zone_change_days += 1
    busiest = sorted(day_counts.items(), key=lambda item: (-item[1], item[0]))
    span_days = 0
    if dates:
        try:
            span_days = (_date.fromisoformat(dates[-1]) - _date.fromisoformat(dates[0])).days + 1
        except ValueError:
            span_days = 0
    numbered_leads = {k: v for k, v in lead_counts.items() if re.search(r"\d", k)}
    classes = rr_mod.railroad_classes()
    class_counts: Dict[str, int] = defaultdict(int)
    group_counts: Dict[str, int] = defaultdict(int)
    for name, count in rr_counts.items():
        class_counts[_rr_class(name, classes)] += count
        group_counts[_rr_group(name)] += count
    month_line: Dict[str, int] = defaultdict(int)
    for day, count in sorted(day_counts.items()):
        label = analytics.month_label(day)
        if label:
            month_line[label] += count
    unit_trains = sum(unit_counts.values())
    facts = [
        {"name": "Days trackside", "value": str(len(days))},
        {"name": "Average trains per day trackside", "value": "{:.1f}".format(len(entries) / len(days)) if days else "0"},
        {"name": "Most trains in one day", "value": "{} on {}".format(busiest[0][1], busiest[0][0]) if busiest else "—"},
        {"name": "Busiest hour", "value": _hour_label(max(hour_counts, key=lambda h: (hour_counts[h], -h))) if hour_counts else "—"},
        {"name": "Days spanned, first to last", "value": str(span_days)},
        {"name": "Trains with a time zone set", "value": str(len(entries) - zone_counts.get("No zone", 0))},
        {"name": "Days with a time zone change", "value": str(zone_change_days)},
        {"name": "Time zone changes logged", "value": str(zone_changes)},
        {"name": "States", "value": str(len(state_counts))},
        {"name": "Logged railroads not in the library", "value": str(len(unknown_marks))},
        {"name": "Trains seen outside the railroad's listed states", "value": str(outside_states)},
        {"name": "Trains with a symbol", "value": str(sum(symbol_counts.values()))},
        {"name": "Most-seen symbol", "value": "{} ({})".format(*max(symbol_counts.items(), key=lambda kv: (kv[1], kv[0]))) if symbol_counts else "—"},
        {"name": "Different symbols seen", "value": str(len(symbol_counts))},
        {"name": "Symbol lanes seen", "value": str(len(symbol_lane_counts))},
        {"name": "Trains with a heritage unit", "value": str(heritage_trains)},
        {"name": "Heritage units seen", "value": str(len([k for k in heritage_unit_counts if k != "Unit not given"]))},
        {"name": "Most-seen heritage unit", "value": "{} ({})".format(*max(heritage_unit_counts.items(), key=lambda kv: (kv[1], kv[0]))) if heritage_unit_counts else "—"},
        {"name": "Steam sightings", "value": str(steam_trains)},
        {"name": "Steam engines seen", "value": str(len([k for k in steam_engine_counts if k != "Engine not given"]))},
        {"name": "Steam doubleheaders", "value": str(steam_run_counts["Doubleheader"] + steam_run_counts["Doubleheader with diesel assist"])},
        {"name": "Steam with diesel assist", "value": str(steam_run_counts["Single engine with diesel assist"] + steam_run_counts["Doubleheader with diesel assist"])},
        {"name": "Trains with unit numbers noted", "value": str(noted_unit_trains)},
        {"name": "Trailing and DP units seen", "value": str(len(consist_unit_counts))},
        {"name": "Most-seen passenger train", "value": "{} ({})".format(*max(passenger_counts.items(), key=lambda kv: (kv[1], kv[0]))) if passenger_counts else "—"},
        {"name": "Average cars (when counted)", "value": "{:.0f}".format(sum(c[0] for c in car_totals) / len(car_totals)) if car_totals else "—"},
        {"name": "Longest train", "value": "{} cars on {}".format(*max(car_totals, key=lambda c: (c[0], c[1]))[:2]) if car_totals else "—"},
        {"name": "Average units on the head end", "value": "{:.1f}".format(sum(n * c for n, c in unit_counts.items()) / unit_trains) if unit_trains else "—"},
        {"name": "Foreign power leading", "value": str(lead_power["Foreign power leading"])},
        {"name": "Leads missed, hidden, too dark, or too far", "value": str(lead_missed)},
        {"name": "Night sightings", "value": str(night)},
        {"name": "Stopped", "value": str(stopped)},
        {"name": "In siding", "value": str(in_siding)},
        {"name": "Crew changes", "value": str(crew_change)},
        {"name": "No crew onboard", "value": str(no_crew)},
        {"name": "Most-seen lead loco", "value": "{} ({})".format(*max(numbered_leads.items(), key=lambda kv: (kv[1], kv[0]))) if numbered_leads else "—"},
        {"name": "Busiest weekday", "value": WEEKDAYS[max(weekday_counts, key=lambda d: (weekday_counts[d], -d))] if weekday_counts else "—"},
        {"name": "Busiest location", "value": _ranked({k: v for k, v in loc_counts.items() if k != "Unknown"})[0]["name"] if any(k != "Unknown" for k in loc_counts) else "—"},
    ]
    extra = analytics.extra_stats(entries, sorted(days), all_entries)
    facts.extend(extra.pop("extra_facts"))
    return {
        **extra,
        "totals": {
            "trains": len(entries),
            "days": len(days),
            "photos": photos,
            "videos": videos,
            "both_media": both_media,
            "night": night,
            "stopped": stopped,
            "in_siding": in_siding,
            "crew_change": crew_change,
            "no_crew": no_crew,
            "notes": notes,
            "unique_locations": len(loc_counts),
            "unique_subdivisions": len(sub_counts),
            "unique_leads": len(lead_counts),
            "unique_consists": len(consist_counts),
            "unique_railroads": len(rr_counts),
            "unique_types": len(type_counts),
            "unique_trips": len(trip_counts),
            "am": ampm_counts.get("AM", 0),
            "pm": ampm_counts.get("PM", 0),
            "loads": load_counts.get("Loads", 0) + load_counts.get("Loads/Empties", 0),
            "empties": load_counts.get("Empties", 0) + load_counts.get("Loads/Empties", 0),
            "loads_empties": load_counts.get("Loads/Empties", 0),
            "unknown_load": load_counts.get("Unknown", 0),
            "media": photos + videos - both_media,
            "first_date": dates[0] if dates else "",
            "last_date": dates[-1] if dates else "",
        },
        "railroads": railroad_rows,
        "types": type_rows(type_counts),
        "types_by_railroad": [
            {"railroad": name, "types": type_rows(counter)}
            for name, counter in sorted(rr_combined.items())
        ],
        "directions": [
            {"direction": name, "trains": dir_counts.get(name, 0)} for name in DIRECTION_ORDER
        ],
        "locations": [
            {"location": row["name"], "trains": row["trains"]} for row in _ranked(loc_counts)
        ],
        "subdivisions": [
            {"subdivision": row["name"], "trains": row["trains"]} for row in _ranked(sub_counts)
        ],
        "leads": [{"lead": row["name"], "trains": row["trains"]} for row in _ranked(lead_counts)],
        "consists": [
            {"consist": row["name"], "trains": row["trains"]} for row in _ranked(consist_counts)
        ],
        "ampm": [
            {"period": "AM", "trains": ampm_counts.get("AM", 0)},
            {"period": "PM", "trains": ampm_counts.get("PM", 0)},
        ],
        "loads": [
            {"status": name, "trains": load_counts.get(name, 0)}
            for name in ("Loads", "Empties", "Loads/Empties", "Unknown")
            if load_counts.get(name, 0)
        ],
        "media": [
            {"name": name, "trains": count}
            for name, count in (
                ("Photo", photos),
                ("Video", videos),
                ("Photo and video", both_media),
                ("Night", night),
                ("Notes", notes),
            )
            if count
        ],
        "trips": [{"trip": row["name"], "trains": row["trains"]} for row in _ranked(trip_counts)],
        "time_zones": [{"zone": row["name"], "trains": row["trains"]} for row in _ranked(zone_counts)],
        "hours": [{"hour": _hour_label(h), "trains": hour_counts[h]} for h in range(24) if hour_counts.get(h)],
        "weekdays": [{"day": WEEKDAYS[i], "trains": weekday_counts.get(i, 0)} for i in range(7)],
        "months": [{"month": MONTHS[i - 1], "trains": month_counts[i]} for i in range(1, 13) if month_counts.get(i)],
        "years": [{"year": y, "trains": year_counts[y]} for y in sorted(year_counts)],
        "busiest_days": [{"day": d, "trains": n} for d, n in busiest[:10]],
        "units": [
            {"units": "{} unit{}".format(n, "" if n == 1 else "s"), "trains": unit_counts[n]}
            for n in sorted(unit_counts)
        ],
        "dp": [{"name": k, "trains": v} for k, v in sorted(dp_counts.items(), key=lambda item: -item[1])],
        "states": [{"state": row["name"], "trains": row["trains"]} for row in _ranked(state_counts)],
        "symbols": [{"symbol": row["name"], "trains": row["trains"]} for row in _ranked(symbol_counts)],
        "symbol_series": [{"series": row["name"], "trains": row["trains"]} for row in _ranked(symbol_series_counts)],
        "symbol_lanes": [{"lane": row["name"], "trains": row["trains"]} for row in _ranked(symbol_lane_counts)],
        "symbol_origins": [{"origin": row["name"], "trains": row["trains"]} for row in _ranked(symbol_origin_counts)],
        "symbol_destinations": [{"destination": row["name"], "trains": row["trains"]} for row in _ranked(symbol_dest_counts)],
        "symbol_roads": [{"railroad": row["name"], "trains": row["trains"]} for row in _ranked(symbol_road_counts)],
        "symbol_check": [
            {"name": name, "trains": symbol_check_counts[name]}
            for name in ("In the symbol list", "Not in the symbol list", "No symbol list for this railroad")
            if symbol_check_counts.get(name)
        ],
        "passenger_trains": [{"train": row["name"], "trains": row["trains"]} for row in _ranked(passenger_counts)],
        "heritage_schemes": [{"scheme": row["name"], "trains": row["trains"]} for row in _ranked(heritage_scheme_counts)],
        "heritage_eras": [
            {"era": "America 250", "trains": heritage_era_counts["America 250"]}
        ] if heritage_era_counts.get("America 250") else [],
        "heritage_units": [{"unit": row["name"], "trains": row["trains"]} for row in _ranked(heritage_unit_counts)],
        "heritage_positions": [
            {"position": name, "trains": heritage_position_counts[name]}
            for name in ("Leading", "Trailing", "DP", "Steam assist", "Position not given")
            if heritage_position_counts.get(name)
        ],
        "heritage_roads": [{"railroad": row["name"], "trains": row["trains"]} for row in _ranked(heritage_road_counts)],
        "steam_engines": [{"engine": row["name"], "trains": row["trains"]} for row in _ranked(steam_engine_counts)],
        "steam_wheels": [{"wheels": row["name"], "trains": row["trains"]} for row in _ranked(steam_wheel_counts)],
        "steam_states": [{"state": row["name"], "trains": row["trains"]} for row in _ranked(steam_state_counts)],
        "steam_runs": [{"name": name, "trains": steam_run_counts[name]} for name in STEAM_RUN_LABELS if steam_run_counts.get(name)],
        "assist_diesels": [{"unit": row["name"], "trains": row["trains"]} for row in _ranked(assist_diesel_counts)],
        "consist_units": [{"unit": row["name"], "trains": row["trains"]} for row in _ranked(consist_unit_counts)],
        "special_sightings": sorted(special_sightings, key=lambda row: (row["date"], row["time"]), reverse=True),
        "directions_more": [
            {"direction": name, "trains": dir_counts[name]} for name in DIRECTION_ORDER if dir_counts.get(name)
        ],
        "car_lengths": [
            {"cars": label, "trains": car_bucket_counts[label]}
            for label in (_car_bucket(low) for low, _high in CAR_BUCKETS)
            if car_bucket_counts.get(label)
        ],
        "seasons": [{"season": name, "trains": season_counts[name]} for name in SEASONS if season_counts.get(name)],
        "day_parts": [
            {"part": label, "trains": sum(hour_counts.get(h, 0) for h in hours)}
            for label, hours in DAY_PARTS
            if any(hour_counts.get(h) for h in hours)
        ],
        "lead_marks": [{"mark": row["name"], "trains": row["trains"]} for row in _ranked(lead_mark_counts)],
        "lead_power": [{"name": k, "trains": v} for k, v in lead_power.items() if v],
        "railroad_classes": [{"class": row["name"], "trains": row["trains"]} for row in _ranked(class_counts)],
        "railroad_groups": [
            {"group": name, "trains": group_counts[name]}
            for name in sorted(group_counts, key=lambda n: (RR_GROUP_ORDER.index(n) if n in RR_GROUP_ORDER else len(RR_GROUP_ORDER), n))
        ],
        "railroad_regions": [
            {"region": name, "trains": region_counts[name]}
            for name in _ordered_count(region_counts, rrlibrary.REGIONS + ("Not in the library",))
        ],
        "railroad_operations": [
            {"operation": row["name"], "trains": row["trains"]} for row in _ranked(operation_counts)
        ],
        "con_trade": [
            {"trade": name, "trains": con_counts[name]} for name in _ordered_count(con_counts, CON_TRADE_ORDER)
        ],
        "lead_conditions": [
            {"status": row["name"], "trains": row["trains"]} for row in _ranked(lead_condition_counts)
        ],
        "train_status": [
            {"status": row["name"], "trains": row["trains"]} for row in _ranked(train_status_counts)
        ],
        "trains_by_date": [{"day": d, "trains": n} for d, n in sorted(day_counts.items())],
        "trains_by_month": [{"month": label, "trains": n} for label, n in month_line.items()],
        "facts": facts,
        "span": {
            "trains": len(entries),
            "first_date": dates[0] if dates else "",
            "last_date": dates[-1] if dates else "",
        },
    }


def _text(entry: Any, field: str) -> str:
    return (getattr(entry, field, None) or "").strip()


def _entry_date(entry: Any) -> Optional[_date]:
    try:
        return _date.fromisoformat(_text(entry, "date"))
    except ValueError:
        return None


def _one(value: str) -> List[str]:
    return [value] if value else []


def _cmp_hour(entry: Any, _ctx: Dict[str, Any]) -> List[str]:
    hour = _hour(_text(entry, "time"))
    return [] if hour is None else [_hour_label(hour)]


def _cmp_part(entry: Any, _ctx: Dict[str, Any]) -> List[str]:
    hour = _hour(_text(entry, "time"))
    if hour is None:
        return []
    return [label for label, hours in DAY_PARTS if hour in hours]


def _cmp_weekday(entry: Any, _ctx: Dict[str, Any]) -> List[str]:
    parsed = _entry_date(entry)
    return [WEEKDAYS[parsed.weekday()]] if parsed else []


def _cmp_month(entry: Any, _ctx: Dict[str, Any]) -> List[str]:
    parsed = _entry_date(entry)
    return [MONTHS[parsed.month - 1]] if parsed else []


def _cmp_season(entry: Any, _ctx: Dict[str, Any]) -> List[str]:
    parsed = _entry_date(entry)
    return [_season(parsed.month)] if parsed else []


def _cmp_lead_power(entry: Any, _ctx: Dict[str, Any]) -> List[str]:
    mark = _lead_mark(_text(entry, "lead_locomotive"))
    home = _text(entry, "railroad").upper()
    if not mark or not home:
        return []
    return ["Home road leading" if mark == home else "Foreign power leading"]


def _cmp_units(entry: Any, _ctx: Dict[str, Any]) -> List[str]:
    parts = [p for p in _text(entry, "power_consist").split("x") if p.isdigit()]
    if not parts:
        return []
    n = int(parts[0])
    return ["{} unit{}".format(n, "" if n == 1 else "s")]


def _cmp_dp(entry: Any, _ctx: Dict[str, Any]) -> List[str]:
    parts = [p for p in _text(entry, "power_consist").split("x") if p.isdigit()]
    if not parts:
        return []
    return ["With helpers / DP" if sum(int(p) for p in parts[1:]) else "No helpers / DP"]


def _cmp_cars(entry: Any, _ctx: Dict[str, Any]) -> List[str]:
    cars = _car_total(_text(entry, "car_counts"))
    return [_car_bucket(cars)] if cars else []


def _cmp_loads(entry: Any, _ctx: Dict[str, Any]) -> List[str]:
    parts = [p for p in _text(entry, "load_status").split("/") if p]
    if "Loads" in parts and "Empties" in parts:
        return ["Loads/Empties"]
    return [p for p in parts if p in ("Loads", "Empties")][:1]


def _cmp_media(entry: Any, _ctx: Dict[str, Any]) -> List[str]:
    photo = bool(getattr(entry, "photographed", False))
    video = bool(getattr(entry, "videoed", False))
    if photo and video:
        return ["Photo and video"]
    if photo:
        return ["Photo"]
    if video:
        return ["Video"]
    return ["No photo or video"]


def _cmp_class(entry: Any, ctx: Dict[str, Any]) -> List[str]:
    return _one(ctx["classes"].get(_text(entry, "railroad"), ""))


def _cmp_region(entry: Any, ctx: Dict[str, Any]) -> List[str]:
    return [_lib_field(entry, "region", ctx.get("library"))]


def _cmp_operation(entry: Any, ctx: Dict[str, Any]) -> List[str]:
    return [_lib_field(entry, "operation", ctx.get("library"))]


def _cmp_special(entry: Any, _ctx: Dict[str, Any]) -> List[str]:
    special = normalize_special_power(getattr(entry, "special_power", None) or "")
    out = []
    if special["heritage"]:
        out.append("Heritage unit")
    if special["steam"]:
        out.append("Steam")
    return out


COMPARE_DIMENSIONS: List[Dict[str, Any]] = [
    {"key": "railroad", "label": "Railroad", "group": "Trains", "fn": lambda e, c: _one(_text(e, "railroad"))},
    {"key": "rrclass", "label": "Railroad Class", "group": "Trains", "fn": _cmp_class, "order": rr_mod.ALL_CLASSES},
    {"key": "rrregion", "label": "Railroad Region", "group": "Where", "fn": _cmp_region, "order": rrlibrary.REGIONS + ("Not in the library",)},
    {"key": "rroperation", "label": "Operation", "group": "Trains", "fn": _cmp_operation},
    {"key": "contrade", "label": "Container Trade", "group": "Trains", "fn": lambda e, c: _con_trade(e), "order": CON_TRADE_ORDER},
    {"key": "type", "label": "Train Type", "group": "Trains", "fn": lambda e, c: [t for t in (getattr(e, "train_types", None) or []) if t], "multi": True},
    {"key": "direction", "label": "Direction", "group": "Trains", "fn": lambda e, c: [d for d in _one(_direction_label(_text(e, "direction"))) if d in DIRECTIONS], "order": DIRECTION_ORDER},
    {"key": "loads", "label": "Loads / Empties", "group": "Trains", "fn": _cmp_loads, "order": ("Loads", "Empties", "Loads/Empties")},
    {"key": "cars", "label": "Train Length", "group": "Trains", "fn": _cmp_cars, "order": tuple(_car_bucket(low) for low, _high in CAR_BUCKETS)},
    {"key": "location", "label": "Location", "group": "Where", "fn": lambda e, c: _one(_text(e, "location_spot"))},
    {"key": "subdivision", "label": "Subdivision", "group": "Where", "fn": lambda e, c: _one(_text(e, "location_subdivision"))},
    {"key": "state", "label": "State", "group": "Where", "fn": lambda e, c: _one(_text(e, "location_state").upper())},
    {"key": "zone", "label": "Time Zone", "group": "Where", "fn": lambda e, c: _one(_zone_label(_text(e, "time_zone")) if _text(e, "time_zone") else "")},
    {"key": "trip", "label": "Trip", "group": "Where", "fn": lambda e, c: _one(_text(e, "trip_name"))},
    {"key": "hour", "label": "Hour of Day", "group": "When", "fn": _cmp_hour, "order": tuple(_hour_label(h) for h in range(24))},
    {"key": "part", "label": "Time of Day", "group": "When", "fn": _cmp_part, "order": tuple(label for label, _hours in DAY_PARTS)},
    {"key": "ampm", "label": "AM / PM", "group": "When", "fn": lambda e, c: _one(_ampm(_text(e, "time"))), "order": ("AM", "PM")},
    {"key": "weekday", "label": "Day of Week", "group": "When", "fn": _cmp_weekday, "order": WEEKDAYS},
    {"key": "month", "label": "Month", "group": "When", "fn": _cmp_month, "order": MONTHS},
    {"key": "season", "label": "Season", "group": "When", "fn": _cmp_season, "order": SEASONS},
    {"key": "year", "label": "Year", "group": "When", "fn": lambda e, c: _one(_text(e, "date")[:4]), "natural": True},
    {"key": "leadmark", "label": "Lead Loco Railroad", "group": "Power", "fn": lambda e, c: _one(_lead_mark(_text(e, "lead_locomotive")))},
    {"key": "leadpower", "label": "Home vs Foreign Power", "group": "Power", "fn": _cmp_lead_power, "order": ("Home road leading", "Foreign power leading")},
    {"key": "units", "label": "Units on the Head End", "group": "Power", "fn": _cmp_units, "numeric": True},
    {"key": "dp", "label": "Helpers / DP", "group": "Power", "fn": _cmp_dp, "order": ("No helpers / DP", "With helpers / DP")},
    {"key": "special", "label": "Heritage / Steam", "group": "Power", "fn": _cmp_special, "order": ("Heritage unit", "Steam"), "multi": True},
    {"key": "media", "label": "Photo / Video", "group": "Media", "fn": _cmp_media, "order": ("Photo", "Video", "Photo and video", "No photo or video")},
]
_COMPARE_BY_KEY = {dim["key"]: dim for dim in COMPARE_DIMENSIONS}


def compare_dimensions() -> List[Dict[str, str]]:
    return [{"key": d["key"], "label": d["label"], "group": d["group"]} for d in COMPARE_DIMENSIONS]


def _compare_ctx() -> Dict[str, Any]:
    return {"classes": rr_mod.railroad_classes(), "library": rrlibrary.by_mark()}


def _ordered(dim: Dict[str, Any], totals: Dict[str, int]) -> List[str]:
    names = [name for name in totals if name]
    if dim.get("order"):
        rank = {name: i for i, name in enumerate(dim["order"])}
        return sorted(names, key=lambda n: (rank.get(n, len(rank)), n))
    if dim.get("natural"):
        return sorted(names)
    if dim.get("numeric"):
        return sorted(names, key=lambda n: int(re.match(r"\d+", n).group(0)) if re.match(r"\d+", n) else 0)
    return sorted(names, key=lambda n: (-totals[n], n))


def _ranked_dim(dim: Dict[str, Any]) -> bool:
    return not (dim.get("order") or dim.get("natural") or dim.get("numeric"))


def compare_grid(entries: List[Any], rows: str, cols: str, limit: int = 12) -> Dict[str, Any]:
    """Count trains for every pair of values in two dimensions, such as hour of day by railroad."""
    row_dim = _COMPARE_BY_KEY.get(rows)
    col_dim = _COMPARE_BY_KEY.get(cols)
    if not row_dim or not col_dim:
        raise ValueError("Pick something to compare.")
    if rows == cols:
        raise ValueError("Pick two different things to compare.")
    limit = max(1, min(int(limit or 12), 40))
    ctx = _compare_ctx()
    cells: Dict[str, Dict[str, int]] = defaultdict(lambda: defaultdict(int))
    row_totals: Dict[str, int] = defaultdict(int)
    col_totals: Dict[str, int] = defaultdict(int)
    counted = 0
    skipped = 0
    for entry in entries:
        rvals = list(dict.fromkeys(row_dim["fn"](entry, ctx)))
        cvals = list(dict.fromkeys(col_dim["fn"](entry, ctx)))
        if not rvals or not cvals:
            skipped += 1
            continue
        counted += 1
        for r in rvals:
            row_totals[r] += 1
            for c in cvals:
                cells[r][c] += 1
        for c in cvals:
            col_totals[c] += 1
    row_names = _ordered(row_dim, row_totals)
    col_names = _ordered(col_dim, col_totals)
    more_rows = more_cols = 0
    if _ranked_dim(row_dim) and len(row_names) > limit:
        more_rows = len(row_names) - limit
        row_names = row_names[:limit]
    if _ranked_dim(col_dim) and len(col_names) > limit:
        more_cols = len(col_names) - limit
        col_names = col_names[:limit]
    return {
        "rows": {"key": rows, "label": row_dim["label"], "names": row_names, "totals": [row_totals[n] for n in row_names], "more": more_rows, "multi": bool(row_dim.get("multi"))},
        "cols": {"key": cols, "label": col_dim["label"], "names": col_names, "totals": [col_totals[n] for n in col_names], "more": more_cols, "multi": bool(col_dim.get("multi"))},
        "cells": [[cells[r].get(c, 0) for c in col_names] for r in row_names],
        "max": max([cells[r].get(c, 0) for r in row_names for c in col_names] or [0]),
        "counted": counted,
        "skipped": skipped,
    }


def compare_cell(entries: List[Any], rows: str, row_value: str, cols: str, col_value: str) -> List[Any]:
    """The trains behind one cell of compare_grid."""
    row_dim = _COMPARE_BY_KEY.get(rows)
    col_dim = _COMPARE_BY_KEY.get(cols)
    if not row_dim or not col_dim:
        raise ValueError("Pick something to compare.")
    ctx = _compare_ctx()
    return [
        entry
        for entry in entries
        if row_value in row_dim["fn"](entry, ctx) and col_value in col_dim["fn"](entry, ctx)
    ]



def dashboard(entries: Optional[List[Any]] = None, all_entries: Optional[List[Any]] = None) -> Dict[str, Any]:
    reload_types()
    reload_type_filters()
    reload_acronyms()
    rr_mod.reload_railroads()
    st_mod.ensure_loaded()
    items = st_mod.catalog_items()
    grouped = rr_mod.grouped_railroads()
    loc_by_rr: Dict[str, int] = defaultdict(int)
    unique_by_rr: Dict[str, set] = defaultdict(set)
    for rrs, _display, _original, name, _mp in st_mod.STATIONS:
        for railroad in rrs:
            loc_by_rr[railroad] += 1
            unique_by_rr[railroad].add(name)
    sub_by_rr: Dict[str, int] = defaultdict(int)
    for item in items:
        for railroad in item["railroads"]:
            sub_by_rr[railroad] += 1
    railroad_stats: List[Dict[str, Any]] = []
    for group in grouped["groups"]:
        for name in group["railroads"]:
            railroad_stats.append(
                {
                    "railroad": name,
                    "group": group["label"],
                    "subdivisions": sub_by_rr.get(name, 0),
                    "locations": loc_by_rr.get(name, 0),
                    "unique_locations": len(unique_by_rr.get(name, set())),
                }
            )
    known = {row["railroad"] for row in railroad_stats}
    extras = sorted(set(list(sub_by_rr) + list(loc_by_rr)) - known)
    for name in extras:
        railroad_stats.append(
            {
                "railroad": name,
                "group": "In CSVs",
                "subdivisions": sub_by_rr.get(name, 0),
                "locations": loc_by_rr.get(name, 0),
                "unique_locations": len(unique_by_rr.get(name, set())),
            }
        )
    rights = sum(1 for item in items if len(item["railroads"]) > 1)
    user_files = sum(1 for item in items if item["source"] != "bundled")
    return {
        "success": True,
        "totals": {
            "files": len(items),
            "subdivisions": len(items),
            "locations": len(st_mod.STATIONS),
            "railroads": len(grouped["all"]),
            "types": len(list_types()),
            "trackage_rights": rights,
            "user_files": user_files,
            "bundled_files": sum(1 for item in items if item["source"] == "bundled"),
        },
        "railroads": railroad_stats,
        "groups": grouped["groups"],
        "classes": grouped["classes"],
        "freight_classes": grouped["freight_classes"],
        "class_choices": grouped["class_choices"],
        "types": list_types(),
        "type_filters": list_type_filters(),
        "meanings": list_meanings(),
        "subdivisions": items,
        "log": log_stats(entries, all_entries),
    }
