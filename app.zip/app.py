"""Flask API and static UI for Railroad Train Log."""
from __future__ import annotations

import hashlib
import json
import os
import subprocess
import sys
import threading
import time
import traceback
from pathlib import Path

from flask import Flask, Response, jsonify, request, send_from_directory
from werkzeug.exceptions import HTTPException

import appearance as appearance_prefs
import data_updates
import debug as debug_log
import phone_sync
import durability
import updater
from database import Database, fuel_metrics, parse_import_payload, parse_tabular_records, rows_to_csv
from paths import resource_root
from railroads import add_railroad, grouped_railroads, reset_railroads, save_railroads, set_railroad_class
import analytics
from reference import decode_train_number, entry_reference, read_symbol, reference_rows
from special_power import list_rows as special_rows
from special_power import remove_row as special_remove
from special_power import restore_rows as special_restore
from special_power import roster as special_roster
from special_power import save_row as special_save
from stations import (
    delete_subdivision,
    get_subdivision,
    grouped_subdivisions,
    hide_subdivision,
    inbound_dir,
    inbound_status,
    ingest_inbound_csvs,
    import_subdivision_csv,
    restore_shipped_subdivisions,
    save_subdivision,
    search_stations,
    station_state,
    subdivision_location_counts,
    unhide_subdivision,
    with_milepost,
)
from catalog import compare_cell, compare_dimensions, compare_grid, dashboard
import datafix
import rrlibrary
from acronyms import list_meanings, reload_acronyms, reset_railroad_meanings, reset_type_meanings, save_meanings
from train_types import (
    add_type,
    add_type_filter,
    list_type_filters,
    list_types,
    remove_type,
    remove_type_filter,
    reset_type_filters,
    reset_types,
    save_type_order,
)
from states import SPLIT_STATES, STATE_CODES, STATE_ZONES, normalize_state
from trip_picks import list_picks, reset_picks, save_picks
from aar_marks import list_book as aar_list_book
from aar_marks import reset_all as aar_reset_all
from aar_marks import restore_mark as aar_restore_mark
from aar_marks import save_mark as aar_save_mark
from quick_spots import add_favorite as quick_spots_add_favorite
from quick_spots import list_favorites as quick_spots_list_favorites
from quick_spots import remove_favorite as quick_spots_remove_favorite
from quick_spots import save_favorites as quick_spots_save_favorites
from trip_packing import list_kit as packing_list_kit
from trip_packing import reset_kit as packing_reset_kit
from trip_packing import save_kit as packing_save_kit
from validators import ValidationError, duplicate_window_message, normalize_time_zone, validate_entry
from version import APP_VERSION
from work import begin as work_begin
from work import finish as work_finish
from work import snapshot as work_snapshot
from work import update as work_update

ROOT = resource_root()
STATIC = ROOT / "static"


def _fuel_amount(value: float, places: int) -> str:
    text = "{:,.{}f}".format(value, places)
    if "." in text:
        text = text.rstrip("0").rstrip(".")
    return text


def _driven_miles(details: dict) -> float:
    start, end = str(details.get("start_miles") or ""), str(details.get("end_miles") or "")
    try:
        driven = float(end) - float(start) if start and end else 0
    except ValueError:
        return 0
    return driven if driven > 0 else 0


def _temp_label(values: list) -> str:
    nums = []
    for text in values:
        try:
            nums.append(float(text))
        except (TypeError, ValueError):
            continue
    if not nums:
        return "—"
    lo, hi = min(nums), max(nums)
    if lo == hi:
        return _fuel_amount(lo, 1) + "°F"
    return "{}–{}°F".format(_fuel_amount(lo, 1), _fuel_amount(hi, 1))


def _fuel_facts(reports: list) -> list:
    """Fuel totals and trip rates for the trips in this view. One trip's fill-ups count once."""
    gallons = cost = miles = fuel_miles = 0.0
    trips = 0
    trains_gal = trains_cost = trains_miles = 0
    temps = []
    for report in reports:
        details = report.get("details") or {}
        try:
            trains = int(report.get("trains") or 0)
        except (TypeError, ValueError):
            trains = 0
        driven = _driven_miles(details)
        if driven and trains:
            miles += driven
            trains_miles += trains
        log = details.get("fuel_log") or []
        for item in log:
            if isinstance(item, dict):
                temp = str(item.get("temperature") or "").strip()
                if temp:
                    temps.append(temp)
        if not log:
            continue
        metrics = fuel_metrics(log)
        if not metrics["gallons"] and not metrics["cost"]:
            continue
        trips += 1
        gallons += metrics["gallons"]
        cost += metrics["cost"]
        if metrics["gallons"] and trains:
            trains_gal += trains
        if metrics["cost"] and trains:
            trains_cost += trains
        if metrics["gallons"] and driven:
            fuel_miles += driven
    facts = []
    if trips:
        if gallons:
            facts.append({
                "name": "Fuel used",
                "value": "{} gal on {} trip{}".format(_fuel_amount(gallons, 1), trips, "" if trips == 1 else "s"),
            })
        if cost:
            facts.append({"name": "Fuel cost", "value": "${:,.2f}".format(cost)})
        if gallons and cost:
            facts.append({"name": "Average price per gallon", "value": "${:,.2f}".format(cost / gallons)})
        if gallons and fuel_miles:
            facts.append({"name": "Miles per gallon", "value": _fuel_amount(fuel_miles / gallons, 1)})
        if cost and fuel_miles:
            facts.append({"name": "Fuel cost per mile", "value": "${:,.2f}".format(cost / fuel_miles)})
    if trains_miles and miles:
        facts.append({"name": "Trains per mile", "value": _fuel_amount(trains_miles / miles, 3)})
    if trains_gal and gallons:
        facts.append({"name": "Trains per gallon", "value": _fuel_amount(trains_gal / gallons, 3)})
    if trains_cost and cost:
        facts.append({"name": "Fuel cost per train", "value": "${:,.2f}".format(cost / trains_cost)})
    if temps:
        facts.append({"name": "Outside temperature", "value": _temp_label(temps)})
    return facts


def _period_rate_rows(chosen: list, all_entries: list, details: dict) -> list:
    """Trip rates for Side by Side. A trip counts only when every train on it is in this period."""
    chosen_ids = {id(entry) for entry in chosen}
    by_name = {}
    for entry in all_entries:
        name = (getattr(entry, "trip_name", "") or "").strip()
        if name:
            by_name.setdefault(name, []).append(entry)
    miles = gallons = cost = 0.0
    trains_miles = trains_gal = trains_cost = 0
    temps = []
    seen = []
    for entry in chosen:
        name = (getattr(entry, "trip_name", "") or "").strip()
        if name and name not in seen:
            seen.append(name)
    for name in seen:
        members = by_name.get(name) or []
        if not members or any(id(entry) not in chosen_ids for entry in members):
            continue
        item = details.get(name.lower()) or {}
        trains = len(members)
        for fill in item.get("fuel_log") or []:
            if isinstance(fill, dict):
                temp = str(fill.get("temperature") or "").strip()
                if temp:
                    temps.append(temp)
        driven = _driven_miles(item)
        if driven and trains:
            miles += driven
            trains_miles += trains
        metrics = fuel_metrics(item.get("fuel_log") or [])
        if metrics["gallons"] and trains:
            gallons += metrics["gallons"]
            trains_gal += trains
        if metrics["cost"] and trains:
            cost += metrics["cost"]
            trains_cost += trains
    return [
        {"name": "Trains per mile", "value": _fuel_amount(trains_miles / miles, 3) if miles and trains_miles else "—"},
        {"name": "Trains per gallon", "value": _fuel_amount(trains_gal / gallons, 3) if gallons and trains_gal else "—"},
        {"name": "Fuel cost per train", "value": "${:,.2f}".format(cost / trains_cost) if cost and trains_cost else "—"},
        {"name": "Outside temperature", "value": _temp_label(temps)},
    ]


def create_app(db_path=None, watch_inbound: bool = False, serve_phones: bool = False) -> Flask:
    app = Flask(
        __name__,
        static_folder=str(STATIC),
        static_url_path="/static",
        root_path=str(ROOT),
    )
    app.config["DB"] = Database(db_path)
    if serve_phones:
        phone_sync.note_restored_state()
    app.config["FIELD"] = os.environ.get("TRAINS_FIELD") == "1"
    app.json.sort_keys = False
    data_updates.apply()

    def db() -> Database:
        return app.config["DB"]

    @app.errorhandler(ValidationError)
    def handle_validation(exc: ValidationError):
        return jsonify({"success": False, **exc.to_dict()}), 400

    @app.errorhandler(OSError)
    def handle_oserror(exc: OSError):
        app.logger.exception("Catalog write failed")
        debug_log.record_exception(request.method + " " + request.path, exc)
        return (
            jsonify(
                {
                    "success": False,
                    "error": "Could not save that catalog file. TRAIN LOG needs write access to Application Support.",
                }
            ),
            500,
        )

    @app.errorhandler(Exception)
    def handle_unexpected(exc: Exception):
        if isinstance(exc, HTTPException):
            return exc
        app.logger.exception("Unhandled error")
        debug_log.record_exception(request.method + " " + request.path, exc)
        return jsonify({"success": False, "error": str(exc) or "Something went wrong."}), 500

    @app.get("/api/debug/report")
    def debug_report_get():
        return jsonify(debug_log.build_report(db()))

    @app.post("/api/debug/report")
    def debug_report_post():
        payload = request.get_json(silent=True) or {}
        client = payload.get("client") if isinstance(payload.get("client"), dict) else {}
        return jsonify(debug_log.build_report(db(), client))

    @app.get("/api/debug/errors")
    def debug_errors():
        return jsonify({"success": True, "errors": debug_log.recent(100)})

    @app.post("/api/debug/errors")
    def debug_error_add():
        payload = request.get_json(silent=True) or {}
        items = payload.get("errors") if isinstance(payload.get("errors"), list) else [payload]
        for item in items[:20]:
            if not isinstance(item, dict):
                continue
            debug_log.record(
                "client." + str(item.get("kind") or "error")[:40],
                str(item.get("message") or "")[:2000],
                {k: item.get(k) for k in ("source", "line", "col", "stack", "url", "status", "view") if item.get(k) is not None},
            )
        return jsonify({"success": True})

    @app.post("/api/debug/clear")
    def debug_clear():
        debug_log.clear()
        return jsonify({"success": True})

    @app.get("/")
    @app.get("/index.html")
    def index():
        # Inject disk appearance so Night survives a 127.0.0.1 port/origin change
        # (localStorage alone is origin-scoped; Intel Qt also often reports light).
        html = (STATIC / "index.html").read_text(encoding="utf-8")
        payload = json.dumps(appearance_prefs.load_appearance(), separators=(",", ":"))
        snip = "<script>window.__TRAINLOG_APPEARANCE__={};</script>\n".format(payload)
        if "</title>" in html:
            html = html.replace("</title>", "</title>\n  " + snip, 1)
        else:
            html = snip + html
        return Response(html, mimetype="text/html; charset=utf-8")

    @app.get("/api/appearance")
    def appearance_get():
        return jsonify({"success": True, **appearance_prefs.load_appearance()})

    @app.put("/api/appearance")
    def appearance_put():
        saved = appearance_prefs.save_appearance(request.get_json(silent=True) or {})
        return jsonify({"success": True, **saved})

    @app.get("/field/field.css")
    def field_stylesheet():
        # Device preview loads this from the live server, same as styles.css.
        response = send_from_directory(ROOT / "field", "field.css")
        response.headers["Cache-Control"] = "no-cache"
        return response

    @app.get("/docs")
    def docs():
        return send_from_directory(STATIC, "docs.html")

    @app.get("/api/health")
    def health():
        return jsonify({"success": True, "version": APP_VERSION, "database": db().info()})

    @app.get("/api/database")
    def database_info():
        return jsonify({"success": True, **db().info()})

    @app.post("/api/database/open")
    def database_open():
        payload = request.get_json(silent=True) or {}
        path = payload.get("path")
        if not path:
            raise ValidationError("Database path is required", "path")
        db().reopen(Path(path))
        db().log_activity("database.open", "Opened database {}.".format(path), {"path": str(path)})
        return jsonify({"success": True, **db().info()})

    @app.get("/api/work")
    def work_status():
        return jsonify({"success": True, **work_snapshot()})

    @app.get("/api/database/backup")
    def database_backup():
        work_begin("Backing up database…")
        try:
            data = db().backup_bytes()
        finally:
            work_finish()
        return Response(
            data,
            mimetype="application/octet-stream",
            headers={"Content-Disposition": "attachment; filename=train-log.db"},
        )

    @app.get("/api/database/recovery-pack")
    def database_recovery_pack():
        work_begin("Building recovery pack…")
        try:
            data = db().recovery_pack_bytes()
        finally:
            work_finish()
        stamp = time.strftime("%Y-%m-%d")
        filename = "TRAIN-LOG-recovery-{}.zip".format(stamp)
        return Response(
            data,
            mimetype="application/zip",
            headers={"Content-Disposition": "attachment; filename={}".format(filename)},
        )

    def entry_filters():
        return {
            "date": request.args.get("date") or None,
            "date_from": request.args.get("date_from") or None,
            "date_to": request.args.get("date_to") or None,
            "railroad": request.args.get("railroad") or None,
            "direction": request.args.get("direction") or None,
            "location_spot": request.args.get("location_spot") or None,
            "train_types": request.args.get("train_types") or None,
            "load_status": request.args.get("load_status") or None,
            "lead_locomotive": request.args.get("lead_locomotive") or None,
            "trip_name": request.args.get("trip_name") or None,
            "train_symbol": request.args.get("train_symbol") or None,
            "power_consist": request.args.get("power_consist") or None,
            "car_counts": request.args.get("car_counts") or None,
            "location_subdivision": request.args.get("location_subdivision") or None,
            "location_state": request.args.get("location_state") or None,
            "time_zone": request.args.get("time_zone") or None,
            "notes": request.args.get("notes") or None,
            "media": request.args.get("media") or None,
            "ids": id_list(request.args.get("ids")),
        }

    def id_list(raw):
        if raw is None:
            return None
        return [int(item) for item in str(raw).split(",") if item.strip().isdigit()][:5000]

    @app.get("/api/entries")
    def list_entries():
        entries = []
        for entry in db().list_entries(entry_filters()):
            item = entry.to_dict()
            item.update(entry_reference(item))
            entries.append(item)
        return jsonify(entries)

    @app.get("/api/reference/decode")
    def reference_decode():
        railroad = request.args.get("railroad", "")
        symbol = request.args.get("symbol", "")
        number = request.args.get("train_number", "")
        return jsonify(
            {
                "symbol": read_symbol(railroad, symbol, number) if symbol else None,
                "train_number": decode_train_number(railroad, number) if number else None,
            }
        )

    @app.get("/api/reference/list")
    def reference_list():
        return jsonify(
            reference_rows(
                request.args.get("kind", ""),
                request.args.get("railroad", ""),
                request.args.get("q", ""),
            )
        )

    @app.get("/api/special-power/roster")
    def special_power_roster():
        return jsonify(special_roster(db().special_power_values()))

    @app.get("/api/special-power/list")
    def special_power_list():
        return jsonify({"success": True, "heritage": special_rows("heritage"), "steam": special_rows("steam")})

    @app.post("/api/special-power/item")
    def special_power_save():
        payload = request.get_json(silent=True) or {}
        kind = str(payload.get("kind") or "")
        original = str(payload.get("original") or "")
        try:
            row = special_save(kind, payload, original)
        except ValueError as err:
            raise ValidationError(str(err), "unit" if kind == "heritage" else "engine")
        name = row.get("unit") or row.get("engine")
        verb = "Updated" if original else "Added"
        label = "heritage unit" if kind == "heritage" else "steam engine"
        db().log_activity("special_power.save", "{} {} {}.".format(verb, label, name), dict(row, kind=kind, original=original))
        return jsonify({"success": True, "row": row})

    @app.delete("/api/special-power/item")
    def special_power_remove():
        payload = request.get_json(silent=True) or {}
        kind = str(payload.get("kind") or "")
        unit = str(payload.get("unit") or "")
        try:
            removed = special_remove(kind, unit)
        except ValueError as err:
            raise ValidationError(str(err), "kind")
        if not removed:
            raise ValidationError("{} is not on the list".format(unit), "unit")
        label = "heritage unit" if kind == "heritage" else "steam engine"
        db().log_activity("special_power.remove", "Removed {} {} from the list.".format(label, unit), {"kind": kind, "unit": unit})
        return jsonify({"success": True})

    @app.post("/api/special-power/restore")
    def special_power_restore():
        payload = request.get_json(silent=True) or {}
        kind = str(payload.get("kind") or "")
        cleared = special_restore(kind)
        db().log_activity("special_power.restore", "Restored the shipped heritage and steam list.", {"kind": kind, "cleared": cleared})
        return jsonify({"success": True, "cleared": cleared})

    @app.get("/api/library")
    def library_list():
        return jsonify(dict(rrlibrary.summary(), success=True))

    @app.post("/api/library")
    def library_save():
        payload = request.get_json(silent=True) or {}
        original = str(payload.get("original") or "")
        before = rrlibrary.find(original) if original else None
        try:
            row = rrlibrary.save_row(payload.get("row") or {}, original)
        except ValueError as err:
            raise ValidationError(str(err), "name")
        label = row["mark"] or row["name"]
        db().log_activity(
            "library.save",
            "{} {} in the railroad library.".format("Updated" if original else "Added", label),
            {"before": before, "after": row},
        )
        return jsonify({"success": True, "row": row})

    @app.delete("/api/library/<path:rid>")
    def library_remove(rid: str):
        before = rrlibrary.find(rid)
        if not rrlibrary.remove_row(rid):
            return jsonify({"success": False, "error": "That railroad isn't in the library."}), 404
        label = (before or {}).get("mark") or (before or {}).get("name") or rid
        db().log_activity("library.remove", "Removed {} from the railroad library.".format(label), {"before": before})
        return jsonify({"success": True})

    @app.post("/api/library/restore")
    def library_restore():
        cleared = rrlibrary.restore_shipped()
        db().log_activity("library.restore", "Restored the shipped railroad library.", {"cleared": cleared})
        return jsonify({"success": True, "cleared": cleared})

    @app.post("/api/library/import")
    def library_import():
        payload = request.get_json(silent=True) or {}
        try:
            result = rrlibrary.import_rows(str(payload.get("text") or ""), str(payload.get("group") or ""))
        except ValueError as err:
            raise ValidationError(str(err), "text")
        parts = ["added {}".format(len(result["added"]))]
        if result["filled"]:
            parts.append("filled in blanks on {}".format(len(result["filled"])))
        if result["same"]:
            parts.append("{} already there".format(len(result["same"])))
        if result["skipped"]:
            parts.append("skipped {}".format(len(result["skipped"])))
        message = "Railroad library: " + ", ".join(parts) + "."
        db().log_activity("library.import", message, result)
        return jsonify(dict(result, success=True, message=message))

    @app.post("/api/library/menu")
    def library_add_to_menu():
        payload = request.get_json(silent=True) or {}
        try:
            row, _groups = rrlibrary.add_to_menu(str(payload.get("id") or ""))
        except ValueError as err:
            raise ValidationError(str(err), "id")
        db().log_activity(
            "library.menu",
            "Put {} on the Railroad menu from the library.".format(row["mark"]),
            {"mark": row["mark"], "group": row["group"], "rr_class": row["rr_class"], "name": row["name"]},
        )
        return jsonify({"success": True, "mark": row["mark"], "message": "{} is on the Railroad menu.".format(row["mark"])})

    @app.post("/api/library/extra")
    def library_extra():
        payload = request.get_json(silent=True) or {}
        on = bool(payload.get("on"))
        rrlibrary.set_extra(on)
        summary = rrlibrary.summary()
        db().log_activity(
            "library.extra",
            "{} the extra railroad list.".format("Added" if on else "Hid"),
            {"on": on, "count": summary["extra_count"]},
        )
        return jsonify(dict(summary, success=True))


    @app.get("/api/aar-marks")
    def aar_marks_list():
        return jsonify({"success": True, "book": aar_list_book()})

    @app.put("/api/aar-marks/mark")
    def aar_marks_save():
        payload = request.get_json(silent=True) or {}
        try:
            book = aar_save_mark(payload.get("mark"), payload.get("names"))
        except ValueError as err:
            raise ValidationError(str(err), "mark")
        mark = str(payload.get("mark") or "").strip().upper()
        db().log_activity("aar.marks", "Updated reporting mark {}.".format(mark), {"mark": mark})
        return jsonify({"success": True, "book": book})

    @app.post("/api/aar-marks/mark/restore")
    def aar_marks_restore_one():
        payload = request.get_json(silent=True) or {}
        try:
            book = aar_restore_mark(payload.get("mark"))
        except ValueError as err:
            raise ValidationError(str(err), "mark")
        mark = str(payload.get("mark") or "").strip().upper()
        db().log_activity("aar.marks", "Restored reporting mark {}.".format(mark), {"mark": mark})
        return jsonify({"success": True, "book": book})

    @app.post("/api/aar-marks/reset")
    def aar_marks_reset():
        book = aar_reset_all()
        db().log_activity("aar.marks", "Restored the shipped reporting marks list.", {})
        return jsonify({"success": True, "book": book})

    @app.get("/api/trip-packing/kit")
    def trip_packing_kit():
        return jsonify({"success": True, "kit": packing_list_kit()})

    @app.put("/api/trip-packing/kit")
    def trip_packing_kit_save():
        payload = request.get_json(silent=True) or {}
        try:
            kit = packing_save_kit(payload.get("kit") or payload.get("items") or payload)
        except ValueError as err:
            raise ValidationError(str(err), "kit")
        db().log_activity("trip.packing", "Updated the default field packing kit.", {"count": len(kit)})
        return jsonify({"success": True, "kit": kit})

    @app.post("/api/trip-packing/kit/reset")
    def trip_packing_kit_reset():
        kit = packing_reset_kit()
        db().log_activity("trip.packing", "Restored the shipped field packing kit.", {"count": len(kit)})
        return jsonify({"success": True, "kit": kit})

    @app.get("/api/quick-spots")
    def quick_spots_list():
        return jsonify({"success": True, "favorites": quick_spots_list_favorites()})

    @app.put("/api/quick-spots")
    def quick_spots_save():
        payload = request.get_json(silent=True) or {}
        favorites = quick_spots_save_favorites(payload.get("favorites"))
        db().log_activity("quick.spots", "Updated Quick spots favorites.", {"count": len(favorites)})
        return jsonify({"success": True, "favorites": favorites})

    @app.post("/api/quick-spots")
    def quick_spots_add():
        payload = request.get_json(silent=True) or {}
        favorites = quick_spots_add_favorite(payload.get("spot") if isinstance(payload.get("spot"), dict) else payload)
        db().log_activity("quick.spots", "Saved a Quick spot favorite.", {"count": len(favorites)})
        return jsonify({"success": True, "favorites": favorites})

    @app.post("/api/quick-spots/remove")
    def quick_spots_remove():
        payload = request.get_json(silent=True) or {}
        favorites = quick_spots_remove_favorite(payload.get("spot") if isinstance(payload.get("spot"), dict) else payload)
        db().log_activity("quick.spots", "Removed a Quick spot favorite.", {"count": len(favorites)})
        return jsonify({"success": True, "favorites": favorites})

    @app.get("/api/trips")
    def list_trips():
        trips = db().list_trips()
        details = db().trip_details()
        counts = db().trip_counts()
        named = set()
        for trip in trips:
            key = trip["name"].strip().lower()
            named.add(key)
            trip["details"] = details.get(key)
            trip["trains"] = counts.get(trip["name"], 0)
        for key, extra in details.items():
            if key not in named:
                trips.append({"name": extra["name"], "trip_date_from": "", "trip_date_to": "", "latest": "", "details": extra, "trains": 0})
        trips.sort(key=lambda item: item["name"].lower())
        return jsonify({"trips": trips, "picks": list_picks()})

    @app.get("/api/trip-picks")
    def trip_picks_list():
        return jsonify({"success": True, "picks": list_picks()})

    @app.put("/api/trip-picks")
    def trip_picks_save():
        payload = request.get_json(silent=True) or {}
        picks = save_picks(payload)
        db().log_activity("trip.picks", "Changed the attendee and vehicle buttons for Trip Details.", picks)
        return jsonify({"success": True, "picks": picks})

    @app.post("/api/trip-picks/reset")
    def trip_picks_reset():
        picks = reset_picks()
        db().log_activity("trip.picks", "Restored the default attendee and vehicle buttons for Trip Details.", picks)
        return jsonify({"success": True, "picks": picks})

    @app.post("/api/trips/details")
    def save_trip_details():
        payload = request.get_json(silent=True) or {}
        saved = db().save_trip_details(str(payload.get("name") or ""), payload)
        return jsonify({"success": True, "details": saved, "message": "Saved the details for {}.".format(saved["name"])})

    @app.get("/api/entries/<int:entry_id>")
    def get_entry(entry_id: int):
        entry = db().get_entry(entry_id)
        if entry is None:
            return jsonify({"success": False, "error": "Entry not found"}), 404
        return jsonify(entry.to_dict())

    def create_one(raw, force=False):
        cleaned = validate_entry(raw)
        if force:
            cleaned["force"] = True
        duplicates = []
        if not cleaned.get("force"):
            duplicates = db().find_duplicates(cleaned)
            if duplicates:
                return None, duplicates, cleaned
        entry = db().create_entry(cleaned)
        return entry, [], cleaned

    @app.post("/api/entries")
    def create_entries():
        payload = request.get_json(silent=True)
        if payload is None:
            raise ValidationError("JSON body is required")
        if isinstance(payload, dict) and isinstance(payload.get("entries"), list):
            items = payload["entries"]
            global_force = bool(payload.get("force"))
        elif isinstance(payload, list):
            items = payload
            global_force = False
        else:
            items = [payload]
            global_force = bool(payload.get("force"))

        if not items:
            return (
                jsonify(
                    {
                        "success": False,
                        "created": [],
                        "duplicates": [],
                        "errors": [{"row": 0, "error": "No entries to save", "field": None}],
                        "message": "No entries to save",
                    }
                ),
                400,
            )

        created = []
        duplicates = []
        errors = []
        for index, raw in enumerate(items):
            raw = dict(raw or {})
            row = raw.get("row", index)
            try:
                entry, dupes, _cleaned = create_one(
                    raw, force=global_force or bool(raw.get("force"))
                )
            except ValidationError as exc:
                errors.append({"row": row, "error": exc.message, "field": exc.field})
                continue
            if dupes:
                duplicates.append(
                    {
                        "row": row,
                        "entry": {k: v for k, v in raw.items() if k != "force"},
                        "existing": [item.to_dict() for item in dupes],
                        "message": duplicate_window_message(),
                    }
                )
                continue
            created.append({"row": row, "id": entry.id, "entry": entry.to_dict()})

        if duplicates and not created and not errors:
            return (
                jsonify(
                    {
                        "success": False,
                        "duplicate": True,
                        "created": created,
                        "duplicates": duplicates,
                        "errors": errors,
                        "message": duplicate_window_message(),
                    }
                ),
                409,
            )
        if duplicates or errors:
            # Pure validation failure → 400 so clients can trust HTTP status, not only payload.success.
            # Duplicates only → 409. Partial create with some bad rows → 200 with success true/false mix.
            if errors and not created and not duplicates:
                status = 400
            elif duplicates and not created:
                status = 409
            else:
                status = 200
            return jsonify(
                {
                    "success": False if (errors and not created) else True,
                    "duplicate": bool(duplicates),
                    "created": created,
                    "duplicates": duplicates,
                    "errors": errors,
                    "message": "Some rows need attention",
                }
            ), status
        message = "Entry added" if len(created) == 1 else "{} entries added".format(len(created))
        result = {
            "success": True,
            "created": created,
            "duplicates": [],
            "errors": [],
            "message": message,
        }
        if len(created) == 1:
            result["id"] = created[0]["id"]
        return jsonify(result), 201

    @app.put("/api/entries/<int:entry_id>")
    def update_entry(entry_id: int):
        payload = request.get_json(silent=True)
        if not isinstance(payload, dict):
            raise ValidationError("JSON object is required")
        existing = db().get_entry(entry_id)
        if existing is None:
            return jsonify({"success": False, "error": "Entry not found"}), 404
        cleaned = validate_entry(payload)
        if not payload.get("force"):
            dupes = db().find_duplicates(cleaned, exclude_id=entry_id)
            if dupes:
                return (
                    jsonify(
                        {
                            "success": False,
                            "duplicate": True,
                            "existing": [item.to_dict() for item in dupes],
                            "message": duplicate_window_message(),
                        }
                    ),
                    409,
                )
        entry = db().update_entry(entry_id, cleaned)
        return jsonify({"success": True, "id": entry.id, "entry": entry.to_dict(), "message": "Entry updated"})

    @app.delete("/api/entries/<int:entry_id>")
    def delete_entry(entry_id: int):
        if not db().delete_entry(entry_id):
            return jsonify({"success": False, "error": "Entry not found"}), 404
        return jsonify({"success": True, "message": "Entry deleted"})

    @app.post("/api/entries/delete")
    def delete_selected_entries():
        payload = request.get_json(silent=True) or {}
        ids = payload.get("ids")
        if not isinstance(ids, list) or not ids:
            raise ValidationError("Select at least one sighting", "ids")
        try:
            ids = [int(item) for item in ids]
        except (TypeError, ValueError):
            raise ValidationError("Sighting ids must be numbers", "ids")
        removed = db().delete_entries(ids)
        return jsonify(
            {
                "success": True,
                "deleted": removed,
                "message": "Deleted {} sighting{}.".format(removed, "" if removed == 1 else "s"),
            }
        )

    @app.post("/api/entries/time-zone")
    def set_entries_time_zone():
        payload = request.get_json(silent=True) or {}
        ids = payload.get("ids")
        if not isinstance(ids, list) or not ids:
            raise ValidationError("Select at least one sighting", "ids")
        try:
            ids = [int(item) for item in ids]
        except (TypeError, ValueError):
            raise ValidationError("Sighting ids must be numbers", "ids")
        if payload.get("from_state") is True:
            changed, skipped = db().set_time_zone_from_state(ids)
            message = "Matched the time zone to the state on {} sighting{}.".format(changed, "" if changed == 1 else "s")
            if skipped:
                message += " {} left alone (no state, or a state with two time zones).".format(skipped)
            return jsonify({"success": True, "updated": changed, "left_alone": skipped, "message": message})
        zone = normalize_time_zone(payload.get("time_zone"))
        changed = db().set_time_zone(ids, zone)
        return jsonify(
            {
                "success": True,
                "updated": changed,
                "time_zone": zone,
                "message": "Time zone set on {} sighting{}.".format(changed, "" if changed == 1 else "s"),
            }
        )

    @app.post("/api/entries/bulk")
    def bulk_update_entries():
        from states import normalize_state

        payload = request.get_json(silent=True) or {}
        ids = payload.get("ids")
        if not isinstance(ids, list) or not ids:
            raise ValidationError("Select at least one sighting", "ids")
        try:
            ids = [int(item) for item in ids]
        except (TypeError, ValueError):
            raise ValidationError("Sighting ids must be numbers", "ids")
        subdivision = None
        if "subdivision" in payload:
            subdivision = str(payload.get("subdivision") or "").strip()
            if len(subdivision) > 120:
                raise ValidationError("Subdivision name is too long", "subdivision")
        state = None
        if "state" in payload:
            raw_state = str(payload.get("state") or "").strip()
            state = normalize_state(raw_state)
            if raw_state and not state:
                raise ValidationError("State must be a two-letter code like AZ", "state")
        zone_from_state = payload.get("zone_from_state") is True
        time_zone = None
        if "time_zone" in payload and not zone_from_state:
            time_zone = normalize_time_zone(payload.get("time_zone"))
        trip_name = None
        if "trip_name" in payload:
            trip_name = str(payload.get("trip_name") or "").strip()
            if len(trip_name) > 120:
                raise ValidationError("Trip name is too long", "trip_name")
        if subdivision is None and state is None and time_zone is None and not zone_from_state and trip_name is None:
            raise ValidationError("Pick a trip, subdivision, state, or time zone to set", "subdivision")
        watch = set(ids)
        if trip_name:
            watch.update(db().trip_member_ids(trip_name))
        before = db().entries_by_ids(watch)
        parts = []
        trip_dates = ""
        if trip_name is not None:
            name, start, end = db().set_trip(ids, trip_name)
            parts.append("trip " + name if name else "no trip")
            if name and start:
                trip_dates = " {} now runs {} to {}.".format(name, start, end)
        if subdivision is not None or state is not None:
            db().set_place(ids, subdivision=subdivision, state=state, log=False)
            if subdivision is not None:
                parts.append("subdivision")
            if state is not None:
                parts.append("state")
        left_alone = 0
        if zone_from_state:
            _zoned, left_alone = db().set_time_zone_from_state(ids, log=False)
            parts.append("time zone from state")
        elif time_zone is not None:
            db().set_time_zone(ids, time_zone, log=False)
            parts.append("time zone")
        after = db().entries_by_ids(watch)
        skip = ("created_at", "updated_at")
        picked = set(ids)
        changes = [
            {"before": before[i], "after": after[i]}
            for i in sorted(watch, key=lambda i: (i not in picked, i))
            if i in before
            and i in after
            and {k: v for k, v in before[i].items() if k not in skip} != {k: v for k, v in after[i].items() if k not in skip}
        ]
        n = len(ids)
        what = ", ".join(parts[:-1]) + (" and " if len(parts) > 1 else "") + parts[-1]
        message = "Set {} on {} sighting{}.".format(what, n, "" if n == 1 else "s") + trip_dates
        if left_alone:
            message += " Time zone left alone on {} (no state, or a state with two time zones).".format(left_alone)
        db().log_activity(
            "entry.bulk",
            message,
            {
                "ids": ids,
                "set": {
                    key: value
                    for key, value in (
                        ("trip_name", trip_name),
                        ("subdivision", subdivision),
                        ("state", state),
                        ("time_zone", "from state" if zone_from_state else time_zone),
                    )
                    if value is not None
                },
                "changes": changes,
            },
        )
        return jsonify({"success": True, "updated": len(changes), "left_alone": left_alone, "message": message})

    @app.post("/api/entries/clear")
    def clear_entries():
        payload = request.get_json(silent=True) or {}
        if payload.get("confirm") is not True:
            raise ValidationError("Confirmation is required to delete all log data")
        deleted = db().delete_all_entries()
        return jsonify(
            {
                "success": True,
                "deleted": deleted,
                "message": "Deleted {} sighting{}.".format(deleted, "" if deleted == 1 else "s"),
            }
        )

    @app.get("/api/locations/autocomplete")
    def locations_autocomplete():
        query = request.args.get("q", "")
        railroad = request.args.get("railroad") or ""
        subdivision = request.args.get("subdivision") or ""
        guide = search_stations(railroad, subdivision, query) if (query or subdivision) else []
        history = []
        if query:
            history = [item.to_dict() for item in db().autocomplete_locations(query)]
        merged = []
        seen = set()
        for item in history + guide:
            item["location_spot"] = with_milepost(
                item.get("location_spot") or "",
                item.get("railroad") or railroad,
                item.get("location_subdivision") or subdivision,
            )
            item["location_spot_label"] = item.get("location_spot_label") or item["location_spot"]
            if not item.get("location_state"):
                item["location_state"] = station_state(
                    item["location_spot"],
                    item.get("railroad") or railroad,
                    item.get("location_subdivision") or subdivision,
                )
            key = (
                (item.get("location_spot") or "").lower(),
                (item.get("location_subdivision") or "").lower(),
            )
            if key in seen:
                continue
            seen.add(key)
            merged.append(item)
        return jsonify(merged)

    @app.get("/api/railroads")
    def railroads():
        payload = grouped_railroads()
        payload["types"] = list_types()
        payload["meanings"] = list_meanings()
        payload["states"] = {
            "codes": list(STATE_CODES),
            "zones": STATE_ZONES,
            "split": sorted(SPLIT_STATES),
        }
        return jsonify(payload)

    def dashboard_entries():
        all_entries = db().list_entries()
        filters = entry_filters()
        trip = (filters.get("trip_name") or "").strip()
        sql_filters = dict(filters)
        sql_filters["trip_name"] = ""
        filtered = (
            db().list_entries(sql_filters)
            if any(sql_filters.get(key) for key in ("date_from", "date_to", "date", "railroad"))
            else all_entries
        )
        if trip:
            filtered = [
                entry
                for entry in filtered
                if (getattr(entry, "trip_name", None) or "") == trip
            ]
        return all_entries, filtered

    @app.get("/api/catalog/compare")
    def catalog_compare():
        _all, filtered = dashboard_entries()
        rows = request.args.get("rows", "")
        cols = request.args.get("cols", "")
        try:
            limit = int(request.args.get("limit") or 12)
        except ValueError:
            limit = 12
        try:
            if request.args.get("row_value") is not None:
                trains = compare_cell(filtered, rows, request.args.get("row_value", ""), cols, request.args.get("col_value", ""))
                trains.sort(key=lambda e: ((e.date or ""), (e.time or "")), reverse=True)
                return jsonify({"success": True, "entries": [e.to_dict() for e in trains[:200]], "count": len(trains)})
            return jsonify({"success": True, "dimensions": compare_dimensions(), **compare_grid(filtered, rows, cols, limit)})
        except ValueError as exc:
            return jsonify({"success": False, "error": str(exc), "dimensions": compare_dimensions()}), 400

    def entry_rows(entries, cap=500):
        entries = sorted(entries, key=lambda e: ((e.date or ""), (e.time or ""), e.id or 0), reverse=True)
        return [e.to_dict() for e in entries[:cap]]

    @app.get("/api/fix/drill")
    def fix_drill():
        _all, filtered = dashboard_entries()
        try:
            trains = datafix.drill(
                filtered,
                request.args.get("source", ""),
                request.args.get("value", ""),
                request.args.get("type_rr", ""),
            )
        except ValueError as exc:
            return jsonify({"success": False, "error": str(exc)}), 400
        return jsonify({"success": True, "count": len(trains), "ids": [e.id for e in trains], "entries": entry_rows(trains)})

    @app.get("/api/fix/values")
    def fix_values():
        field = request.args.get("field", "")
        try:
            values = datafix.field_values(db().list_entries(), field)
        except ValueError as exc:
            return jsonify({"success": False, "error": str(exc), "fields": datafix.FIX_FIELDS}), 400
        return jsonify({"success": True, "fields": datafix.FIX_FIELDS, "field": field, "values": values})

    @app.post("/api/fix/replace")
    def fix_replace():
        payload = request.get_json(silent=True) or {}
        field = str(payload.get("field") or "")
        if field not in datafix.FIX_KEYS:
            raise ValidationError("Pick a field to change", "field")
        if not isinstance(payload.get("from"), str):
            raise ValidationError("Pick the value to replace", "from")
        old = payload["from"].strip()
        trains = [e for e in db().list_entries() if old in datafix.entry_values(e, field)]
        label = datafix.FIX_KEYS[field]
        if payload.get("preview") is True:
            return jsonify({"success": True, "count": len(trains), "ids": [e.id for e in trains], "entries": entry_rows(trains)})
        new = datafix.clean_value(field, payload.get("to"))
        if new == old:
            raise ValidationError("The new value is the same as the old one", "to")
        if not trains:
            raise ValidationError("No sightings have that {} anymore".format(label.lower()), "from")
        ids = [e.id for e in trains]
        before = db().entries_by_ids(ids)
        db().set_fields({i: datafix.replaced_fields(before[i], field, new, old) for i in ids if i in before})
        after = db().entries_by_ids(ids)
        skip = ("created_at", "updated_at")
        changes = [
            {"before": before[i], "after": after[i]}
            for i in sorted(ids)
            if i in before and i in after
            and {k: v for k, v in before[i].items() if k not in skip} != {k: v for k, v in after[i].items() if k not in skip}
        ]
        n = len(changes)
        message = "Replaced {} {} with {} on {} sighting{}.".format(
            label, '"{}"'.format(old) if old else "(blank)", '"{}"'.format(new) if new else "(blank)", n, "" if n == 1 else "s"
        )
        db().log_activity("entry.replace", message, {"ids": ids, "field": field, "from": old, "to": new, "changes": changes})
        return jsonify({"success": True, "updated": n, "ids": ids, "message": message})

    @app.get("/api/fix/checks")
    def fix_checks():
        entries = db().list_entries()
        check = request.args.get("check")
        if not check:
            return jsonify({"success": True, "trains": len(entries), "checks": datafix.check_summary(entries)})
        try:
            ids = set(datafix.check_ids(entries, check))
        except ValueError as exc:
            return jsonify({"success": False, "error": str(exc)}), 400
        trains = [e for e in entries if e.id in ids]
        info = datafix.CHECKS_BY_ID[check]
        return jsonify({
            "success": True,
            "count": len(trains),
            "ids": sorted(ids),
            "entries": entry_rows(trains),
            "fix": info.get("fix", ""),
            "fixable": datafix.fixable_ids(entries, check),
            "row_fix": info.get("row_fix", True),
            "fix_left": info.get("left", "The others need an Edit."),
            "values": datafix.check_values(entries, check),
            "value_field": info.get("values", ""),
            "places": datafix.state_places(entries) if info.get("places") else [],
            "state_codes": list(STATE_CODES) if info.get("places") else [],
        })

    def entry_changes(watch, before):
        after = db().entries_by_ids(watch)
        skip = ("created_at", "updated_at")
        return [
            {"before": before[i], "after": after[i]}
            for i in sorted(watch)
            if i in before and i in after
            and {k: v for k, v in before[i].items() if k not in skip} != {k: v for k, v in after[i].items() if k not in skip}
        ]

    @app.post("/api/fix/checks/apply")
    def fix_checks_apply():
        payload = request.get_json(silent=True) or {}
        check = str(payload.get("check") or "")
        if check not in datafix.CHECKS_BY_ID:
            raise ValidationError("Pick a check", "check")
        only = None
        if payload.get("ids") is not None:
            try:
                only = {int(item) for item in payload.get("ids") or []}
            except (TypeError, ValueError):
                raise ValidationError("Sighting ids must be numbers", "ids")
        entries = db().list_entries()
        if payload.get("state") is not None or payload.get("states") is not None:
            if not datafix.CHECKS_BY_ID[check].get("places"):
                raise ValidationError("This check can't set a state", "check")
            if payload.get("states") is not None:
                if not isinstance(payload.get("states"), dict):
                    raise ValidationError("States must be a list of sightings and states", "states")
                try:
                    wanted = {int(k): normalize_state(v) for k, v in payload["states"].items()}
                except (TypeError, ValueError):
                    raise ValidationError("Sighting ids must be numbers", "states")
            else:
                if not only:
                    raise ValidationError("Pick the trains to change", "ids")
                wanted = {i: normalize_state(payload.get("state")) for i in only}
            if not wanted or not all(wanted.values()):
                raise ValidationError("Pick a state", "state")
            flagged = set(datafix.check_ids(entries, check))
            plan = {"fields": {i: {"location_state": s} for i, s in sorted(wanted.items()) if i in flagged},
                    "zone": [], "trips": [], "renames": [], "delete": []}
        else:
            try:
                plan = datafix.fix_plan(entries, check, only=only)
            except ValueError as exc:
                raise ValidationError(str(exc), "check")
        if not datafix.plan_ids(plan) and not plan["renames"]:
            raise ValidationError("Nothing here can be fixed automatically. Edit these trains instead.", "check")
        watch = set(datafix.plan_ids(plan)) - set(plan["delete"])
        for _ids, name in plan["trips"]:
            watch.update(db().trip_member_ids(name))
        for old, new in plan["renames"]:
            watch.update(e.id for e in entries if (e.trip_name or "").strip().lower() in (old.strip().lower(), new.lower()))
        before = db().entries_by_ids(watch)
        if plan["fields"]:
            db().set_fields(plan["fields"])
        if plan["zone"]:
            db().set_time_zone_from_state(plan["zone"], log=False)
        for ids, name in plan["trips"]:
            db().set_trip(ids, name)
        for old, new in plan["renames"]:
            db().rename_trip(old, new)
        deleted = db().delete_entries(plan["delete"]) if plan["delete"] else 0
        changes = entry_changes(watch, before)
        title = datafix.CHECKS_BY_ID[check]["title"]
        parts = []
        if changes:
            parts.append("fixed {} sighting{}".format(len(changes), "" if len(changes) == 1 else "s"))
        if deleted:
            parts.append("deleted {} extra cop{}".format(deleted, "y" if deleted == 1 else "ies"))
        message = "Data Check {}: {}.".format(" and ".join(parts) or "found nothing left to change", title)
        if changes:
            db().log_activity("entry.fix", message, {"check": check, "ids": sorted(watch), "changes": changes})
        return jsonify({"success": True, "updated": len(changes), "deleted": deleted, "message": message})

    @app.post("/api/trips/rename")
    def trips_rename():
        payload = request.get_json(silent=True) or {}
        old = str(payload.get("from") or "")
        watch = set(db().trip_member_ids(old)) | set(db().trip_member_ids(str(payload.get("to") or "")))
        before = db().entries_by_ids(watch)
        name, start, end, ids = db().rename_trip(old, str(payload.get("to") or ""))
        changes = entry_changes(set(ids) | watch, before)
        renamed = sum(1 for c in changes if c["before"].get("trip_name") != c["after"].get("trip_name"))
        message = "Renamed trip {} to {} on {} sighting{}.".format(old.strip(), name, renamed, "" if renamed == 1 else "s")
        if start:
            message += " {} runs {} to {}.".format(name, start, end)
        db().log_activity("trip.rename", message, {"from": old.strip(), "to": name, "ids": ids, "changes": changes})
        return jsonify({"success": True, "name": name, "updated": len(ids), "message": message})

    @app.get("/api/catalog/seen-before")
    def catalog_seen_before():
        """Soft pad hint: prior sightings of a lead loco or train symbol."""
        _all, filtered = dashboard_entries()
        try:
            exclude = request.args.get("exclude_id")
            exclude_id = int(exclude) if exclude not in (None, "") else None
        except ValueError:
            exclude_id = None
        payload = analytics.seen_before(
            filtered,
            lead=request.args.get("lead") or "",
            symbol=request.args.get("symbol") or "",
            exclude_id=exclude_id,
        )
        return jsonify({"success": True, **payload})

    @app.get("/api/catalog/periods")
    def catalog_periods():
        entries = db().list_entries()
        picks = [request.args.get("a", ""), request.args.get("b", "")]
        try:
            sides = []
            trip_info = db().trip_details()
            for pick in picks:
                if not pick:
                    continue
                side = analytics.period_summary(entries, pick)
                side["rows"].extend(_period_rate_rows(analytics.period_entries(entries, pick), entries, trip_info))
                sides.append(side)
        except ValueError as exc:
            return jsonify({"success": False, "error": str(exc), "choices": analytics.period_choices(entries)}), 400
        return jsonify({"success": True, "choices": analytics.period_choices(entries), "sides": sides})

    @app.get("/api/catalog")
    def catalog_dashboard():
        all_entries, filtered = dashboard_entries()
        payload = dashboard(filtered, all_entries)
        dates = sorted(
            {getattr(entry, "date", None) or "" for entry in all_entries if getattr(entry, "date", None)}
        )
        payload["log"]["span"] = {
            "trains": len(all_entries),
            "first_date": dates[0] if dates else "",
            "last_date": dates[-1] if dates else "",
        }
        payload["trips"] = db().list_trips()
        details = db().trip_details()
        for report in payload["log"].get("trip_reports") or []:
            report["details"] = details.get(str(report.get("trip") or "").strip().lower())
        payload["log"]["facts"].extend(_fuel_facts(payload["log"].get("trip_reports") or []))
        return jsonify(payload)

    @app.get("/api/activity")
    def activity():
        try:
            limit = int(request.args.get("limit") or 500)
        except (TypeError, ValueError):
            limit = 500
        items = db().list_activity(limit)
        wanted = set()
        for item in items:
            payload = item.get("payload")
            if isinstance(payload, dict) and isinstance(payload.get("ids"), list):
                wanted.update(int(i) for i in payload["ids"][:60] if str(i).isdigit())
        if wanted:
            found = db().entries_by_ids(sorted(wanted))
            for item in items:
                payload = item.get("payload")
                if isinstance(payload, dict) and isinstance(payload.get("ids"), list):
                    item["entries"] = [
                        found[int(i)] for i in payload["ids"][:60] if str(i).isdigit() and int(i) in found
                    ]
        return jsonify({"success": True, "activity": items, "count": len(items)})

    @app.post("/api/activity/clear")
    def activity_clear():
        payload = request.get_json(silent=True) or {}
        if payload.get("confirm") is not True:
            raise ValidationError("Confirmation is required to clear activity")
        deleted = db().clear_activity()
        return jsonify(
            {
                "success": True,
                "deleted": deleted,
                "message": "Cleared {} row{}.".format(deleted, "" if deleted == 1 else "s"),
            }
        )

    @app.post("/api/catalog/reload")
    def catalog_reload():
        work_begin("Reloading station book…")
        try:
            reload_acronyms()
            payload = dashboard()
        finally:
            work_finish()
        message = "Reloaded {} subdivision files.".format(payload["totals"]["files"])
        db().log_activity(
            "catalog.reload",
            message,
            {"files": payload["totals"]["files"], "locations": payload["totals"]["locations"]},
        )
        return jsonify({"success": True, "message": message, **payload})

    @app.post("/api/catalog/restore-shipped")
    def catalog_restore_shipped():
        work_begin("Restoring shipped subdivisions…")
        try:
            result = restore_shipped_subdivisions()
            payload = dashboard()
        finally:
            work_finish()
        db().log_activity(
            "catalog.restore_shipped",
            result["message"],
            {"restored": result["restored"], "unhidden": result["unhidden"], "backup": result["backup"]},
        )
        return jsonify({**payload, **result})

    def data_update_error(exc: data_updates.DataUpdateError):
        return jsonify({"success": False, "error": exc.message, **data_updates.status()}), 400

    def data_update_done(action: str, summary: str):
        state = data_updates.status()
        db().log_activity(action, summary, {"data_version": state["data_version"], "source": state["source"]})
        return jsonify({"success": True, "message": summary, **state})

    @app.get("/api/data-updates")
    def data_update_status():
        return jsonify({"success": True, **data_updates.status()})

    @app.post("/api/data-updates/check")
    def data_update_check():
        try:
            found = data_updates.check()
        except data_updates.DataUpdateError as exc:
            return data_update_error(exc)
        found.pop("_asset", None)
        return jsonify({"success": True, **found})

    @app.post("/api/data-updates/install")
    def data_update_install():
        work_begin("Downloading the data update…")
        try:
            data_updates.install_latest()
        except data_updates.DataUpdateError as exc:
            return data_update_error(exc)
        finally:
            work_finish()
        return data_update_done("data.update", "Installed the latest station book and symbol lists.")

    @app.post("/api/data-updates/receive")
    def data_update_receive():
        if not app.config["FIELD"]:
            return jsonify({"success": False, "error": "Only the field app takes data from the Mac."}), 403
        data = request.get_data()
        expected = (request.headers.get("X-Pack-Sha256") or "").lower()
        if expected and hashlib.sha256(data).hexdigest() != expected:
            return jsonify({"success": False, "error": "The data from the Mac arrived damaged. Sync again."}), 400
        try:
            data_updates.install_pack(data, trusted=True)
        except data_updates.DataUpdateError as exc:
            return data_update_error(exc)
        return data_update_done("data.update", "Got the latest station book and symbol lists from the Mac.")

    @app.post("/api/data-updates/built-in")
    def data_update_built_in():
        data_updates.use_built_in()
        return data_update_done("data.built_in", "Went back to the station book and symbol lists built into TRAIN LOG.")

    def mac_only_updates():
        if app.config["FIELD"]:
            return jsonify({"success": False, "error": "The field app gets updates from the Mac."}), 403
        return None

    def updates_info():
        return {
            "key": updater.has_key(),
            "app_version": APP_VERSION,
            "self_update": updater.self_update_problem(updater.app_bundle()),
            "data": data_updates.status(),
        }

    @app.get("/api/updates")
    def updates_status():
        return mac_only_updates() or jsonify({"success": True, **updates_info()})

    @app.post("/api/updates/key")
    def updates_save_key():
        refused = mac_only_updates()
        if refused:
            return refused
        payload = request.get_json(silent=True) or {}
        try:
            updater.save_key(payload.get("key") or "")
        except updater.UpdateError as exc:
            return jsonify({"success": False, "error": exc.message}), 400
        db().log_activity("updates.key", "Saved the key code for updates.", {})
        return jsonify({"success": True, "message": "Key code saved.", **updates_info()})

    @app.delete("/api/updates/key")
    def updates_forget_key():
        refused = mac_only_updates()
        if refused:
            return refused
        updater.forget_key()
        return jsonify({"success": True, **updates_info()})

    @app.post("/api/updates/check")
    def updates_check():
        refused = mac_only_updates()
        if refused:
            return refused
        try:
            found = updater.check()
        except updater.UpdateError as exc:
            return jsonify({"success": False, "error": exc.message, **updates_info()}), 400
        found.pop("_assets", None)
        return jsonify({"success": True, **found, **updates_info()})

    @app.get("/api/updates/auto")
    def updates_auto():
        if app.config["FIELD"]:
            return jsonify({"success": True, "configured": False, "available": False})
        return jsonify({"success": True, **updater.auto()})

    @app.post("/api/updates/app/install")
    def updates_install_app():
        refused = mac_only_updates()
        if refused:
            return refused
        work_begin("Downloading the new TRAIN LOG…")

        def progress(done, total):
            mb = 1024 * 1024
            message = "Downloaded {:.0f} of {:.0f} MB".format(done / mb, total / mb) if total else ""
            work_update(current=done // mb, total=total // mb, message=message or None)

        def status(message):
            work_update(message=message, title=message)

        try:
            ready = updater.stage_app(progress, on_status=status)
        except updater.UpdateError as exc:
            return jsonify({"success": False, "error": exc.message, **updates_info()}), 400
        finally:
            work_finish()
        db().log_activity(
            "app.update",
            "Downloaded TRAIN LOG {}. It opens after TRAIN LOG restarts.".format(ready["version"]),
            {"from": APP_VERSION, "to": ready["version"]},
        )
        return jsonify({"success": True, "ready": True, "version": ready["version"]})

    @app.get("/api/catalog/subdivisions/<path:filename>")
    def catalog_subdivision_get(filename):
        return jsonify({"success": True, **get_subdivision(filename)})

    @app.post("/api/catalog/subdivisions")
    def catalog_subdivision_create():
        payload = request.get_json(silent=True) or {}
        info = save_subdivision(
            payload.get("filename") or "",
            payload.get("railroads") or [],
            payload.get("subdivision") or "",
            payload.get("locations") or [],
            create=True,
        )
        info["success"] = True
        db().log_activity(
            "subdivision.create",
            info.get("message") or "Added subdivision.",
            {
                "filename": info.get("filename"),
                "subdivision": info.get("subdivision"),
                "railroads": info.get("railroads"),
                "locations": info.get("locations"),
            },
        )
        return jsonify(info), 201

    @app.put("/api/catalog/subdivisions/<path:filename>")
    def catalog_subdivision_save(filename):
        payload = request.get_json(silent=True) or {}
        info = save_subdivision(
            filename,
            payload.get("railroads") or [],
            payload.get("subdivision") or "",
            payload.get("locations") or [],
            create=False,
        )
        info["success"] = True
        db().log_activity(
            "subdivision.update",
            info.get("message") or "Updated subdivision.",
            {
                "filename": info.get("filename"),
                "subdivision": info.get("subdivision"),
                "railroads": info.get("railroads"),
                "locations": info.get("locations"),
            },
        )
        return jsonify(info)

    @app.delete("/api/catalog/subdivisions/<path:filename>")
    def catalog_subdivision_delete(filename):
        snapshot = None
        try:
            snapshot = get_subdivision(filename)
        except ValidationError:
            snapshot = {"filename": Path(filename or "").name}
        result = delete_subdivision(filename)
        db().log_activity(
            "subdivision.delete",
            result.get("message") or "Removed subdivision.",
            snapshot,
        )
        return jsonify(result)

    @app.post("/api/catalog/subdivisions/<path:filename>/hide")
    def catalog_subdivision_hide(filename):
        snapshot = None
        try:
            snapshot = get_subdivision(filename)
        except ValidationError:
            snapshot = {"filename": Path(filename or "").name}
        result = hide_subdivision(filename)
        db().log_activity(
            "subdivision.hide",
            result.get("message") or "Hid subdivision.",
            snapshot,
        )
        return jsonify(result)

    @app.post("/api/catalog/subdivisions/<path:filename>/unhide")
    def catalog_subdivision_unhide(filename):
        result = unhide_subdivision(filename)
        db().log_activity(
            "subdivision.unhide",
            result.get("message") or "Unhid subdivision.",
            {"filename": result.get("filename")},
        )
        return jsonify(result)

    @app.post("/api/catalog/railroads")
    def catalog_railroads_add():
        payload = request.get_json(silent=True) or {}
        saved = add_railroad(
            payload.get("name") or "",
            payload.get("group") or payload.get("label") or "Freight",
            str(payload.get("rr_class") or ""),
        )
        name = saved.get("name") or str(payload.get("name") or "").strip().upper()
        meaning = str(payload.get("meaning") or "").strip()
        meanings = list_meanings()
        if meaning:
            meanings = save_meanings({"railroads": {name: meaning}})
        db().log_activity(
            "railroad.save",
            "Added railroad {}.".format(name),
            {"name": name, "meaning": meaning, **saved},
        )
        return jsonify({"success": True, **saved, "meanings": meanings})

    @app.put("/api/catalog/railroads")
    def catalog_railroads_save():
        payload = request.get_json(silent=True) or {}
        groups = payload.get("groups")
        if not isinstance(groups, list):
            raise ValidationError("Railroad groups are required", "groups")
        saved = save_railroads(groups)
        db().log_activity("railroad.save", "Updated railroad list.", saved)
        return jsonify({"success": True, **saved})

    @app.post("/api/catalog/railroads/class")
    def catalog_railroads_class():
        payload = request.get_json(silent=True) or {}
        name = str(payload.get("name") or "").strip().upper()
        rr_class = str(payload.get("rr_class") or "")
        saved = set_railroad_class(name, rr_class)
        label = saved["classes"].get(name, "")
        db().log_activity(
            "railroad.save",
            "Set {} to {}.".format(name, label) if label else "Cleared the class for {}.".format(name),
            {"name": name, "rr_class": label},
        )
        return jsonify({"success": True, **saved})

    @app.post("/api/catalog/railroads/reset")
    def catalog_railroads_reset():
        reset_railroad_meanings()
        restored = reset_railroads()
        db().log_activity("railroad.reset", "Restored railroad defaults.", restored)
        return jsonify({"success": True, **restored})

    @app.get("/api/catalog/types")
    def catalog_types():
        return jsonify({"success": True, "types": list_types()})

    @app.post("/api/catalog/types")
    def catalog_types_add():
        payload = request.get_json(silent=True) or {}
        types = add_type(payload.get("name") or "")
        meaning = str(payload.get("meaning") or "").strip()
        if meaning:
            save_meanings({"types": {str(payload.get("name") or "").strip(): meaning}})
        name = str(payload.get("name") or "").strip()
        meanings = list_meanings()
        db().log_activity(
            "type.add",
            "Added train type {}.".format(name),
            {"name": name, "meaning": meaning, "types": types},
        )
        return jsonify({"success": True, "types": types, "meanings": meanings})

    @app.delete("/api/catalog/types/<path:name>")
    def catalog_types_delete(name):
        meanings = list_meanings()
        meaning = (meanings.get("types") or {}).get(name)
        types = remove_type(name)
        db().log_activity(
            "type.delete",
            "Removed train type {}.".format(name),
            {"name": name, "meaning": meaning, "types": types},
        )
        return jsonify({"success": True, "types": types})

    @app.put("/api/catalog/types")
    def catalog_types_order():
        payload = request.get_json(silent=True) or {}
        names = payload.get("types")
        if not isinstance(names, list):
            raise ValidationError("Train type order is required", "types")
        types = save_type_order(names)
        db().log_activity("type.order", "Reordered train types.", {"types": types})
        return jsonify({"success": True, "types": types})

    @app.post("/api/catalog/types/reset")
    def catalog_types_reset():
        reset_type_meanings()
        types = reset_types()
        meanings = list_meanings()
        db().log_activity("type.reset", "Restored train type defaults.", {"types": types})
        return jsonify({"success": True, "types": types, "meanings": meanings})

    @app.get("/api/catalog/type-filters")
    def catalog_type_filters():
        return jsonify({"success": True, "type_filters": list_type_filters(), "types": list_types()})

    @app.post("/api/catalog/type-filters")
    def catalog_type_filters_add():
        payload = request.get_json(silent=True) or {}
        incoming = str(payload.get("incoming") or payload.get("from") or "").strip()
        stored = str(payload.get("stored") or payload.get("to") or "").strip()
        filters = add_type_filter(incoming, stored)
        db().log_activity(
            "type.filter.add",
            "Import maps {} to {}.".format(incoming, stored),
            {"incoming": incoming, "stored": stored, "type_filters": filters},
        )
        return jsonify({"success": True, "type_filters": filters, "types": list_types()})

    @app.post("/api/catalog/type-filters/reset")
    def catalog_type_filters_reset():
        filters = reset_type_filters()
        db().log_activity("type.filter.reset", "Restored import filter defaults.", {"type_filters": filters})
        return jsonify({"success": True, "type_filters": filters, "types": list_types()})

    @app.delete("/api/catalog/type-filters/<path:incoming>")
    def catalog_type_filters_delete(incoming):
        filters = remove_type_filter(incoming)
        db().log_activity(
            "type.filter.delete",
            "Removed import filter {}.".format(incoming),
            {"incoming": incoming, "type_filters": filters},
        )
        return jsonify({"success": True, "type_filters": filters, "types": list_types()})

    @app.put("/api/catalog/acronyms")
    def catalog_acronyms_save():
        payload = request.get_json(silent=True) or {}
        meanings = save_meanings(payload)
        db().log_activity("acronym.save", "Updated stands-for list.", payload)
        return jsonify({"success": True, "meanings": meanings})

    @app.get("/api/subdivisions")
    def subdivisions():
        return jsonify(
            {
                "grouped": grouped_subdivisions(),
                "counts": subdivision_location_counts(),
            }
        )

    @app.post("/api/subdivisions/import")
    def subdivisions_import():
        uploaded = request.files.get("file")
        if uploaded is None or not uploaded.filename:
            raise ValidationError("Choose a subdivision CSV", "file")
        work_begin("Importing subdivision CSV…")
        try:
            info = import_subdivision_csv(uploaded.filename, uploaded.read())
        finally:
            work_finish()
        info["grouped"] = grouped_subdivisions()
        info["counts"] = subdivision_location_counts()
        info["success"] = True
        db().log_activity(
            "subdivision.import",
            info.get("message") or "Imported subdivision CSV.",
            {
                "filename": info.get("filename"),
                "subdivision": info.get("subdivision"),
                "railroads": info.get("railroads"),
                "stations": info.get("stations"),
            },
        )
        return jsonify(info)

    def _log_inbound(result: dict) -> None:
        for info in result.get("imported") or []:
            db().log_activity(
                "subdivision.inbound",
                info.get("message") or "Imported a subdivision CSV from the watch folder.",
                {
                    "filename": info.get("filename"),
                    "subdivision": info.get("subdivision"),
                    "railroads": info.get("railroads"),
                    "stations": info.get("stations"),
                    "inbound": info.get("inbound"),
                },
            )
        for item in result.get("failed") or []:
            db().log_activity(
                "subdivision.inbound_failed",
                item.get("error") or "Could not import a CSV from the watch folder.",
                {"file": item.get("file")},
            )

    @app.get("/api/subdivisions/inbound")
    def subdivisions_inbound():
        inbound_dir()
        return jsonify({"success": True, **inbound_status()})

    @app.post("/api/subdivisions/inbound")
    def subdivisions_inbound_ingest():
        result = ingest_inbound_csvs()
        _log_inbound(result)
        result["grouped"] = grouped_subdivisions()
        result["counts"] = subdivision_location_counts()
        result["success"] = True
        return jsonify(result)

    @app.post("/api/subdivisions/inbound/open")
    def subdivisions_inbound_open():
        folder = inbound_dir()
        if sys.platform != "darwin":
            return jsonify({"success": False, "error": "Open the folder by hand: " + str(folder), "path": str(folder)}), 400
        try:
            subprocess.Popen(["open", str(folder)])
        except OSError:
            return jsonify({"success": False, "error": "Could not open " + str(folder), "path": str(folder)}), 500
        return jsonify({"success": True, "path": str(folder)})

    @app.get("/api/locomotives/last")
    def locomotives_last():
        railroad = request.args.get("railroad") or None
        last = db().last_locomotive(railroad)
        last_entry = db().last_entry()
        return jsonify(
            {
                "success": True,
                "locomotive": last,
                "last_entry": last_entry.to_dict() if last_entry else None,
            }
        )

    @app.post("/api/import")
    def import_entries():
        source = "upload"
        records = None
        work_begin("Reading import file…")
        try:
            if request.files.get("file"):
                uploaded = request.files["file"]
                source = uploaded.filename or "upload"
                records = parse_import_payload(source, uploaded.read())
            else:
                payload = request.get_json(silent=True)
                if payload is None:
                    raise ValidationError("Upload a CSV/JSON file or send JSON")
                if isinstance(payload, dict) and isinstance(payload.get("csv"), str):
                    source = payload.get("source") or "upload.csv"
                    records = parse_tabular_records(payload["csv"])
                elif isinstance(payload, dict) and isinstance(payload.get("entries"), list):
                    records = payload["entries"]
                    source = payload.get("source") or "json"
                elif isinstance(payload, list):
                    records = payload
                else:
                    records = [payload]
        finally:
            work_finish()
        result = db().import_records(records or [], source=source)
        created = result["created"]
        pending = result["pending"]
        errors = result["errors"]
        already = result.get("already", 0)
        if already and not created and not pending and not errors:
            message = "All {} trains in that file are already in the log.".format(already)
        elif not created and not pending and not errors:
            message = "No trains found in that file."
        elif not created and not pending and errors:
            message = "Could not import that CSV. {n} row(s) skipped: {err}".format(
                n=len(errors), err=errors[0]["error"]
            )
        else:
            message = "Imported {created} entries; {pending} held for review".format(
                created=created, pending=pending
            )
            if already:
                message += "; {} already in the log".format(already)
            if errors:
                message += "; {n} row(s) skipped ({err})".format(
                    n=len(errors), err=errors[0]["error"]
                )
            guesses = []
            if result.get("guessed_subdivisions"):
                guesses.append("subdivision on {}".format(result["guessed_subdivisions"]))
            if result.get("guessed_time_zones"):
                guesses.append("time zone on {}".format(result["guessed_time_zones"]))
            if guesses:
                message += ". Guessed {}; check them in Import Review".format(" and ".join(guesses))
            elif result.get("to_check"):
                message += ". {} need a subdivision or time zone; see Import Review".format(result["to_check"])
        return jsonify(
            {
                "success": True,
                "count": created,
                "pending": pending,
                "already": already,
                "errors": errors,
                "guessed_subdivisions": result.get("guessed_subdivisions", 0),
                "guessed_time_zones": result.get("guessed_time_zones", 0),
                "to_check": result.get("to_check", 0),
                "message": message,
            }
        )

    @app.get("/api/import/pending")
    def import_pending():
        items = [item.to_dict() for item in db().list_pending("pending")]
        review = db().import_review_count()
        return jsonify(
            {"success": True, "pending": items, "count": len(items), "review_count": review}
        )

    @app.get("/api/import/review")
    def import_review():
        items = db().list_import_review()
        return jsonify({"success": True, "items": items, "count": len(items)})

    @app.post("/api/import/review/apply")
    def import_review_apply():
        payload = request.get_json(silent=True) or {}
        ids = payload.get("ids")
        if not isinstance(ids, list) or not ids:
            raise ValidationError("Select at least one sighting", "ids")
        try:
            ids = [int(item) for item in ids]
        except (TypeError, ValueError):
            raise ValidationError("Sighting ids must be numbers", "ids")
        subdivision = None
        if "subdivision" in payload:
            subdivision = str(payload.get("subdivision") or "").strip()
            if len(subdivision) > 120:
                raise ValidationError("Subdivision name is too long", "subdivision")
        time_zone = None
        if "time_zone" in payload:
            time_zone = normalize_time_zone(payload.get("time_zone"))
        keep = payload.get("keep") is True
        if subdivision is None and time_zone is None and not keep:
            raise ValidationError("Pick a subdivision or time zone to set", "subdivision")
        result = db().apply_import_review(ids, subdivision=subdivision, time_zone=time_zone, keep=keep)
        n = len(ids)
        if keep and subdivision is None and time_zone is None:
            message = "Kept the guesses on {} sighting{}.".format(n, "" if n == 1 else "s")
        else:
            message = "Updated {} sighting{}.".format(result["updated"], "" if result["updated"] == 1 else "s")
        return jsonify(
            {
                "success": True,
                "updated": result["updated"],
                "cleared": result["cleared"],
                "remaining": db().import_review_count(),
                "message": message,
            }
        )

    @app.post("/api/import/pending/<int:pending_id>/accept")
    def import_accept(pending_id: int):
        body = request.get_json(silent=True) or {}
        edited = body.get("entry") if isinstance(body, dict) else None
        if edited is not None and not isinstance(edited, dict):
            raise ValidationError("Edited entry must be an object", "entry")
        entry = db().accept_pending(pending_id, edited)
        message = "Held import added to the log as #{}".format(entry.id)
        return jsonify({"success": True, "id": entry.id, "entry": entry.to_dict(), "message": message})

    @app.post("/api/import/pending/<int:pending_id>/resolve")
    def import_resolve(pending_id: int):
        body = request.get_json(silent=True) or {}
        resolution = body.get("resolution") if isinstance(body, dict) else None
        if not isinstance(resolution, str) or not resolution.strip():
            raise ValidationError("Pick keep_both, prefer_existing, or prefer_incoming", "resolution")
        result = db().resolve_pending(pending_id, resolution)
        labels = {
            "keep_both": "Kept both copies",
            "prefer_existing": "Kept the Mac copy",
            "prefer_incoming": "Replaced the Mac copy with the incoming one",
        }
        message = labels.get(result["resolution"], "Resolved")
        entry = result.get("entry")
        if entry and result["resolution"] == "keep_both":
            message = "Kept both — incoming added as #{}".format(entry["id"])
        elif entry and result["resolution"] == "prefer_incoming":
            message = "Preferred incoming — updated #{}".format(entry["id"])
        return jsonify({"success": True, "message": message, **result})

    @app.post("/api/import/pending/<int:pending_id>/discard")
    def import_discard(pending_id: int):
        if not db().discard_pending(pending_id):
            return jsonify({"success": False, "error": "Pending import not found"}), 404
        return jsonify({"success": True, "message": "Pending entry discarded"})

    @app.get("/api/sync/outbox")
    def sync_outbox():
        items = db().sync_outbox()
        return jsonify(
            {
                "success": True,
                "entries": items,
                "trips": [trip for trip in db().trip_details().values()],
                "count": len(items),
                "changed": sum(1 for item in items if item.get("changed")),
            }
        )

    @app.post("/api/sync/sent")
    def sync_sent():
        payload = request.get_json(silent=True) or {}
        items = payload.get("items")
        if not isinstance(items, list):
            raise ValidationError("Send the sightings the Mac received", "items")
        marked = db().mark_synced(item for item in items if isinstance(item, dict))
        return jsonify({"success": True, "marked": marked, "remaining": len(db().sync_outbox())})

    @app.post("/api/sync/reset")
    def sync_reset():
        cleared = db().clear_sync_sent()
        return jsonify({"success": True, "cleared": cleared, "remaining": len(db().sync_outbox())})

    @app.post("/api/log-snapshots")
    def log_snapshot_write():
        name = db().write_log_snapshot()
        durability.prune_log_snapshots()
        return jsonify({"success": True, "name": name, **durability.snapshot_status(db())})

    @app.get("/api/log-snapshots")
    def log_snapshot_list():
        return jsonify({"success": True, **durability.snapshot_status(db())})

    @app.put("/api/log-snapshots/settings")
    def log_snapshot_settings():
        payload = request.get_json(silent=True) or {}
        settings = durability.save_settings(payload if isinstance(payload, dict) else {})
        durability.prune_log_snapshots(settings["snapshot_keep"])
        return jsonify({"success": True, **durability.snapshot_status(db())})

    @app.post("/api/log-snapshots/restore")
    def log_snapshot_restore():
        payload = request.get_json(silent=True) or {}
        result = db().restore_log_snapshot(str(payload.get("name") or ""))
        return jsonify({"success": True, **result})

    @app.get("/api/storage")
    def storage_usage():
        report = durability.storage_report(Path(db().path))
        return jsonify({"success": True, **report})

    @app.post("/api/storage/dismiss")
    def storage_dismiss():
        payload = request.get_json(silent=True) or {}
        try:
            bytes_now = int((payload or {}).get("bytes") or 0)
        except (TypeError, ValueError):
            bytes_now = 0
        settings = durability.dismiss_disk_banner(bytes_now)
        return jsonify({"success": True, "settings": settings})

    @app.get("/api/integrity")
    def integrity_check():
        return jsonify({"success": True, **durability.integrity_report(db())})

    @app.get("/api/phone-sync")
    def phone_sync_status():
        return jsonify({"success": True, **phone_sync.status()})

    @app.post("/api/phone-sync")
    def phone_sync_toggle():
        payload = request.get_json(silent=True) or {}
        on = payload.get("enabled") is True
        phone_sync.set_enabled(on, db)
        db().log_activity("phone_sync." + ("on" if on else "off"), "Field sync turned {}.".format("on" if on else "off"))
        state = phone_sync.status()
        return jsonify({"success": not state["error"], **state})

    @app.post("/api/phone-sync/code")
    def phone_sync_code():
        phone_sync.refresh_code()
        return jsonify({"success": True, **phone_sync.status()})

    @app.post("/api/phone-sync/firewall")
    def phone_sync_firewall():
        result = phone_sync.allow_through_firewall()
        if result["success"]:
            db().log_activity("phone_sync.firewall", "Let phones through the Mac firewall.")
        return jsonify({**phone_sync.status(), **result}), (200 if result["success"] else 400)

    @app.post("/api/phone-sync/reveal-certificate")
    def phone_sync_reveal_certificate():
        """Show the Mac CA certificate in Finder so it can be AirDropped — skips a hung :5080 page."""
        import subprocess

        paths = phone_sync.ensure_certificates()
        cer = paths["ca_cert"]
        if not cer.is_file():
            return jsonify({"success": False, "error": "Certificate isn't ready yet. Turn Field Sync on first."}), 400
        # Prefer a .cer beside the PEM so the field device accepts AirDrop install.
        der = phone_sync.sync_dir() / "train-log-certificate.cer"
        try:
            der.write_bytes(phone_sync.ca_certificate_der())
        except OSError as exc:
            return jsonify({"success": False, "error": "Could not write the certificate file: {}".format(exc)}), 500
        try:
            subprocess.run(["open", "-R", str(der)], check=False)
        except OSError as exc:
            return jsonify({"success": False, "error": "Could not open Finder: {}".format(exc)}), 500
        return jsonify({"success": True, "path": str(der)})

    @app.delete("/api/phone-sync/devices/<device_id>")
    def phone_sync_remove(device_id: str):
        if not phone_sync.remove_device(device_id):
            return jsonify({"success": False, "error": "That device isn't paired."}), 404
        db().log_activity("phone_sync.remove", "Unpaired a phone.", {"device": device_id})
        return jsonify({"success": True, **phone_sync.status()})

    @app.get("/api/export")
    def export_entries():
        fmt = (request.args.get("format") or "json").lower()
        rows = db().export_rows(entry_filters())
        if fmt == "csv":
            body = rows_to_csv(rows)
            return Response(
                body,
                mimetype="text/csv",
                headers={"Content-Disposition": "attachment; filename=train-log.csv"},
            )
        return Response(
            json.dumps(rows, indent=2, ensure_ascii=False),
            mimetype="application/json",
            headers={"Content-Disposition": "attachment; filename=train-log.json"},
        )

    inbound_dir()
    if watch_inbound:
        def _inbound_loop() -> None:
            while True:
                time.sleep(4)
                try:
                    result = ingest_inbound_csvs()
                    if result.get("imported") or result.get("failed"):
                        _log_inbound(result)
                except Exception:
                    app.logger.exception("Inbound subdivision watch failed")
                    debug_log.record("server.watch_folder", "Watch folder check failed", {"traceback": traceback.format_exc()[-4000:]})

        threading.Thread(target=_inbound_loop, name="inbound-subs", daemon=True).start()

    if serve_phones and phone_sync.load_state()["enabled"]:
        phone_sync.start(db)

    try:
        durability.maybe_auto_snapshot(db())
    except Exception:
        pass

    return app


def main() -> None:
    application = create_app(watch_inbound=True, serve_phones=True)
    application.run(host="127.0.0.1", port=5057, debug=False, use_reloader=False)


if __name__ == "__main__":
    main()
