"""Dataclasses for Railroad Train Log records."""
from __future__ import annotations

import json
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional

from railroads import KNOWN_RAILROADS  # noqa: F401
from special_power import normalize_special_power
from train_types import (  # noqa: F401
    DEFAULT_TRAIN_TYPES,
    TYPE_ALIASES,
    canonicalize_train_types,
    list_types,
    normalize_train_type,
)

TRAIN_TYPES = DEFAULT_TRAIN_TYPES
DIRECTIONS = ("North", "South", "East", "West")
LEAD_STATUSES = ("Missed", "Hidden", "Too dark to see", "Too far", "Weather")
LOAD_STATUSES = ("Loads", "Empties")
LOAD_ALIASES = {
    "LOAD": "Loads",
    "LOADS": "Loads",
    "LOADED": "Loads",
    "FULL": "Loads",
    "EMPTY": "Empties",
    "EMPTIES": "Empties",
    "MT": "Empties",
}
DIRECTION_ALIASES = {
    "N": "North",
    "S": "South",
    "E": "East",
    "W": "West",
    "NORTH": "North",
    "SOUTH": "South",
    "EAST": "East",
    "WEST": "West",
}
STOPPED_WORDS = ("STOPPED", "STOP", "HELD")
SIDING_WORDS = ("IN SIDING", "SIDING", "PARKED", "TIED DOWN")
CREW_WORDS = ("CREW CHANGE", "CREW CHG")
NO_CREW_WORDS = ("NO CREW", "NO CREW ONBOARD", "NO CREW ON BOARD", "UNMANNED", "UNCREWED")
DEFAULT_REGION = "Phoenix, AZ"


def _as_bool(value: Any) -> bool:
    if isinstance(value, bool):
        return value
    if value in (None, "", 0, "0", "false", "False", "no"):
        return False
    return True


def parse_types_value(value: Any) -> List[str]:
    """Parse train types from a list, JSON array, pipes, or slash-separated string."""
    if value is None or value == "":
        return []
    if isinstance(value, list):
        return canonicalize_train_types(value)
    text = str(value).strip()
    if text.startswith("["):
        try:
            loaded = json.loads(text)
            if isinstance(loaded, list):
                return canonicalize_train_types(loaded)
        except json.JSONDecodeError:
            pass
    if "|" in text:
        return canonicalize_train_types([part for part in text.split("|") if part.strip()])
    return canonicalize_train_types([text])


def types_to_storage(types: List[str]) -> str:
    return json.dumps(types, ensure_ascii=False)


@dataclass
class TrainEntry:
    date: str
    time: str
    railroad: str
    lead_locomotive: str
    direction: str
    power_consist: str
    train_types: List[str]
    car_counts: str
    location_spot: str
    location_subdivision: str = ""
    location_state: str = ""
    location_region: str = DEFAULT_REGION
    location_coordinates: Optional[str] = None
    notes: str = ""
    train_symbol: str = ""
    train_number: str = ""
    train_info: str = ""
    special_power: str = ""
    photographed: bool = False
    videoed: bool = False
    load_status: str = ""
    trip_name: str = ""
    trip_date_from: str = ""
    trip_date_to: str = ""
    time_zone: str = ""
    lead_status: str = ""
    night: bool = False
    stopped: bool = False
    in_siding: bool = False
    crew_change: bool = False
    no_crew: bool = False
    coal_mark: str = ""
    con_overseas: bool = False
    con_domestic: bool = False
    uid: str = ""
    id: Optional[int] = None
    created_at: Optional[str] = None
    updated_at: Optional[str] = None

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id,
            "uid": self.uid or "",
            "date": self.date,
            "time": self.time,
            "railroad": self.railroad,
            "lead_locomotive": self.lead_locomotive,
            "direction": DIRECTION_ALIASES.get((self.direction or "").upper(), self.direction or ""),
            "power_consist": self.power_consist,
            "train_types": list(self.train_types),
            "train_types_label": "/".join(self.train_types),
            "car_counts": self.car_counts,
            "location_spot": self.location_spot,
            "location_subdivision": self.location_subdivision or "",
            "location_state": self.location_state or "",
            "location_region": self.location_region or DEFAULT_REGION,
            "location_coordinates": self.location_coordinates,
            "notes": self.notes or "",
            "train_symbol": self.train_symbol or "",
            "train_number": self.train_number or "",
            "train_info": self.train_info or "",
            "special_power": normalize_special_power(self.special_power),
            "photographed": bool(self.photographed),
            "videoed": bool(self.videoed),
            "load_status": self.load_status or "",
            "trip_name": self.trip_name or "",
            "trip_date_from": self.trip_date_from or "",
            "trip_date_to": self.trip_date_to or "",
            "time_zone": self.time_zone or "",
            "lead_status": self.lead_status or "",
            "night": bool(self.night),
            "stopped": bool(self.stopped),
            "in_siding": bool(self.in_siding),
            "crew_change": bool(self.crew_change),
            "no_crew": bool(self.no_crew),
            "coal_mark": self.coal_mark or "",
            "con_overseas": bool(self.con_overseas),
            "con_domestic": bool(self.con_domestic),
            "created_at": self.created_at,
            "updated_at": self.updated_at,
        }

    @classmethod
    def from_row(cls, row: Any) -> "TrainEntry":
        mapping = dict(row)
        return cls(
            id=mapping.get("id"),
            date=mapping.get("date") or "",
            time=mapping.get("time") or "",
            railroad=mapping.get("railroad") or "",
            lead_locomotive=mapping.get("lead_locomotive") or "",
            direction=mapping.get("direction") or "",
            power_consist=mapping.get("power_consist") or "",
            train_types=parse_types_value(mapping.get("train_types")),
            car_counts=mapping.get("car_counts") or "",
            location_spot=mapping.get("location_spot") or "",
            location_subdivision=mapping.get("location_subdivision") or "",
            location_state=str(mapping.get("location_state") or "").strip(),
            location_region=mapping.get("location_region") or DEFAULT_REGION,
            location_coordinates=mapping.get("location_coordinates"),
            notes=mapping.get("notes") or "",
            train_symbol=str(mapping.get("train_symbol") or "").strip(),
            train_number=str(mapping.get("train_number") or "").strip(),
            train_info=str(mapping.get("train_info") or "").strip(),
            special_power=str(mapping.get("special_power") or "").strip(),
            photographed=_as_bool(mapping.get("photographed")),
            videoed=_as_bool(mapping.get("videoed")),
            load_status=str(mapping.get("load_status") or "").strip(),
            trip_name=str(mapping.get("trip_name") or "").strip(),
            trip_date_from=str(mapping.get("trip_date_from") or "").strip(),
            trip_date_to=str(mapping.get("trip_date_to") or "").strip(),
            time_zone=str(mapping.get("time_zone") or "").strip(),
            lead_status=str(mapping.get("lead_status") or "").strip(),
            night=_as_bool(mapping.get("night")),
            stopped=_as_bool(mapping.get("stopped")),
            in_siding=_as_bool(mapping.get("in_siding")),
            crew_change=_as_bool(mapping.get("crew_change")),
            no_crew=_as_bool(mapping.get("no_crew")),
            coal_mark=str(mapping.get("coal_mark") or "").strip(),
            con_overseas=_as_bool(mapping.get("con_overseas")),
            con_domestic=_as_bool(mapping.get("con_domestic")),
            uid=str(mapping.get("uid") or ""),
            created_at=mapping.get("created_at"),
            updated_at=mapping.get("updated_at"),
        )


@dataclass
class LocationHistory:
    location_spot: str
    location_subdivision: str = ""
    location_region: str = DEFAULT_REGION
    last_used: Optional[str] = None
    use_count: int = 0
    id: Optional[int] = None

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id,
            "location_spot": self.location_spot,
            "location_subdivision": self.location_subdivision or "",
            "location_region": self.location_region or DEFAULT_REGION,
            "last_used": self.last_used,
            "use_count": self.use_count,
        }


@dataclass
class LocomotiveHistory:
    railroad: str
    lead_locomotive: str
    train_types: List[str] = field(default_factory=list)
    car_counts: str = ""
    last_used: Optional[str] = None
    id: Optional[int] = None

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id,
            "railroad": self.railroad,
            "lead_locomotive": self.lead_locomotive,
            "train_types": list(self.train_types),
            "car_counts": self.car_counts,
            "last_used": self.last_used,
        }


@dataclass
class PendingImport:
    payload: Dict[str, Any]
    source: str = ""
    reason: str = ""
    match_entry_id: Optional[int] = None
    match_entry: Optional[Dict[str, Any]] = None
    status: str = "pending"
    id: Optional[int] = None
    created_at: Optional[str] = None
    conflict: bool = False

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id,
            "source": self.source,
            "reason": self.reason,
            "payload": self.payload,
            "match_entry_id": self.match_entry_id,
            "match_entry": self.match_entry,
            "status": self.status,
            "created_at": self.created_at,
            "conflict": bool(self.conflict),
        }
