"""Heritage units and steam engines logged with a train."""
from __future__ import annotations

import json
import re
from functools import lru_cache
from typing import Any, Dict, Iterable, List

from data_updates import reference_path
from paths import support_dir

ERAS = {"a250": "America 250"}
POSITIONS = {"lead": "Leading", "trail": "Trailing", "dp": "DP", "assist": "Steam assist"}

WHEEL_ARRANGEMENTS = [
    ["0-4-0", "Four-wheel switcher"],
    ["0-6-0", "Six-wheel switcher"],
    ["0-8-0", "Eight-wheel switcher"],
    ["2-6-0", "Mogul"],
    ["2-6-2", "Prairie"],
    ["2-8-0", "Consolidation"],
    ["2-8-2", "Mikado"],
    ["2-8-4", "Berkshire"],
    ["2-10-0", "Decapod"],
    ["2-10-2", "Santa Fe"],
    ["2-10-4", "Texas"],
    ["4-4-0", "American"],
    ["4-4-2", "Atlantic"],
    ["4-6-0", "Ten-Wheeler"],
    ["4-6-2", "Pacific"],
    ["4-6-4", "Hudson"],
    ["4-8-2", "Mountain"],
    ["4-8-4", "Northern"],
    ["2-6-6-2", "Mallet"],
    ["2-6-6-4", "Articulated"],
    ["2-8-8-2", "Articulated"],
    ["2-8-8-4", "Yellowstone"],
    ["4-6-6-4", "Challenger"],
    ["4-8-8-4", "Big Boy"],
    ["Geared", "Shay, Heisler, or Climax"],
]

_WHEELS_RE = re.compile(r"^\d{1,2}(?:-\d{1,2}){2,4}$")


_UNIT_RE = re.compile(r"^\s*([A-Z][A-Z&]*)[\s-]*(\d.*)$")


def unit_key(text: Any) -> str:
    """UP1996 for "UP 1996"; another mark for the same railroad (GCRY for GCRX) gives the same key."""
    upper = str(text or "").upper()
    match = _UNIT_RE.match(upper)
    if match:
        import railroads as rr_mod

        aliases = rr_mod.mark_aliases()
        mark = match.group(1)
        mark = aliases.get(mark) or aliases.get(mark.replace("&", "")) or mark
        upper = mark + match.group(2)
    return re.sub(r"[^A-Z0-9]", "", upper)


def _clean(text: Any, limit: int) -> str:
    return re.sub(r"\s+", " ", str(text or "")).strip()[:limit]


def _unit_text(text: Any) -> str:
    return _clean(text, 30).upper()


def _wheels(text: Any) -> str:
    value = _clean(text, 24)
    compact = value.replace(" ", "")
    if _WHEELS_RE.match(compact):
        return compact
    return value


def normalize_special_power(raw: Any) -> Dict[str, Any]:
    """Clean heritage and steam lists and the consist units; anything blank is dropped."""
    if isinstance(raw, str):
        text = raw.strip()
        if not text:
            return {"heritage": [], "steam": []}
        try:
            raw = json.loads(text)
        except ValueError:
            return {"heritage": [], "steam": []}
    if not isinstance(raw, dict):
        return {"heritage": [], "steam": []}
    heritage: List[Dict[str, Any]] = []
    for item in raw.get("heritage") or []:
        if not isinstance(item, dict):
            continue
        unit = _unit_text(item.get("unit"))
        scheme = _clean(item.get("scheme"), 60)
        if not (unit or scheme):
            continue
        era = str(item.get("era") or "").strip().lower()
        position = str(item.get("position") or "").strip().lower()
        heritage.append({
            "unit": unit,
            "scheme": scheme,
            "era": era if era in ERAS else "",
            "position": position if position in POSITIONS else "",
        })
    steam: List[Dict[str, Any]] = []
    for item in raw.get("steam") or []:
        if not isinstance(item, dict):
            continue
        engine = _unit_text(item.get("engine"))
        name = _clean(item.get("name"), 60)
        wheels = _wheels(item.get("wheels"))
        if not (engine or name or wheels):
            continue
        assist: List[str] = []
        raw_assist = item.get("assist") or []
        if isinstance(raw_assist, str):
            raw_assist = re.split(r"[,+]", raw_assist)
        for unit in raw_assist if isinstance(raw_assist, list) else []:
            unit = _unit_text(unit) if isinstance(unit, str) else ""
            if unit and unit not in assist:
                assist.append(unit)
        row = {"engine": engine, "name": name, "wheels": wheels, "diesel_assist": _flag(item.get("diesel_assist")) or bool(assist)}
        if assist:
            row["assist"] = assist[:6]
        if _flag(item.get("doubleheader")):
            row["doubleheader"] = True
        steam.append(row)
    steam = _pair_doubleheaders(steam[:6])
    cleaned: Dict[str, Any] = {"heritage": heritage[:12], "steam": steam}
    units = consist_units(raw.get("units"))
    if units:
        cleaned["units"] = units
    return cleaned


def _flag(value: Any) -> bool:
    return bool(value) and str(value).lower() not in ("0", "false", "no")


def _pair_doubleheaders(steam: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """A doubleheader is two engines in a row; the diesel assist rides behind the pair, on the first."""
    index = 0
    while index < len(steam):
        row = steam[index]
        if row.pop("doubleheader", False) and index + 1 < len(steam):
            row["doubleheader"] = True
            second = steam[index + 1]
            second.pop("doubleheader", None)
            extra = second.pop("assist", [])
            if second["diesel_assist"] or extra:
                row["diesel_assist"] = True
                merged = list(row.get("assist") or [])
                merged += [unit for unit in extra if unit not in merged]
                if merged:
                    row["assist"] = merged[:6]
            second["diesel_assist"] = False
            index += 2
            continue
        index += 1
    return steam


CONSIST_GROUPS = {"head": "Trailing", "mid": "Mid-train DP", "rear": "Rear DP"}


def consist_units(raw: Any) -> Dict[str, List[str]]:
    """Units behind the lead, by where they ride: head (trailing), mid, rear. Empty when none."""
    if not isinstance(raw, dict):
        return {}
    out: Dict[str, List[str]] = {}
    for group in CONSIST_GROUPS:
        values = raw.get(group) or []
        if isinstance(values, str):
            values = re.split(r"[,+]", values)
        units = [_unit_text(unit) for unit in values if isinstance(unit, str) and _unit_text(unit)] if isinstance(values, list) else []
        if units:
            out[group] = units[:12]
    return out


def special_power_storage(value: Any) -> str:
    cleaned = normalize_special_power(value)
    if not cleaned["heritage"] and not cleaned["steam"] and not cleaned.get("units"):
        return ""
    return json.dumps(cleaned, separators=(",", ":"), sort_keys=True)


def has_special_power(value: Any) -> bool:
    cleaned = normalize_special_power(value)
    return bool(cleaned["heritage"] or cleaned["steam"])


def assist_text(item: Dict[str, Any]) -> str:
    if not item.get("diesel_assist"):
        return ""
    units = item.get("assist") or []
    return "diesel assist" + (" " + " + ".join(units) if units else "")


def special_power_text(value: Any) -> str:
    cleaned = normalize_special_power(value)
    parts = []
    for item in cleaned["heritage"]:
        extra = ", ".join(p for p in (ERAS.get(item["era"], ""), POSITIONS.get(item["position"], "").lower()) if p)
        label = " ".join(p for p in (item["unit"], item["scheme"]) if p)
        parts.append("Heritage {}{}".format(label, " ({})".format(extra) if extra else ""))
    steam = cleaned["steam"]
    index = 0
    while index < len(steam):
        item = steam[index]
        if item.get("doubleheader"):
            pair = " + ".join(_engine_text(row) for row in steam[index:index + 2])
            assist = assist_text(item)
            parts.append("Steam doubleheader {}{}".format(pair, ", " + assist if assist else ""))
            index += 2
            continue
        label = " ".join(p for p in (item["engine"], item["name"]) if p)
        extra = ", ".join(p for p in (item["wheels"], assist_text(item)) if p)
        parts.append("Steam {}{}".format(label, " ({})".format(extra) if extra else "").strip())
        index += 1
    return " · ".join(parts)


def _engine_text(item: Dict[str, Any]) -> str:
    label = " ".join(p for p in (item["engine"], item["name"]) if p)
    return label + (" ({})".format(item["wheels"]) if item["wheels"] else "")


def steam_runs(steam: List[Dict[str, Any]]) -> List[List[Dict[str, Any]]]:
    """Steam engines grouped as they ran: a doubleheader's two engines together, any other engine alone."""
    runs = []
    index = 0
    while index < len(steam):
        size = 2 if steam[index].get("doubleheader") and index + 1 < len(steam) else 1
        runs.append(steam[index:index + size])
        index += size
    return runs


STEAM_RUN_LABELS = (
    "Single engine",
    "Single engine with diesel assist",
    "Doubleheader",
    "Doubleheader with diesel assist",
)


def steam_run_label(run: List[Dict[str, Any]]) -> str:
    label = "Doubleheader" if len(run) > 1 else "Single engine"
    return label + (" with diesel assist" if run[0].get("diesel_assist") else "")


def consist_unit_list(special: Dict[str, Any]) -> List[str]:
    """Every unit noted behind the lead (trailing, mid-train DP, rear DP), once each."""
    seen: List[str] = []
    for group in CONSIST_GROUPS:
        for unit in (special.get("units") or {}).get(group, []):
            if unit not in seen:
                seen.append(unit)
    return seen


def doubleheader_partner(steam: List[Dict[str, Any]], index: int) -> str:
    """The other engine of a doubleheader, or '' when this engine ran alone."""
    if steam[index].get("doubleheader") and index + 1 < len(steam):
        return steam[index + 1]["engine"]
    if index and steam[index - 1].get("doubleheader"):
        return steam[index - 1]["engine"]
    return ""


@lru_cache(maxsize=1)
def shipped_roster() -> Dict[str, Any]:
    try:
        data = json.loads(reference_path("special_power.json").read_text(encoding="utf-8"))
    except (OSError, ValueError):
        data = {}
    america250 = [dict(row, era="a250") for row in data.get("america250", []) if isinstance(row, dict) and row.get("unit")]
    return {
        "heritage": [row for row in data.get("heritage", []) if isinstance(row, dict) and row.get("unit")] + america250,
        "steam": [row for row in data.get("steam", []) if isinstance(row, dict) and row.get("engine")],
    }


KINDS = {"heritage": "unit", "steam": "engine"}


def _custom_path():
    return support_dir() / "special_power_custom.json"


def load_custom() -> Dict[str, Dict[str, Dict[str, Any]]]:
    """Edits made on this Mac: rows keyed by unit_key, or {"hidden": True} for removed shipped rows."""
    try:
        data = json.loads(_custom_path().read_text(encoding="utf-8"))
    except (OSError, ValueError):
        data = {}
    return {kind: {unit_key(key): row for key, row in (data.get(kind) or {}).items()} for kind in KINDS}


def _save_custom(data: Dict[str, Dict[str, Dict[str, Any]]]) -> None:
    path = _custom_path()
    tmp = path.with_suffix(".tmp")
    tmp.write_text(json.dumps(data, indent=1, sort_keys=True, ensure_ascii=False), encoding="utf-8")
    tmp.replace(path)


def _clean_row(kind: str, raw: Dict[str, Any]) -> Dict[str, Any]:
    if kind == "heritage":
        era = str(raw.get("era") or "").strip().lower()
        return {"unit": _unit_text(raw.get("unit")), "scheme": _clean(raw.get("scheme"), 60), "era": era if era in ERAS else ""}
    return {"engine": _unit_text(raw.get("engine")), "name": _clean(raw.get("name"), 60), "wheels": _wheels(raw.get("wheels"))}


def list_rows(kind: str) -> List[Dict[str, Any]]:
    """The working list: shipped rows with this Mac's edits, additions, and removals applied."""
    field = KINDS[kind]
    custom = load_custom()[kind]
    rows: Dict[str, Dict[str, Any]] = {}
    for row in shipped_roster()[kind]:
        key = unit_key(row[field])
        override = custom.get(key)
        if override and override.get("hidden"):
            continue
        rows[key] = dict(_clean_row(kind, override), source="edited") if override else dict(_clean_row(kind, row), source="shipped")
    for key, override in custom.items():
        if key not in rows and not override.get("hidden") and override.get(field):
            rows[key] = dict(_clean_row(kind, override), source="added")
    return sorted(rows.values(), key=lambda row: row[field])


def save_row(kind: str, raw: Dict[str, Any], original: str = "") -> Dict[str, Any]:
    if kind not in KINDS:
        raise ValueError("Pick heritage or steam")
    field = KINDS[kind]
    row = _clean_row(kind, raw)
    key = unit_key(row[field])
    if not re.search(r"[A-Z]", key) or not re.search(r"\d", key):
        raise ValueError("Enter the reporting mark and number, such as UP 1996")
    if kind == "heritage" and not row["scheme"]:
        raise ValueError("Enter the scheme")
    custom = load_custom()
    shipped = {unit_key(item[field]): _clean_row(kind, item) for item in shipped_roster()[kind]}
    old_key = unit_key(original)
    if old_key and old_key != key:
        if old_key in shipped:
            custom[kind][old_key] = {"hidden": True}
        else:
            custom[kind].pop(old_key, None)
    elif not old_key and key in {unit_key(item[field]) for item in list_rows(kind)}:
        raise ValueError("{} is already on the list; edit it instead".format(row[field]))
    if shipped.get(key) == row:
        custom[kind].pop(key, None)
    else:
        custom[kind][key] = row
    _save_custom(custom)
    return row


def remove_row(kind: str, unit: str) -> bool:
    if kind not in KINDS:
        raise ValueError("Pick heritage or steam")
    key = unit_key(unit)
    custom = load_custom()
    shipped = {unit_key(item[KINDS[kind]]) for item in shipped_roster()[kind]}
    if key in shipped:
        custom[kind][key] = {"hidden": True}
    elif custom[kind].pop(key, None) is None:
        return False
    _save_custom(custom)
    return True


def restore_rows(kind: str = "") -> int:
    custom = load_custom()
    kinds = [kind] if kind in KINDS else list(KINDS)
    cleared = sum(len(custom[name]) for name in kinds)
    for name in kinds:
        custom[name] = {}
    _save_custom(custom)
    return cleared


def roster(logged: Iterable[Any] = ()) -> Dict[str, Any]:
    """The working heritage and steam lists, plus units already in the log."""
    custom = load_custom()
    heritage = {unit_key(row["unit"]): row for row in list_rows("heritage")}
    steam = {unit_key(row["engine"]): row for row in list_rows("steam")}
    hidden = {kind: {key for key, row in custom[kind].items() if row.get("hidden")} for kind in KINDS}
    for value in logged:
        cleaned = normalize_special_power(value)
        for item in cleaned["heritage"]:
            key = unit_key(item["unit"])
            if key and key not in heritage and key not in hidden["heritage"] and item["scheme"]:
                heritage[key] = {"unit": item["unit"], "scheme": item["scheme"], "era": item["era"], "source": "log"}
        for item in cleaned["steam"]:
            key = unit_key(item["engine"])
            if key and key not in steam and key not in hidden["steam"] and (item["name"] or item["wheels"]):
                steam[key] = {"engine": item["engine"], "name": item["name"], "wheels": item["wheels"], "source": "log"}
    schemes = sorted({row["scheme"] for row in heritage.values() if row.get("scheme")})
    return {
        "heritage": sorted(heritage.values(), key=lambda row: row["unit"]),
        "steam": sorted(steam.values(), key=lambda row: row["engine"]),
        "schemes": schemes,
        "wheels": WHEEL_ARRANGEMENTS,
        "eras": ERAS,
        "positions": POSITIONS,
    }
