"""App and data updates from the private TRAIN LOG releases repository on GitHub.

Each person gets their own read-only key code (a GitHub fine-grained token limited to the
releases repository), kept in the macOS Keychain. Releases tagged v<version> carry the two
Mac app zips plus app-manifest.json and app-manifest.sig; releases tagged data-<version>
carry a data pack and its latest.json. Everything is signed with the same ed25519 key as data
packs, so a leaked key code can read releases but can never push a fake update.

Installing an app update downloads and checks the zip, unpacks it next to the support files,
and hands a small script the job of swapping it in once TRAIN LOG has quit, then reopening it.
"""
from __future__ import annotations

import base64
import hashlib
import json
import os
import platform
import plistlib
import re
import shutil
import subprocess
import sys
import time
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional

from data_updates import DataUpdateError as UpdateError
from data_updates import _version_tuple
from paths import support_dir
from version import APP_VERSION

REPO = "graphicsmike/trainlog-releases"
API = "https://api.github.com"
KEYCHAIN_SERVICE = "TRAIN LOG updates"
KEYCHAIN_ACCOUNT = "github"
APP_MANIFEST = "app-manifest.json"
APP_SIGNATURE = "app-manifest.sig"
DATA_FEED = "latest.json"
MAX_SMALL_BYTES = 256 * 1024
MAX_APP_BYTES = 1024 * 1024 * 1024
CHECK_EVERY = 20 * 60 * 60

NEED_KEY = "Enter your key code first. You only need to do this once."
BAD_KEY = "That key code didn't work. Check that you pasted all of it, or ask for a new one."
NOT_A_KEY = "That doesn't look like a key code. Copy the whole code and paste it again."
OFFLINE = "Couldn't reach the update server. Check your internet connection and try again."


# --- key code -------------------------------------------------------------------------------

def _use_keychain() -> bool:
    return sys.platform == "darwin" and not os.environ.get("TRAINS_SUPPORT_DIR") and bool(shutil.which("security"))


def _key_file() -> Path:
    return support_dir() / "update-key"


def get_key() -> str:
    if _use_keychain():
        result = subprocess.run(
            ["security", "find-generic-password", "-s", KEYCHAIN_SERVICE, "-a", KEYCHAIN_ACCOUNT, "-w"],
            capture_output=True,
            text=True,
        )
        return result.stdout.strip() if result.returncode == 0 else ""
    try:
        return _key_file().read_text(encoding="utf-8").strip()
    except OSError:
        return ""


def has_key() -> bool:
    return bool(get_key())


def clean_key(text: str) -> str:
    key = re.sub(r"\s+", "", str(text or ""))
    if not re.fullmatch(r"[A-Za-z0-9_]{20,255}", key):
        raise UpdateError(NOT_A_KEY)
    return key


def save_key(text: str) -> None:
    """Check the key code against GitHub, then keep it."""
    key = clean_key(text)
    _get_json("/repos/{}".format(REPO), key)
    if _use_keychain():
        result = subprocess.run(
            ["security", "add-generic-password", "-U", "-s", KEYCHAIN_SERVICE, "-a", KEYCHAIN_ACCOUNT, "-w", key],
            capture_output=True,
            text=True,
        )
        if result.returncode != 0:
            raise UpdateError("TRAIN LOG couldn't save the key code in your Mac's Keychain.")
        return
    path = _key_file()
    path.write_text(key, encoding="utf-8")
    path.chmod(0o600)


def forget_key() -> None:
    if _use_keychain():
        subprocess.run(
            ["security", "delete-generic-password", "-s", KEYCHAIN_SERVICE, "-a", KEYCHAIN_ACCOUNT],
            capture_output=True,
        )
    else:
        try:
            _key_file().unlink()
        except OSError:
            pass
    _write_state({})


# --- talking to GitHub ----------------------------------------------------------------------

def _ssl_context():
    import ssl

    context = ssl.create_default_context()
    try:
        import certifi

        context.load_verify_locations(certifi.where())
    except ImportError:
        pass
    return context


def _http_error(exc) -> UpdateError:
    if exc.code in (401, 404):
        return UpdateError(BAD_KEY)
    if exc.code in (403, 429):
        if exc.headers.get("X-RateLimit-Remaining") == "0" or exc.code == 429:
            return UpdateError("GitHub asked TRAIN LOG to wait. Try again in an hour.")
        return UpdateError(BAD_KEY)
    return UpdateError("The update server had a problem (error {}). Try again later.".format(exc.code))


def _open(url: str, token: str, accept: str = "application/vnd.github+json"):
    """Open a GitHub URL. Asset downloads redirect to storage that must not see the key code."""
    import urllib.error
    import urllib.request

    class NoRedirect(urllib.request.HTTPRedirectHandler):
        def redirect_request(self, *args, **kwargs):
            return None

    opener = urllib.request.build_opener(urllib.request.HTTPSHandler(context=_ssl_context()), NoRedirect)
    headers = {
        "User-Agent": "TRAIN LOG/" + APP_VERSION,
        "Accept": accept,
        "Authorization": "Bearer " + token,
        "X-GitHub-Api-Version": "2022-11-28",
    }
    try:
        try:
            return opener.open(urllib.request.Request(url, headers=headers), timeout=60)
        except urllib.error.HTTPError as exc:
            location = exc.headers.get("Location") or ""
            if exc.code not in (301, 302, 303, 307, 308) or not location.lower().startswith("https://"):
                raise
        plain = {"User-Agent": headers["User-Agent"], "Accept": accept}
        return opener.open(urllib.request.Request(location, headers=plain), timeout=60)
    except urllib.error.HTTPError as exc:
        raise _http_error(exc) from exc
    except (urllib.error.URLError, OSError) as exc:
        raise UpdateError(OFFLINE) from exc


def _read(response, limit: int) -> bytes:
    with response:
        data = response.read(limit + 1)
    if len(data) > limit:
        raise UpdateError("The update server sent more data than expected.")
    return data


def _get_json(path: str, token: str) -> Any:
    data = _read(_open(API + path, token), 4 * 1024 * 1024)
    try:
        return json.loads(data.decode("utf-8"))
    except ValueError as exc:
        raise UpdateError("The update server's answer couldn't be read.") from exc


def asset_bytes(asset: Dict[str, Any], token: str, limit: int = MAX_SMALL_BYTES) -> bytes:
    return _read(_open(str(asset["url"]), token, "application/octet-stream"), limit)


def _download(asset: Dict[str, Any], token: str, dest: Path, progress: Optional[Callable[[int, int], None]]) -> str:
    """Stream an asset to dest and return its sha256."""
    response = _open(str(asset["url"]), token, "application/octet-stream")
    total = int(response.headers.get("Content-Length") or asset.get("size") or 0)
    digest = hashlib.sha256()
    done = 0
    try:
        with response, open(dest, "wb") as out:
            while True:
                chunk = response.read(256 * 1024)
                if not chunk:
                    break
                done += len(chunk)
                if done > MAX_APP_BYTES:
                    raise UpdateError("The update server sent more data than expected.")
                digest.update(chunk)
                out.write(chunk)
                if progress:
                    progress(done, total)
    except OSError as exc:
        raise UpdateError(OFFLINE) from exc
    return digest.hexdigest()


def releases(token: str) -> List[Dict[str, Any]]:
    found = _get_json("/repos/{}/releases?per_page=50".format(REPO), token)
    if not isinstance(found, list):
        raise UpdateError("The update server's answer couldn't be read.")
    return [item for item in found if isinstance(item, dict) and not item.get("draft") and not item.get("prerelease")]


def _asset(release: Dict[str, Any], name: str) -> Optional[Dict[str, Any]]:
    for asset in release.get("assets") or []:
        if asset.get("name") == name:
            return asset
    return None


def _newest(found: List[Dict[str, Any]], prefix: str) -> Optional[Dict[str, Any]]:
    tagged = [item for item in found if str(item.get("tag_name") or "").startswith(prefix)]
    return max(tagged, key=lambda item: _version_tuple(str(item["tag_name"])[len(prefix):]), default=None)


# --- what's out there -----------------------------------------------------------------------

def _verify(manifest: bytes, signature: bytes) -> None:
    from cryptography.exceptions import InvalidSignature
    from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey

    import data_updates

    key = Ed25519PublicKey.from_public_bytes(base64.b64decode(data_updates.PUBLIC_KEY))
    try:
        key.verify(base64.b64decode(signature.strip()), manifest)
    except (InvalidSignature, ValueError) as exc:
        raise UpdateError("This update isn't signed by TRAIN LOG. Nothing was changed.") from exc


def arch() -> str:
    return "arm64" if platform.machine() in ("arm64", "aarch64") else "x86_64"


def latest_app(found: List[Dict[str, Any]], token: str) -> Optional[Dict[str, Any]]:
    release = _newest(found, "v")
    if not release:
        return None
    manifest_asset = _asset(release, APP_MANIFEST)
    signature_asset = _asset(release, APP_SIGNATURE)
    if not manifest_asset or not signature_asset:
        return None
    manifest_bytes = asset_bytes(manifest_asset, token)
    _verify(manifest_bytes, asset_bytes(signature_asset, token))
    try:
        manifest = json.loads(manifest_bytes.decode("utf-8"))
        file = dict(manifest["files"][arch()])
        latest = {
            "version": str(manifest["version"]),
            "created": str(manifest.get("created") or ""),
            "notes": str(manifest.get("notes") or "")[:4000],
            "name": str(file["name"]),
            "sha256": str(file["sha256"]).lower(),
            "size": int(file.get("size") or 0),
        }
    except (ValueError, KeyError, TypeError) as exc:
        raise UpdateError("The update's details couldn't be read.") from exc
    asset = _asset(release, latest["name"])
    if not asset:
        raise UpdateError("The update for this Mac is missing from the server.")
    latest["asset"] = {"url": asset["url"], "size": asset.get("size") or 0}
    return latest


def latest_data(found: List[Dict[str, Any]], token: str) -> Optional[Dict[str, Any]]:
    release = _newest(found, "data-")
    if not release:
        return None
    feed_asset = _asset(release, DATA_FEED)
    if not feed_asset:
        return None
    try:
        feed = json.loads(asset_bytes(feed_asset, token).decode("utf-8"))
        latest = {
            "data_version": int(feed["data_version"]),
            "min_app_version": str(feed.get("min_app_version") or ""),
            "created": str(feed.get("created") or ""),
            "notes": str(feed.get("notes") or "")[:2000],
            "size": int(feed.get("size") or 0),
            "sha256": str(feed.get("sha256") or "").lower(),
        }
        pack = _asset(release, Path(str(feed["url"])).name)
    except (ValueError, KeyError, TypeError) as exc:
        raise UpdateError("The update server's list couldn't be read.") from exc
    if not pack:
        raise UpdateError("The data update is missing from the server.")
    latest["asset"] = {"url": pack["url"], "size": pack.get("size") or 0}
    return latest


def _state_path() -> Path:
    return support_dir() / "update-check.json"


def _read_state() -> Dict[str, Any]:
    try:
        data = json.loads(_state_path().read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return {}
    return data if isinstance(data, dict) else {}


def _write_state(state: Dict[str, Any]) -> None:
    try:
        _state_path().write_text(json.dumps(state, indent=1), encoding="utf-8")
    except OSError:
        pass


def _public(item: Optional[Dict[str, Any]]) -> Optional[Dict[str, Any]]:
    return {key: value for key, value in item.items() if key != "asset"} if item else None


def summarize(app: Optional[Dict[str, Any]], data: Optional[Dict[str, Any]]) -> Dict[str, Any]:
    import data_updates

    current_data = data_updates.status()["data_version"]
    app_ready = bool(app) and _version_tuple(app["version"]) > _version_tuple(APP_VERSION)
    data_newer = bool(data) and data["data_version"] > current_data
    data_fits = bool(data) and _version_tuple(data["min_app_version"]) <= _version_tuple(APP_VERSION)
    if app_ready:
        message = "TRAIN LOG {} is ready.".format(app["version"])
    elif data_newer and data_fits:
        message = "New station data is ready."
    else:
        message = "TRAIN LOG is up to date."
    return {
        "app_version": APP_VERSION,
        "app": {"available": app_ready, "latest": _public(app)},
        "data": {"available": data_newer and data_fits, "latest": _public(data)},
        "available": app_ready or (data_newer and data_fits),
        "message": message,
    }


def check() -> Dict[str, Any]:
    token = get_key()
    if not token:
        raise UpdateError(NEED_KEY)
    found = releases(token)
    app = latest_app(found, token)
    data = latest_data(found, token)
    _write_state({"checked_at": time.time(), "app": _public(app), "data": _public(data)})
    result = summarize(app, data)
    result["_assets"] = {"app": app, "data": data}
    return result


def auto() -> Dict[str, Any]:
    """The once-a-day look for a new version. Never raises; a failure waits for the next day."""
    if not has_key():
        return {"configured": False, "available": False}
    state = _read_state()
    if time.time() - float(state.get("checked_at") or 0) < CHECK_EVERY:
        return {"configured": True, "checked": False, **summarize(state.get("app"), state.get("data"))}
    try:
        result = check()
    except UpdateError as exc:
        _write_state({**state, "checked_at": time.time()})
        return {"configured": True, "checked": True, "available": False, "error": exc.message}
    result.pop("_assets", None)
    return {"configured": True, "checked": True, **result}


# --- installing a new app -------------------------------------------------------------------

def work_dir() -> Path:
    return support_dir() / "app-update"


def app_bundle() -> Optional[Path]:
    if not getattr(sys, "frozen", False):
        return None
    bundle = Path(sys.executable).resolve().parents[2]
    return bundle if bundle.suffix == ".app" else None


def self_update_problem(bundle: Optional[Path]) -> str:
    if bundle is None:
        return "TRAIN LOG updates itself only in the Mac app."
    if "/AppTranslocation/" in str(bundle) or not os.access(bundle.parent, os.W_OK) or not os.access(bundle, os.W_OK):
        return "Move TRAIN LOG into your Applications folder, open it from there, and try again."
    return ""


def _bundle_version(app: Path) -> str:
    try:
        with open(app / "Contents" / "Info.plist", "rb") as handle:
            return str(plistlib.load(handle).get("CFBundleShortVersionString") or "")
    except (OSError, plistlib.InvalidFileException, ValueError):
        return ""


def stage_app(
    progress: Optional[Callable[[int, int], None]] = None,
    bundle: Optional[Path] = None,
    on_status: Optional[Callable[[str], None]] = None,
) -> Dict[str, Any]:
    """Download, check, and unpack the new app. It is swapped in by finish_update after TRAIN LOG quits."""
    bundle = bundle or app_bundle()
    problem = self_update_problem(bundle)
    if problem:
        raise UpdateError(problem)
    found = check()
    if not found["app"]["available"]:
        raise UpdateError("You already have the newest TRAIN LOG.")
    latest = found["_assets"]["app"]
    folder = work_dir()
    shutil.rmtree(folder, ignore_errors=True)
    folder.mkdir(parents=True)
    zipped = folder / "download.zip"
    digest = _download(latest["asset"], get_key(), zipped, progress)
    if digest != latest["sha256"]:
        shutil.rmtree(folder, ignore_errors=True)
        raise UpdateError("The download didn't match the signed update. Nothing was changed.")
    if on_status:
        on_status("Unpacking the new TRAIN LOG…")
    staged = folder / "staged"
    unpacked = subprocess.run(["ditto", "-x", "-k", str(zipped), str(staged)], capture_output=True)
    zipped.unlink()
    apps = sorted(staged.glob("*.app")) if unpacked.returncode == 0 else []
    if len(apps) != 1 or _bundle_version(apps[0]) != latest["version"]:
        shutil.rmtree(folder, ignore_errors=True)
        raise UpdateError("The new version couldn't be unpacked. Nothing was changed.")
    if on_status:
        on_status("Checking the download…")
    signed = subprocess.run(["codesign", "--verify", "--deep", "--strict", str(apps[0])], capture_output=True)
    if signed.returncode != 0:
        shutil.rmtree(folder, ignore_errors=True)
        detail = (signed.stderr or b"").decode("utf-8", "replace").strip().splitlines()
        why = detail[0] if detail else "the Mac rejected the signature"
        if len(why) > 160:
            why = why[:157] + "..."
        raise UpdateError("The new version didn't pass the Mac's app check ({}). Nothing was changed.".format(why))
    ready = {"app": str(apps[0]), "target": str(bundle), "version": latest["version"]}
    (folder / "staged.json").write_text(json.dumps(ready), encoding="utf-8")
    return ready


SWAP_SCRIPT = r"""#!/bin/sh
# Waits for TRAIN LOG to quit, puts the new app where the old one was, and reopens it.
pid="$1"; new="$2"; target="$3"; old="$4"; launch="$5"
i=0
while kill -0 "$pid" 2>/dev/null && [ "$i" -lt 600 ]; do sleep 0.2; i=$((i+1)); done
rm -rf "$old"
mkdir -p "$(dirname "$old")"
if mv "$target" "$old"; then
  if mv "$new" "$target"; then
    xattr -dr com.apple.quarantine "$target" 2>/dev/null
    $launch "$target"
    exit 0
  fi
  mv "$old" "$target"
fi
$launch "$target"
exit 1
"""


def finish_update(pid: int, launch: str = "open") -> bool:
    """Start the swap script for a staged update. The caller quits TRAIN LOG right after."""
    folder = work_dir()
    try:
        ready = json.loads((folder / "staged.json").read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return False
    new, target = Path(ready["app"]), Path(ready["target"])
    if not new.is_dir() or not target.is_dir():
        return False
    script = folder / "swap.sh"
    script.write_text(SWAP_SCRIPT, encoding="utf-8")
    old = folder / "previous" / target.name
    subprocess.Popen(
        ["/bin/sh", str(script), str(pid), str(new), str(target), str(old), launch],
        stdin=subprocess.DEVNULL,
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
        start_new_session=True,
    )
    return True


def tidy() -> None:
    """After a launch, the previous app and any half-finished download are no longer needed."""
    folder = work_dir()
    if folder.exists():
        shutil.rmtree(folder, ignore_errors=True)
