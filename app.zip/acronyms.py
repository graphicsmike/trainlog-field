"""Editable expansions for railroad marks and train-type chips."""
from __future__ import annotations

import json
from typing import Any, Dict

from paths import shipped_json, support_dir

DEFAULT_RAILROADS = {
    "BNSF": "BNSF Railway",
    "UP": "Union Pacific",
    "NS": "Norfolk Southern",
    "CN": "Canadian National",
    "CPKC": "Canadian Pacific Kansas City",
    "CSX": "CSX Transportation",
    "AMTK": "Amtrak",
    "ACEX": "Altamont Corridor Express",
    "JPBX": "Caltrain",
    "SCAX": "Metrolink",
    "SDNX": "Coaster",
    "UTAX": "UTA FrontRunner",
    "UTAH": "Utah Railway",
}

DEFAULT_TYPES = {
    "AUTO": "Autoracks",
    "CON": "Containers",
    "PIG": "Piggyback",
    "MIXED": "Mixed Freight",
    "ETH-GAS": "Ethanol / Gasoline",
    "GRAIN": "Grain",
    "BR TBL": "Baretable",
    "COAL": "Coal",
    "PASS": "Passenger",
    "MIL": "Military",
    "BALLAST": "Ballast",
    "COTTON": "Cotton Seed",
    "SAND": "Unit Sand",
    "SODA": "Unit Soda Ash",
    "CEMENT": "Unit Cement",
    "LGT HLP": "Light Help",
    "LGT PWR": "Light Power",
    "TIE TRN": "Tie Train",
    "RAIL": "Rail Train",
    "HGH WDE": "High/Wide",
    "OCS": "Officer Special",
    "EXCRSN": "Excursion Train",
    "SPECIAL": "Special Move",
    "HI-RAIL": "Hi-Railer",
    "HERZOG": "Herzog Ballast Train",
    "LORAM": "Loram MOW (LMIX)",
    "MOW": "Maintenance of Way",
}

_LOADED = False
_OVERLAY: Dict[str, Dict[str, str]] = {"railroads": {}, "types": {}}


def _path():
    return support_dir() / "acronyms.json"


def _clean_map(raw: Any) -> Dict[str, str]:
    out: Dict[str, str] = {}
    if not isinstance(raw, dict):
        return out
    for key, value in raw.items():
        name = str(key or "").strip()
        meaning = str(value or "").strip()
        if not name:
            continue
        out[name] = meaning
    return out


def reload_acronyms() -> Dict[str, Dict[str, str]]:
    global _OVERLAY, _LOADED
    overlay = {"railroads": {}, "types": {}}
    path = _path()
    if path.is_file():
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError, TypeError):
            data = {}
        if isinstance(data, dict):
            overlay["railroads"] = _clean_map(data.get("railroads"))
            overlay["types"] = _clean_map(data.get("types"))
    _OVERLAY = overlay
    _LOADED = True
    return list_meanings()


def _overlay() -> Dict[str, Dict[str, str]]:
    if not _LOADED:
        reload_acronyms()
    return _OVERLAY


def defaults(bucket: str) -> Dict[str, str]:
    """Built-in meanings; assets/reference/meanings.json, when present, is the full shipped list."""
    base = DEFAULT_RAILROADS if bucket == "railroads" else DEFAULT_TYPES
    shipped = shipped_json("reference", "meanings.json")
    if isinstance(shipped, dict) and isinstance(shipped.get(bucket), dict):
        return {key: value for key, value in _clean_map(shipped[bucket]).items() if value}
    return dict(base)


def _merged(defaults: Dict[str, str], overlay: Dict[str, str]) -> Dict[str, str]:
    merged = dict(defaults)
    merged.update(overlay)
    return {key: value for key, value in merged.items() if str(value).strip()}


def _by_mark(meanings: Dict[str, str]) -> Dict[str, str]:
    """Meanings filed under another mark for the same railroad (SNRD for SDNX) move to the app's mark."""
    import railroads as rr_mod

    out: Dict[str, str] = {}
    for key, value in meanings.items():
        mark = rr_mod.mark_aliases().get(key.upper(), key)
        if mark not in out or key == mark:
            out[mark] = value
    return out


def list_meanings() -> Dict[str, Dict[str, str]]:
    overlay = _overlay()
    return {
        "railroads": _by_mark(_merged(defaults("railroads"), overlay.get("railroads") or {})),
        "types": _merged(defaults("types"), overlay.get("types") or {}),
    }


def _write(overlay: Dict[str, Dict[str, str]]) -> Dict[str, Dict[str, str]]:
    global _OVERLAY
    cleaned = {
        "railroads": _clean_map(overlay.get("railroads")),
        "types": _clean_map(overlay.get("types")),
    }
    path = _path()
    if not cleaned["railroads"] and not cleaned["types"]:
        if path.exists():
            path.unlink()
    else:
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(cleaned, indent=2) + "\n", encoding="utf-8")
    _OVERLAY = cleaned
    return list_meanings()


def save_meanings(payload: Dict[str, Any]) -> Dict[str, Dict[str, str]]:
    overlay = {
        "railroads": dict(_overlay().get("railroads") or {}),
        "types": dict(_overlay().get("types") or {}),
    }
    for bucket in ("railroads", "types"):
        incoming = payload.get(bucket)
        if not isinstance(incoming, dict):
            continue
        shipped = defaults(bucket)
        for key, value in incoming.items():
            name = str(key or "").strip()
            if not name:
                continue
            meaning = str(value or "").strip()
            if meaning == shipped.get(name, "") and name in shipped:
                overlay[bucket].pop(name, None)
            else:
                overlay[bucket][name] = meaning
    return _write(overlay)


def reset_railroad_meanings() -> Dict[str, Dict[str, str]]:
    overlay = {
        "railroads": {
            key: value
            for key, value in (_overlay().get("railroads") or {}).items()
            if key not in defaults("railroads")
        },
        "types": dict(_overlay().get("types") or {}),
    }
    return _write(overlay)


def reset_type_meanings() -> Dict[str, Dict[str, str]]:
    overlay = {
        "railroads": dict(_overlay().get("railroads") or {}),
        "types": {},
    }
    return _write(overlay)


reload_acronyms()
