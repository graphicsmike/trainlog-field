"""US state (and nearby Canadian province) codes and their usual time zone."""
from __future__ import annotations

import re
from typing import Any, Dict, Tuple

EASTERN = "America/New_York"
CENTRAL = "America/Chicago"
MOUNTAIN = "America/Denver"
ARIZONA = "America/Phoenix"
PACIFIC = "America/Los_Angeles"
ALASKA = "America/Anchorage"
HAWAII = "Pacific/Honolulu"

STATE_ZONES: Dict[str, str] = {
    "CT": EASTERN, "DE": EASTERN, "DC": EASTERN, "FL": EASTERN, "GA": EASTERN,
    "IN": EASTERN, "KY": EASTERN, "ME": EASTERN, "MD": EASTERN, "MA": EASTERN,
    "MI": EASTERN, "NH": EASTERN, "NJ": EASTERN, "NY": EASTERN, "NC": EASTERN,
    "OH": EASTERN, "PA": EASTERN, "RI": EASTERN, "SC": EASTERN, "VT": EASTERN,
    "VA": EASTERN, "WV": EASTERN, "ON": EASTERN, "QC": EASTERN,
    "AL": CENTRAL, "AR": CENTRAL, "IL": CENTRAL, "IA": CENTRAL, "KS": CENTRAL,
    "LA": CENTRAL, "MN": CENTRAL, "MS": CENTRAL, "MO": CENTRAL, "NE": CENTRAL,
    "ND": CENTRAL, "OK": CENTRAL, "SD": CENTRAL, "TN": CENTRAL, "TX": CENTRAL,
    "WI": CENTRAL, "MB": CENTRAL,
    "CO": MOUNTAIN, "ID": MOUNTAIN, "MT": MOUNTAIN, "NM": MOUNTAIN, "UT": MOUNTAIN,
    "WY": MOUNTAIN, "AB": MOUNTAIN,
    "AZ": ARIZONA,
    "CA": PACIFIC, "NV": PACIFIC, "OR": PACIFIC, "WA": PACIFIC, "BC": PACIFIC,
    "AK": ALASKA,
    "HI": HAWAII,
}

# Part of these states keeps another zone, so the state alone is not enough.
SPLIT_ZONES: Dict[str, Tuple[str, ...]] = {
    "FL": (EASTERN, CENTRAL), "IN": (EASTERN, CENTRAL), "KY": (EASTERN, CENTRAL),
    "MI": (EASTERN, CENTRAL), "TN": (CENTRAL, EASTERN), "KS": (CENTRAL, MOUNTAIN),
    "NE": (CENTRAL, MOUNTAIN), "ND": (CENTRAL, MOUNTAIN), "SD": (CENTRAL, MOUNTAIN),
    "TX": (CENTRAL, MOUNTAIN), "ID": (MOUNTAIN, PACIFIC), "OR": (PACIFIC, MOUNTAIN),
}
SPLIT_STATES = set(SPLIT_ZONES)

STATE_NAMES: Dict[str, str] = {
    "ALABAMA": "AL", "ALASKA": "AK", "ARIZONA": "AZ", "ARKANSAS": "AR", "CALIFORNIA": "CA",
    "COLORADO": "CO", "CONNECTICUT": "CT", "DELAWARE": "DE", "FLORIDA": "FL", "GEORGIA": "GA",
    "HAWAII": "HI", "IDAHO": "ID", "ILLINOIS": "IL", "INDIANA": "IN", "IOWA": "IA",
    "KANSAS": "KS", "KENTUCKY": "KY", "LOUISIANA": "LA", "MAINE": "ME", "MARYLAND": "MD",
    "MASSACHUSETTS": "MA", "MICHIGAN": "MI", "MINNESOTA": "MN", "MISSISSIPPI": "MS",
    "MISSOURI": "MO", "MONTANA": "MT", "NEBRASKA": "NE", "NEVADA": "NV",
    "NEW HAMPSHIRE": "NH", "NEW JERSEY": "NJ", "NEW MEXICO": "NM", "NEW YORK": "NY",
    "NORTH CAROLINA": "NC", "NORTH DAKOTA": "ND", "OHIO": "OH", "OKLAHOMA": "OK",
    "OREGON": "OR", "PENNSYLVANIA": "PA", "RHODE ISLAND": "RI", "SOUTH CAROLINA": "SC",
    "SOUTH DAKOTA": "SD", "TENNESSEE": "TN", "TEXAS": "TX", "UTAH": "UT", "VERMONT": "VT",
    "VIRGINIA": "VA", "WASHINGTON": "WA", "WEST VIRGINIA": "WV", "WISCONSIN": "WI",
    "WYOMING": "WY", "DISTRICT OF COLUMBIA": "DC", "ONTARIO": "ON", "QUEBEC": "QC",
    "MANITOBA": "MB", "ALBERTA": "AB", "BRITISH COLUMBIA": "BC",
}

STATE_CODES: Tuple[str, ...] = tuple(sorted(STATE_ZONES))


def normalize_state(value: Any) -> str:
    """Two-letter code for a state or province name or code, else ""."""
    text = re.sub(r"\s+", " ", str(value or "").strip().upper().rstrip("."))
    if not text:
        return ""
    if text in STATE_ZONES:
        return text
    return STATE_NAMES.get(text, "")


def state_zone(state: str) -> str:
    return STATE_ZONES.get(normalize_state(state), "")


def state_from_region(region: Any) -> str:
    text = str(region or "").strip().upper()
    if not text:
        return ""
    tail = re.split(r"[,·]", text)[-1].strip().rstrip(".")
    tail = re.sub(r"\s+\d{5}(?:-\d{4})?$", "", tail).strip()
    return normalize_state(tail)
