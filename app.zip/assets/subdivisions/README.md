One CSV per subdivision (or per railroad). All `*.csv` files in this folder are merged into the Subdivision list and location suggestions. You do not need one combined spreadsheet.

Currently loaded: 462 CSVs, about 8,655 stations.

## Format

    BNSF or UP,,,
    Subdivision,Location,Milepost,State
    Cajon Sub,Barstow,0.0,CA
    Cajon Sub,Victorville,36.7,CA

- Row 1 is the railroad or railroads that use the line (BNSF, UP, AMTK, SCAX, ACEX, and so on). Use `or` when another road has trackage rights, like `BNSF or AMTK or UP`.
- Row 2 is the header row. State is optional: a two-letter state or province code that helps set time zones on the pad and on import. Older three-column files still load.
- `python3 scripts/tag_states.py` fills in missing states for this folder and the Application Support subdivisions (add `--dry-run --report` to preview, `--redo` to replace states already there).
- Every row after that is one station, siding, or milepost. Order does not matter; the Stations editor and the pad sort by milepost.
- Name the file `RAILROAD-Subdivision.csv` (for example `BNSF-Cajon.csv`). Same-named subdivisions on different roads are labeled on the pad, like `Lakeside Sub (BNSF)` and `Lakeside Sub (UP)`.

## Adding more CSVs

Any of these works, and the lists reload on their own:

1. **Many at once:** drop the files into the watch folder, `~/Library/Application Support/RailroadTrainLog/watch` (Dashboard → Settings → Files → Watch folder… shows the path and opens it in Finder; File → Open Watch Folder in the Mac app). While TRAIN LOG is open it imports each CSV within a few seconds and moves it into `imported/`. A file it cannot read goes into `failed/` with a `.txt` note saying why.
2. **One at a time:** Dashboard → Settings → Add subdivision, then Add Subdivision CSV, or type the stations in.
3. **Straight into this folder** (source copy only): drop the file here, then Files → Reload CSVs.

Files added with 1 or 2 are stored in `~/Library/Application Support/RailroadTrainLog/subdivisions`. Every build copies them, and any edits you made to shipped subdivisions, into this folder first (`scripts/prepare_release.py`), so the next app ships them and the count above updates. Run `python3 scripts/prepare_release.py --dry-run` to preview what would be copied.

## Settings

- **Files → Reload CSVs** re-reads this folder and the extra files in Application Support. It keeps editor changes, hidden subdivisions, and added files.
- **Files → Restore shipped** puts the list back as issued: edits to shipped subdivisions are undone (the edited copies are moved to `~/Library/Application Support/RailroadTrainLog/subdivision-backups/`) and hidden subdivisions show again. Subdivisions you added stay.
- Each row's **⋯** menu has Edit, Hide or Unhide, and Delete. Hide keeps the CSV and takes it off the pad. Delete removes a file you added; deleting or hiding a shipped file hides it on this Mac but does not remove it from this folder or the app bundle.
