Railroad names for the entry pad live here. All `*.csv` files are merged at startup.

Format:

    Freight,Pass/Comm,Tourist
    BNSF,AMTK,DSNG
    UP,ACEX,GCRX
    NS,JPBX,SRC
    CN,SCAX,CTSR
    CPKC,SDNX,NVRR
    CSX,,NN
    MRL,,

Row 1 is the group headers: Freight, passenger and commuter roads, and tourist lines each have a column. A list saved before 1.0.6 has only the first two columns; TRAIN LOG adds the shipped tourist lines to it once, and after that the Tourist column is whatever you keep in it. Tourist roads count as passenger roads for the lead loco menu, so their lead marks only show for that railroad. Other stays a typed choice on the pad, not in this file. Dashboard → Settings can add marks, edit what each mark stands for, set a freight railroad's class, or restore the shipped list. Edits are saved in `~/Library/Application Support/RailroadTrainLog/` as `railroads.csv`, `acronyms.json`, and `railroad_classes.json`.

`rr-classes.json` holds the shipped freight classes (`{"BNSF": "Class I", ...}`; Class I, Regional, Shortline, or Tourist). A user's own classes in `railroad_classes.json` sit on top; Restore defaults removes them.

These shipped files are what a new user starts with. Every build (`scripts/prepare_release.py`) writes this Mac's railroad list into `rr-list.csv` and its classes into `rr-classes.json` first, so your edits become the next app's defaults. The "Stands for" meanings, train types, and import filters are written the same way to `../reference/meanings.json`, `train-types.json`, and `import-filters.json`.
