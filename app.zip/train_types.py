"""Train type chips, aliases, and import filters.

Defaults ship with the app; extras and incoming-label maps live in Application Support.
"""
from __future__ import annotations

import json
import re
from typing import Any, Dict, List, Tuple

from paths import shipped_json, support_dir

PINNED_TYPE = "PASS"

DEFAULT_TRAIN_TYPES = (
    "PASS",
    "COAL",
    "CON",
    "AUTO",
    "PIG",
    "MIXED",
    "ETH-GAS",
    "GRAIN",
    "BR TBL",
    "MIL",
    "BALLAST",
    "COTTON",
    "SAND",
    "SODA",
    "CEMENT",
    "LGT HLP",
    "LGT PWR",
    "TIE TRN",
    "RAIL",
    "HGH WDE",
    "OCS",
    "EXCRSN",
    "SPECIAL",
    "HI-RAIL",
    "HERZOG",
    "LORAM",
    "MOW",
)

TYPE_ALIASES = {
    "ETH/GAS": "ETH-GAS",
}

# Incoming spellings matched as whole tokens (case-insensitive) before a train is saved.
TYPE_NICKNAMES: Tuple[Tuple[str, str], ...] = (
    ("ETH/GAS", "ETH-GAS"),
    ("ETH GAS", "ETH-GAS"),
    ("ETH-GAS", "ETH-GAS"),
    ("ETH", "ETH-GAS"),
    ("ETHANOL", "ETH-GAS"),
    ("ETHANOL/GASOLINE", "ETH-GAS"),
    ("ETHANOL / GASOLINE", "ETH-GAS"),
    ("GASOLINE", "ETH-GAS"),
    ("CONTAINER", "CON"),
    ("CONTAINERS", "CON"),
    ("STACK", "CON"),
    ("STACKS", "CON"),
    ("PIGGYBACK", "PIG"),
    ("PIGGYBACKS", "PIG"),
    ("TRAILER", "PIG"),
    ("TRAILERS", "PIG"),
    ("TOFC", "PIG"),
    ("MIXED FREIGHT", "MIXED"),
    ("MANIFEST", "MIXED"),
    ("MIX", "MIXED"),
    ("AUTORACK", "AUTO"),
    ("AUTORACKS", "AUTO"),
    ("AUTO RACK", "AUTO"),
    ("AUTO RACKS", "AUTO"),
    ("BARETABLE", "BR TBL"),
    ("BARETABLES", "BR TBL"),
    ("BARE TABLE", "BR TBL"),
    ("BR-TBL", "BR TBL"),
    ("BRTBL", "BR TBL"),
    ("PASSENGER", "PASS"),
    ("PASSENGERS", "PASS"),
    ("PAX", "PASS"),
    ("MILITARY", "MIL"),
    ("OFFICER SPECIAL", "OCS"),
    ("OFFICE CAR SPECIAL", "OCS"),
    ("GRAINS", "GRAIN"),
    ("CWR", "RAIL"),
    ("RBN RAIL", "RAIL"),
    ("RBN-RL", "RAIL"),
    ("RBRL", "RAIL"),
    ("RIBBON", "RAIL"),
    ("RIBBON RAIL", "RAIL"),
    ("WELDED RAIL", "RAIL"),
    ("TIE", "TIE TRN"),
    ("TIES", "TIE TRN"),
    ("TIE TRAIN", "TIE TRN"),
    ("CTTN SD", "COTTON"),
    ("CTTN", "COTTON"),
    ("COTTONSEED", "COTTON"),
    ("COTTON SEED", "COTTON"),
    ("BLST", "BALLAST"),
    ("LIGHT HELPER", "LGT HLP"),
    ("LGTHLP", "LGT HLP"),
    ("LGTPWR", "LGT PWR"),
    ("LIGHT POWER", "LGT PWR"),
    ("HI RAIL", "HI-RAIL"),
    ("HIRAIL", "HI-RAIL"),
    ("HY-RAIL", "HI-RAIL"),
    ("HIRAILER", "HI-RAIL"),
    ("EXCUR", "EXCRSN"),
    ("EXCURSION", "EXCRSN"),
    ("HIGH WIDE", "HGH WDE"),
    ("HIGH/WIDE", "HGH WDE"),
    ("SPEC", "SPECIAL"),
    ("SPECIAL MOVE", "SPECIAL"),
    ("HRZG", "HERZOG"),
    ("LMIX", "LORAM"),
)

_FOLD_RE = re.compile(r"[^A-Z0-9]+")

_LOADED = False
TRAIN_TYPES: List[str] = list(DEFAULT_TRAIN_TYPES)

_FILTERS_LOADED = False
_TYPE_FILTERS: Dict[str, str] = {}


def shipped_types() -> List[str]:
    """The chips a new user starts with: assets/reference/train-types.json, else the list above."""
    data = shipped_json("reference", "train-types.json")
    raw = data.get("types") if isinstance(data, dict) else data
    names = [str(item).strip() for item in raw or [] if str(item or "").strip()] if isinstance(raw, list) else []
    return names or list(DEFAULT_TRAIN_TYPES)


def shipped_type_filters() -> Dict[str, str]:
    data = shipped_json("reference", "import-filters.json")
    raw = data.get("filters") if isinstance(data, dict) else None
    return dict(raw) if isinstance(raw, dict) else {}


def types_path():
    return support_dir() / "train_types.json"


def type_filters_path():
    return support_dir() / "type_import_filters.json"


def fold_type_key(text: Any) -> str:
    raw = str(text or "").strip().upper()
    if not raw:
        return ""
    return " ".join(part for part in _FOLD_RE.split(raw) if part)


def reload_types() -> List[str]:
    global TRAIN_TYPES, _LOADED
    path = types_path()
    names: List[str] = []
    if path.is_file():
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
            raw = data.get("types") if isinstance(data, dict) else data
            if isinstance(raw, list):
                seen = set()
                for item in raw:
                    name = str(item or "").strip()
                    if not name or name.upper() in seen:
                        continue
                    seen.add(name.upper())
                    names.append(name)
        except (OSError, json.JSONDecodeError, TypeError):
            names = []
    TRAIN_TYPES = _place_con_after_coal(_pin_first(names or shipped_types()))
    _LOADED = True
    return list(TRAIN_TYPES)


def _pin_first(names: List[str]) -> List[str]:
    pinned = [name for name in names if name.upper() == PINNED_TYPE]
    return pinned[:1] + [name for name in names if name.upper() != PINNED_TYPE]


def _place_con_after_coal(names: List[str]) -> List[str]:
    """CON sits immediately after COAL. Other chips, including PIG, stay where they are."""
    con = [name for name in names if str(name).upper() == "CON"]
    if not con or not any(str(name).upper() == "COAL" for name in names):
        return names
    out: List[str] = []
    for name in names:
        if str(name).upper() == "CON":
            continue
        out.append(name)
        if str(name).upper() == "COAL":
            out.append(con[0])
    return out


def list_types() -> List[str]:
    if not _LOADED:
        reload_types()
    return _place_con_after_coal(list(TRAIN_TYPES))


def _write(names: List[str]) -> List[str]:
    global TRAIN_TYPES
    cleaned = []
    seen = set()
    for item in names:
        name = str(item or "").strip()
        if not name:
            continue
        key = name.upper()
        if key in seen:
            continue
        seen.add(key)
        cleaned.append(name)
    if not cleaned:
        cleaned = shipped_types()
    cleaned = _place_con_after_coal(_pin_first(cleaned))
    types_path().write_text(
        json.dumps({"types": cleaned}, indent=2) + "\n",
        encoding="utf-8",
    )
    TRAIN_TYPES = cleaned
    return list(TRAIN_TYPES)


def add_type(name: str) -> List[str]:
    current = list_types()
    text = (name or "").strip()
    if not text:
        from validators import ValidationError

        raise ValidationError("Train type is required", "name")
    if any(item.upper() == text.upper() for item in current):
        return current
    current.append(text)
    return _write(current)


def save_type_order(names: List[str]) -> List[str]:
    """Reorder the chips; unknown names are ignored and missing ones keep their place at the end."""
    current = list_types()
    by_key = {item.upper(): item for item in current}
    ordered: List[str] = []
    for raw in names or []:
        item = by_key.pop(str(raw or "").strip().upper(), None)
        if item:
            ordered.append(item)
    ordered.extend(item for item in current if item.upper() in by_key)
    return _write(ordered)


def remove_type(name: str) -> List[str]:
    text = (name or "").strip()
    current = [item for item in list_types() if item.upper() != text.upper()]
    return _write(current)


def reset_types() -> List[str]:
    path = types_path()
    if path.exists():
        path.unlink()
    return reload_types()


def reload_type_filters() -> List[Dict[str, str]]:
    global _TYPE_FILTERS, _FILTERS_LOADED
    path = type_filters_path()
    mapping: Dict[str, str] = {}
    if not path.is_file():
        mapping = _clean_filters(shipped_type_filters())
    else:
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError, TypeError):
            data = {}
        raw = data.get("filters") if isinstance(data, dict) else data
        if isinstance(raw, dict):
            mapping = _clean_filters(raw)
        elif isinstance(raw, list):
            pairs = {}
            for item in raw:
                if not isinstance(item, dict):
                    continue
                incoming = str(item.get("incoming") or item.get("from") or "").strip()
                stored = str(item.get("stored") or item.get("to") or "").strip()
                if incoming and stored:
                    pairs[incoming] = stored
            mapping = _clean_filters(pairs)
    _TYPE_FILTERS = mapping
    _FILTERS_LOADED = True
    return list_type_filters()


def list_type_filters() -> List[Dict[str, str]]:
    if not _FILTERS_LOADED:
        reload_type_filters()
    rows = [{"incoming": key, "stored": value} for key, value in _TYPE_FILTERS.items()]
    rows.sort(key=lambda item: item["incoming"].upper())
    return rows


def _filters() -> Dict[str, str]:
    if not _FILTERS_LOADED:
        reload_type_filters()
    return _TYPE_FILTERS


def _clean_filters(raw: Any) -> Dict[str, str]:
    out: Dict[str, str] = {}
    if not isinstance(raw, dict):
        return out
    for key, value in raw.items():
        incoming = str(key or "").strip()
        stored = str(value or "").strip()
        if not incoming or not stored:
            continue
        fold = fold_type_key(incoming)
        if not fold:
            continue
        canonical = _catalog_spelling(stored) or stored
        out[incoming] = canonical
    # Drop duplicate folded keys, keeping the last incoming spelling.
    cleaned: Dict[str, str] = {}
    seen_fold: Dict[str, str] = {}
    for incoming, stored in out.items():
        fold = fold_type_key(incoming)
        previous = seen_fold.get(fold)
        if previous:
            cleaned.pop(previous, None)
        seen_fold[fold] = incoming
        cleaned[incoming] = stored
    return cleaned


def _write_filters(mapping: Dict[str, str]) -> List[Dict[str, str]]:
    global _TYPE_FILTERS
    cleaned = _clean_filters(mapping)
    path = type_filters_path()
    if not cleaned and not shipped_type_filters():
        if path.exists():
            path.unlink()
    else:
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(
            json.dumps({"filters": cleaned}, indent=2) + "\n",
            encoding="utf-8",
        )
    _TYPE_FILTERS = cleaned
    return list_type_filters()


def add_type_filter(incoming: str, stored: str) -> List[Dict[str, str]]:
    from validators import ValidationError

    source = str(incoming or "").strip()
    target = str(stored or "").strip()
    if not source:
        raise ValidationError("Incoming label is required", "incoming")
    if not target:
        raise ValidationError("Stored type is required", "stored")
    catalog = _catalog_spelling(target)
    if not catalog:
        raise ValidationError("Store as must be a train type on the pad", "stored")
    mapping = dict(_filters())
    fold = fold_type_key(source)
    for key in list(mapping):
        if fold_type_key(key) == fold:
            mapping.pop(key, None)
    mapping[source] = catalog
    return _write_filters(mapping)


def remove_type_filter(incoming: str) -> List[Dict[str, str]]:
    text = str(incoming or "").strip()
    fold = fold_type_key(text)
    mapping = {
        key: value
        for key, value in _filters().items()
        if fold_type_key(key) != fold
    }
    return _write_filters(mapping)


def reset_type_filters() -> List[Dict[str, str]]:
    path = type_filters_path()
    if path.exists():
        path.unlink()
    return reload_type_filters()


def _catalog_spelling(token: Any) -> str:
    text = str(token or "").strip()
    if not text:
        return ""
    fold = fold_type_key(text)
    for name in list_types():
        if fold_type_key(name) == fold or name.upper() == text.upper():
            return name
    return ""


def _filter_target(token: Any) -> str:
    fold = fold_type_key(token)
    if not fold:
        return ""
    for incoming, stored in _filters().items():
        if fold_type_key(incoming) == fold:
            return _catalog_spelling(stored) or stored
    return ""


def _nickname_target(token: Any) -> str:
    fold = fold_type_key(token)
    if not fold:
        return ""
    for alias, stored in TYPE_NICKNAMES:
        if fold_type_key(alias) == fold:
            return stored
    alias = TYPE_ALIASES.get(str(token or "").strip()) or TYPE_ALIASES.get(
        str(token or "").strip().upper()
    )
    if alias:
        return alias
    return ""


def _meaning_target(token: Any) -> str:
    fold = fold_type_key(token)
    if not fold:
        return ""
    try:
        from acronyms import list_meanings
    except ImportError:
        return ""
    meanings = (list_meanings().get("types") or {})
    for name, meaning in meanings.items():
        if fold_type_key(meaning) == fold:
            return _catalog_spelling(name) or str(name).strip()
    return ""


def lookup_canonical_type(token: Any) -> str:
    """Return the stored type for an incoming label, or empty if unknown."""
    text = str(token or "").strip()
    if not text:
        return ""
    mapped = _filter_target(text)
    if mapped:
        return mapped
    catalog = _catalog_spelling(text)
    if catalog:
        return catalog
    meaning = _meaning_target(text)
    if meaning:
        return meaning
    nick = _nickname_target(text)
    if nick:
        return _catalog_spelling(nick) or nick
    return ""


def normalize_train_type(token: Any) -> str:
    text = str(token or "").strip()
    if not text:
        return ""
    return lookup_canonical_type(text) or text


def _split_tokens() -> List[str]:
    seen = set()
    tokens: List[str] = []

    def add(name: Any) -> None:
        text = str(name or "").strip()
        if not text:
            return
        key = text.upper()
        if key in seen:
            return
        seen.add(key)
        tokens.append(text)

    for name in list_types():
        add(name)
    for alias in TYPE_ALIASES:
        add(alias)
    for alias, _stored in TYPE_NICKNAMES:
        add(alias)
    for incoming in _filters():
        add(incoming)
    try:
        from acronyms import list_meanings

        for meaning in (list_meanings().get("types") or {}).values():
            add(meaning)
    except ImportError:
        pass
    tokens.sort(key=len, reverse=True)
    return tokens


def _token_prefix_match(remaining: str, token: str) -> bool:
    if not remaining or not token or len(remaining) < len(token):
        return False
    if remaining[: len(token)].upper() != token.upper():
        return False
    if len(remaining) == len(token):
        return True
    return remaining[len(token) :].startswith("/")


def split_type_string(text: str) -> List[str]:
    remaining = str(text or "").strip()
    if not remaining:
        return []
    found: List[str] = []
    known = _split_tokens()
    while remaining:
        remaining = remaining.lstrip("/").strip()
        if not remaining:
            break
        matched = None
        for token in known:
            if _token_prefix_match(remaining, token):
                matched = token
                break
        if matched:
            found.append(normalize_train_type(matched))
            remaining = remaining[len(matched) :].lstrip("/")
        else:
            part, _, remaining = remaining.partition("/")
            if part.strip():
                found.append(normalize_train_type(part))
    return found


def _should_split(text: str) -> bool:
    if "/" not in text and "," not in text:
        return False
    return not lookup_canonical_type(text)


def canonicalize_train_types(tokens: List[Any]) -> List[str]:
    found: List[str] = []
    for token in tokens:
        text = str(token or "").strip()
        if not text:
            continue
        if "," in text and not lookup_canonical_type(text):
            for part in text.split(","):
                found.extend(canonicalize_train_types([part]))
            continue
        if _should_split(text):
            found.extend(split_type_string(text))
            continue
        name = normalize_train_type(text)
        if name:
            found.append(name)
    return _dedupe_and_order(found)


def _dedupe_and_order(names: List[str]) -> List[str]:
    catalog = list_types()
    rank = {fold_type_key(name): index for index, name in enumerate(catalog)}
    chosen: Dict[str, str] = {}
    for name in names:
        text = str(name or "").strip()
        if not text:
            continue
        key = fold_type_key(text) or text.upper()
        if key in chosen:
            continue
        chosen[key] = _catalog_spelling(text) or text

    def sort_key(item: Tuple[str, str]) -> Tuple[int, int, str]:
        key, display = item
        if key in rank:
            return (0, rank[key], display.upper())
        return (1, 0, display.upper())

    return [display for _key, display in sorted(chosen.items(), key=sort_key)]
