"""Field Sync: a field device running the field app sends sightings to this Mac.

When turned on, two small servers listen on the local network, and (when the Mac
is online) an easy HTTPS link (Cloudflare tunnel) is started so the field device
does not need the Mac certificate.

* HTTPS (port 5443) serves the field app plus /sync/pair and /sync/push.
* HTTP (port 5080) serves a legacy setup page and certificate (optional fallback).
* Easy link: public https://….trycloudflare.com → local 5443 (preferred for field devices).

The Mac's own log is never served to the network. Sync only adds sightings through the normal
import, so look-alikes wait in Import Review and nothing already in the log is changed.
"""
from __future__ import annotations

import datetime as dt
import hashlib
import ipaddress
import json
import re
import secrets
import socket
import subprocess
import sys
import threading
import time
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional
from urllib.parse import quote

from flask import Flask, Response, jsonify, request, send_from_directory

import data_updates
import field_tunnel
from paths import resource_root, support_dir
from version import APP_VERSION

HTTPS_PORT = 5443
SETUP_PORT = 5080
MAX_BAD_CODES = 8
SERVER_CERT_DAYS = 800
CA_NAME = "TRAIN LOG on this Mac"
# Public HTTPS install of the field app (no Mac certificate needed to pin the icon).
FIELD_SITE_URL = "https://graphicsmike.github.io/trainlog-field/"

FIREWALL = "/usr/libexec/ApplicationFirewall/socketfilterfw"
RETRY_SECONDS = 30

_lock = threading.RLock()
_servers: List[Any] = []
_error = ""
_get_db: Optional[Callable[[], Any]] = None
_retry: Optional[threading.Timer] = None
_firewall_cache: Dict[str, Any] = {"at": 0.0, "value": None}
_build_id: Optional[str] = None
_reached_mark: Dict[str, Any] = {}


def sync_dir() -> Path:
    path = support_dir() / "phone-sync"
    path.mkdir(parents=True, exist_ok=True)
    return path


def field_dir() -> Path:
    return resource_root() / "dist-field"


def _now() -> str:
    return dt.datetime.now().strftime("%Y-%m-%d %H:%M:%S")


def _stamp_field_index(html: str) -> str:
    """Paint the running Mac's APP_VERSION on the install page so Safari isn't stuck on an old stamp."""
    html = re.sub(
        r"(Field Book for Railfans · )\d+\.\d+\.\d+",
        r"\g<1>" + APP_VERSION,
        html,
        count=1,
    )
    stamp = (
        '<p id="phone-sync-serving" class="muted" '
        'style="margin:0 0 8px;font-weight:650">'
        "This Mac is serving TRAIN LOG "
        + APP_VERSION
        + "</p>"
    )
    if 'id="phone-sync-serving"' in html:
        html = re.sub(
            r'<p id="phone-sync-serving"[^>]*>.*?</p>',
            stamp,
            html,
            count=1,
            flags=re.S,
        )
    elif "<main" in html:
        html = re.sub(r"(<main[^>]*>)", r"\1\n    " + stamp, html, count=1)
    else:
        html = stamp + html
    # Bust leftover HTTP caches when the Mac version changes.
    if 'rel="stylesheet" href="field.css' in html:
        html = re.sub(
            r'(href="field\.css)(\?v=[^"]*)?(")',
            r"\1?v=" + APP_VERSION + r"\3",
            html,
            count=1,
        )
    for name in ("boot.js", "offline.js"):
        html = re.sub(
            r'(src="' + name + r')(\?v=[^"]*)?(")',
            r"\1?v=" + APP_VERSION + r"\3",
            html,
            count=1,
        )
    return html


def field_index_response() -> Response:
    folder = field_dir()
    path = folder / "index.html"
    if not path.is_file():
        return Response(
            "The field app isn't built yet. On the Mac, run: venv/bin/python scripts/build_field_app.py",
            status=503,
            mimetype="text/plain",
        )
    html = _stamp_field_index(path.read_text(encoding="utf-8"))
    response = Response(html, mimetype="text/html; charset=utf-8")
    response.headers["Cache-Control"] = "no-store"
    response.headers["Pragma"] = "no-cache"
    return response


def _state_path() -> Path:
    return sync_dir() / "state.json"


def load_state() -> Dict[str, Any]:
    try:
        state = json.loads(_state_path().read_text(encoding="utf-8"))
    except (OSError, ValueError):
        state = {}
    state.setdefault("enabled", False)
    state.setdefault("devices", [])
    state.setdefault("code", "")
    state.setdefault("bad_codes", 0)
    return state


def save_state(state: Dict[str, Any]) -> None:
    path = _state_path()
    tmp = path.with_suffix(".tmp")
    tmp.write_text(json.dumps(state, indent=2), encoding="utf-8")
    tmp.replace(path)


def new_code(state: Dict[str, Any]) -> str:
    state["code"] = "{:06d}".format(secrets.randbelow(1000000))
    state["bad_codes"] = 0
    return state["code"]


def _token_hash(token: str) -> str:
    return hashlib.sha256(token.encode("utf-8")).hexdigest()


def host_name() -> str:
    """This Mac's Bonjour name, such as Michaels-MacBook-Pro.local, which stays put when the IP changes."""
    try:
        name = subprocess.run(
            ["scutil", "--get", "LocalHostName"], capture_output=True, text=True, timeout=3
        ).stdout.strip()
    except (OSError, subprocess.SubprocessError):
        name = ""
    if not name:
        name = socket.gethostname().split(".")[0]
    return name + ".local"


def lan_addresses() -> List[str]:
    found = []
    try:
        probe = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        probe.connect(("10.255.255.255", 1))
        found.append(probe.getsockname()[0])
        probe.close()
    except OSError:
        pass
    return [ip for ip in found if not ip.startswith("127.")]


# --- certificates -------------------------------------------------------------------------

def _paths() -> Dict[str, Path]:
    base = sync_dir()
    return {
        "ca_key": base / "ca.key",
        "ca_cert": base / "ca.pem",
        "key": base / "server.key",
        "cert": base / "server.pem",
        "meta": base / "server.json",
    }


def ensure_certificates(host: Optional[str] = None) -> Dict[str, Path]:
    """Make this Mac's certificate authority once, and a server certificate for its current name.

    The phone trusts the authority, so a new server certificate (after a rename or near expiry)
    needs no change on the phone.
    """
    from cryptography import x509
    from cryptography.hazmat.primitives import hashes, serialization
    from cryptography.hazmat.primitives.asymmetric import ec
    from cryptography.x509.oid import ExtendedKeyUsageOID, NameOID

    host = host or host_name()
    paths = _paths()
    now = dt.datetime.now(dt.timezone.utc)

    if paths["ca_key"].exists() and paths["ca_cert"].exists():
        ca_key = serialization.load_pem_private_key(paths["ca_key"].read_bytes(), password=None)
        ca_cert = x509.load_pem_x509_certificate(paths["ca_cert"].read_bytes())
    else:
        ca_key = ec.generate_private_key(ec.SECP256R1())
        subject = x509.Name([
            x509.NameAttribute(NameOID.COMMON_NAME, CA_NAME),
            x509.NameAttribute(NameOID.ORGANIZATION_NAME, "TRAIN LOG"),
        ])
        ca_cert = (
            x509.CertificateBuilder()
            .subject_name(subject)
            .issuer_name(subject)
            .public_key(ca_key.public_key())
            .serial_number(x509.random_serial_number())
            .not_valid_before(now - dt.timedelta(days=1))
            .not_valid_after(now + dt.timedelta(days=3650))
            .add_extension(x509.BasicConstraints(ca=True, path_length=0), critical=True)
            .add_extension(
                x509.KeyUsage(
                    digital_signature=True, content_commitment=False, key_encipherment=False,
                    data_encipherment=False, key_agreement=False, key_cert_sign=True,
                    crl_sign=True, encipher_only=False, decipher_only=False,
                ),
                critical=True,
            )
            .add_extension(x509.SubjectKeyIdentifier.from_public_key(ca_key.public_key()), critical=False)
            .sign(ca_key, hashes.SHA256())
        )
        paths["ca_key"].write_bytes(
            ca_key.private_bytes(
                serialization.Encoding.PEM,
                serialization.PrivateFormat.PKCS8,
                serialization.NoEncryption(),
            )
        )
        paths["ca_key"].chmod(0o600)
        paths["ca_cert"].write_bytes(ca_cert.public_bytes(serialization.Encoding.PEM))
        for stale in ("key", "cert", "meta"):
            paths[stale].unlink(missing_ok=True)

    addresses = lan_addresses()
    try:
        meta = json.loads(paths["meta"].read_text(encoding="utf-8"))
    except (OSError, ValueError):
        meta = {}
    expires = meta.get("expires", "")
    fresh = (
        paths["cert"].exists()
        and paths["key"].exists()
        and meta.get("host") == host
        and set(addresses) <= set(meta.get("addresses", []))
        and expires > (now + dt.timedelta(days=30)).strftime("%Y-%m-%d")
    )
    if fresh:
        return paths

    key = ec.generate_private_key(ec.SECP256R1())
    names: List[x509.GeneralName] = [x509.DNSName(host), x509.DNSName("localhost")]
    for ip in addresses + ["127.0.0.1"]:
        names.append(x509.IPAddress(ipaddress.ip_address(ip)))
    not_after = now + dt.timedelta(days=SERVER_CERT_DAYS)
    cert = (
        x509.CertificateBuilder()
        .subject_name(x509.Name([x509.NameAttribute(NameOID.COMMON_NAME, host)]))
        .issuer_name(ca_cert.subject)
        .public_key(key.public_key())
        .serial_number(x509.random_serial_number())
        .not_valid_before(now - dt.timedelta(days=1))
        .not_valid_after(not_after)
        .add_extension(x509.SubjectAlternativeName(names), critical=False)
        .add_extension(x509.BasicConstraints(ca=False, path_length=None), critical=True)
        .add_extension(x509.ExtendedKeyUsage([ExtendedKeyUsageOID.SERVER_AUTH]), critical=False)
        .add_extension(
            x509.KeyUsage(
                digital_signature=True, content_commitment=False, key_encipherment=False,
                data_encipherment=False, key_agreement=False, key_cert_sign=False,
                crl_sign=False, encipher_only=False, decipher_only=False,
            ),
            critical=True,
        )
        .add_extension(
            x509.AuthorityKeyIdentifier.from_issuer_public_key(ca_key.public_key()), critical=False
        )
        .sign(ca_key, hashes.SHA256())
    )
    paths["key"].write_bytes(
        key.private_bytes(
            serialization.Encoding.PEM,
            serialization.PrivateFormat.PKCS8,
            serialization.NoEncryption(),
        )
    )
    paths["key"].chmod(0o600)
    paths["cert"].write_bytes(
        cert.public_bytes(serialization.Encoding.PEM) + ca_cert.public_bytes(serialization.Encoding.PEM)
    )
    paths["meta"].write_text(
        json.dumps({"host": host, "addresses": addresses, "expires": not_after.strftime("%Y-%m-%d")}),
        encoding="utf-8",
    )
    return paths


def ca_certificate_der() -> bytes:
    from cryptography import x509
    from cryptography.hazmat.primitives import serialization

    ensure_certificates()
    cert = x509.load_pem_x509_certificate(_paths()["ca_cert"].read_bytes())
    return cert.public_bytes(serialization.Encoding.DER)


# --- the network apps ---------------------------------------------------------------------

def _device_for(state: Dict[str, Any], token: str) -> Optional[Dict[str, Any]]:
    digest = _token_hash(token)
    for device in state["devices"]:
        if secrets.compare_digest(device.get("token_hash", ""), digest):
            return device
    return None


def create_phone_app(get_db: Callable[[], Any]) -> Flask:
    """The HTTPS app phones see: the field app files and the sync endpoints, nothing else."""
    app = Flask(__name__, static_folder=None)
    app.json.sort_keys = False

    @app.before_request
    def note_reached():
        note_phone_reached(request.remote_addr or "")

    @app.after_request
    def cors(response):
        # Field app may be installed from the public git site; sync still talks to this Mac.
        origin = request.headers.get("Origin") or ""
        if origin and (origin.startswith("https://graphicsmike.github.io") or origin.startswith("http://127.0.0.1") or origin.startswith("http://localhost")):
            response.headers["Access-Control-Allow-Origin"] = origin
            response.headers["Access-Control-Allow-Headers"] = "Authorization, Content-Type"
            response.headers["Access-Control-Allow-Methods"] = "GET, POST, OPTIONS"
            response.headers["Vary"] = "Origin"
        return response

    @app.route("/sync/<path:_rest>", methods=["OPTIONS"])
    def sync_preflight(_rest: str = ""):
        return Response(status=204)

    def authorized() -> Optional[Dict[str, Any]]:
        header = request.headers.get("Authorization", "")
        if not header.startswith("Bearer "):
            return None
        with _lock:
            return _device_for(load_state(), header[7:].strip())

    @app.post("/sync/pair")
    def pair():
        body = request.get_json(silent=True) or {}
        code = str(body.get("code") or "").replace(" ", "").strip()
        name = str(body.get("device") or "").strip()[:40] or "Field Device"
        with _lock:
            state = load_state()
            if not state["enabled"] or not state["code"]:
                return jsonify({"success": False, "error": "Phone sync is turned off on the Mac."}), 403
            if not secrets.compare_digest(code, state["code"]):
                state["bad_codes"] = int(state.get("bad_codes") or 0) + 1
                rotated = state["bad_codes"] >= MAX_BAD_CODES
                if rotated:
                    new_code(state)
                save_state(state)
                mac = host_name()
                if rotated:
                    message = "Too many wrong codes, so " + mac + " made a new one. Read the new code on that Mac, then try again."
                else:
                    message = "That code doesn't match " + mac + ". Check this is the right Mac, then read the code on its Field Sync screen."
                return jsonify({"success": False, "error": message, "rotated": rotated, "mac": mac}), 403
            token = secrets.token_urlsafe(32)
            device_key = str(body.get("device_id") or "").strip()[:64]
            device = None
            reclaimed = False
            if device_key:
                for saved in state["devices"]:
                    if saved.get("device_id") == device_key:
                        device = saved
                        reclaimed = True
                        break
            if device is None:
                device = {
                    "id": secrets.token_hex(6),
                    "device_id": device_key,
                    "name": name,
                    "token_hash": _token_hash(token),
                    "paired_at": _now(),
                    "last_sync": "",
                    "received": 0,
                }
                state["devices"].append(device)
            else:
                device["name"] = name
                device["token_hash"] = _token_hash(token)
                device["paired_at"] = _now()
            new_code(state)
            save_state(state)
        return jsonify(
            {
                "success": True,
                "token": token,
                "device": device["name"],
                "mac": host_name(),
                "cert": cert_tail(),
                "reclaimed": reclaimed,
            }
        )

    @app.get("/sync/hello")
    def hello():
        """Who this Mac is, before a code is entered. The code itself stays on the Mac's screen."""
        return jsonify({
            "success": True,
            "mac": host_name(),
            "cert": cert_tail(),
            "host": host_name(),
            "server_epoch": int(time.time()),
            "app_version": APP_VERSION,
        })

    @app.get("/sync/status")
    def status():
        device = authorized()
        if device is None:
            return jsonify({"success": False, "error": "This device isn't paired with the Mac."}), 401
        state = data_updates.status()
        data = {key: state[key] for key in ("source", "data_version", "sha256")}
        return jsonify(
            {
                "success": True,
                "device": device["name"],
                "mac": host_name(),
                "data": data,
                "app_version": APP_VERSION,
            }
        )

    @app.get("/sync/data")
    def data_pack():
        if authorized() is None:
            return jsonify({"success": False, "error": "This device isn't paired with the Mac."}), 401
        pack = data_updates.pack_bytes()
        if pack is None:
            return jsonify({"success": False, "error": "The Mac is using the built-in station data."}), 404
        return Response(pack, mimetype="application/zip", headers={"Cache-Control": "no-store"})

    @app.post("/sync/push")
    def push():
        device = authorized()
        if device is None:
            return jsonify({"success": False, "error": "This device isn't paired with the Mac. Pair it again."}), 401
        body = request.get_json(silent=True) or {}
        entries = body.get("entries")
        if not isinstance(entries, list):
            return jsonify({"success": False, "error": "Nothing to sync."}), 400
        result = get_db().import_records(entries, source="Field sync: " + device["name"])
        trips = body.get("trips")
        trips_changed = get_db().merge_trip_details(trips, device["name"]) if isinstance(trips, list) else 0
        failed = {int(err.get("row") or 0) for err in result["errors"]}
        received = [
            str(item.get("uid") or "")
            for index, item in enumerate(entries, start=1)
            if index not in failed and isinstance(item, dict)
        ]
        with _lock:
            state = load_state()
            for saved in state["devices"]:
                if saved["id"] == device["id"]:
                    saved["last_sync"] = _now()
                    saved["received"] = int(saved.get("received") or 0) + result["created"]
            save_state(state)
        return jsonify(
            {
                "success": True,
                "created": result["created"],
                "pending": result["pending"],
                "already": result.get("already", 0),
                "errors": result["errors"],
                "received": [uid for uid in received if uid],
                "trips": trips_changed,
            }
        )

    @app.get("/")
    def home():
        return field_index_response()

    @app.get("/index.html")
    def home_index():
        return field_index_response()

    @app.get("/<path:filename>")
    def field_file(filename: str):
        if filename == "index.html":
            return field_index_response()
        folder = field_dir()
        if not (folder / "index.html").exists():
            return Response(
                "The field app isn't built yet. On the Mac, run: venv/bin/python scripts/build_field_app.py",
                status=503,
                mimetype="text/plain",
            )
        response = send_from_directory(folder, filename)
        if filename in ("sw.js", "boot.js", "offline.js") or filename.endswith(".webmanifest"):
            response.headers["Cache-Control"] = "no-store"
            response.headers["Pragma"] = "no-cache"
        return response

    return app


SETUP_PAGE = """<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<title>TRAIN LOG setup</title>
<style>
  body {{ font: 17px/1.5 -apple-system, Helvetica, sans-serif; margin: 0; padding: 24px; background: #11161f; color: #e8ecf2; }}
  main {{ max-width: 560px; margin: 0 auto; }}
  h1 {{ font-size: 24px; margin: 0 0 4px; }}
  p.muted {{ color: #9aa6b8; margin-top: 0; }}
  ol {{ padding-left: 22px; }}
  li {{ margin-bottom: 14px; }}
  a.btn {{ display: inline-block; margin-top: 6px; padding: 10px 16px; border-radius: 10px; background: #e5484d; color: #fff; font-weight: 650; text-decoration: none; }}
  code {{ font-size: 15px; background: #1d2533; padding: 2px 6px; border-radius: 6px; }}
  .warn {{ padding: 12px 14px; border-left: 4px solid #c4921a; border-radius: 10px; background: #2a2412; }}
  .box {{ padding: 14px 16px; border-radius: 12px; background: #1d2533; margin: 16px 0; }}
  .box h2 {{ font-size: 18px; margin: 0 0 8px; }}
  #wrong-icon {{ display: none; }}
  .standalone #wrong-icon {{ display: block; }}
  .standalone #steps {{ display: none; }}
</style>
<script>
  if (navigator.standalone || matchMedia("(display-mode: standalone)").matches) document.documentElement.className = "standalone";
</script>
</head>
<body>
<main>
  <h1>TRAIN LOG on Your Field Device</h1>
  <div id="wrong-icon" class="warn">
    <strong>Wrong icon.</strong> This Home Screen icon is the setup page, not TRAIN LOG, so it can't work without signal.
    Delete this icon, then open Safari, go to <code>https://{host}:{port}/?v={version}</code>, and add that page to your Home Screen instead.
  </div>
  <div id="steps">
  <p class="muted">From {host}. This Mac is serving <strong>TRAIN LOG {version}</strong>. Do these steps once.</p>
  <p class="warn">Don't add this setup page to your Home Screen. Add TRAIN LOG itself in step 3.</p>
  <ol>
    <li>Install this Mac's certificate so Safari trusts it.<br />
      <a class="btn" href="/train-log-certificate.cer">Download Certificate</a><br />
      Tap <strong>Allow</strong>, then open <strong>Settings</strong>, tap <strong>Profile Downloaded</strong>, and tap <strong>Install</strong>.</li>
    <li>Turn on full trust: <strong>Settings → General → About → Certificate Trust Settings</strong>, then switch on <strong>{ca}</strong>.</li>
    <li>Open the app in Safari:<br />
      <a class="btn" href="https://{host}:{port}/?v={version}">Open TRAIN LOG {version}</a></li>
  </ol>
  <div class="box">
    <h2>Add to Home Screen</h2>
    <p class="muted">Safari can't pin TRAIN LOG for you. After Open TRAIN LOG:</p>
    <ol>
      <li>Tap <strong>Share</strong> (square with an arrow up).</li>
      <li>Tap <strong>Add to Home Screen</strong>, then <strong>Add</strong>.</li>
      <li>Use that Home Screen icon from now on.</li>
    </ol>
    <p class="warn"><strong>Do not delete the Home Screen icon to update.</strong> That can wipe your field log. After a Mac TRAIN LOG update, open the same icon → <strong>Updates → Get Update</strong> or Sync with Mac → Get Update.</p>
  </div>
  <ol start="4">
    <li>Open TRAIN LOG from the new Home Screen icon and leave it open on this Wi-Fi until the badge under the TRAIN LOG name says <strong>Offline ready</strong>. The first time takes a minute or two.</li>
    <li>In the app, tap <strong>Sync with Mac</strong> and enter the 6-digit code once. Later, <strong>Sync Now</strong> is a one-time handoff when you're home — the field device does not stay connected to the Mac trackside.</li>
    <li>To be sure, turn on <strong>Airplane Mode</strong> and open the icon again. If TRAIN LOG starts, it will work trackside without signal.</li>
  </ol>
  <div class="box">
    <h2>Won't reload after an update?</h2>
    <p class="muted">Keep TRAIN LOG open on the Mac with Field Sync on, then open:</p>
    <p><a class="btn" href="https://{host}:{port}/?repair=1&amp;v={version}">Repair Install ({version})</a></p>
    <p class="muted">That clears a stuck offline copy and reloads TRAIN LOG {version} from this Mac. Your sightings stay on the device. Then use the Home Screen icon again — don't delete it.</p>
  </div>
  </div>
</main>
</body>
</html>
"""


def create_setup_app() -> Flask:
    app = Flask(__name__ + ".setup", static_folder=None)

    @app.get("/")
    def setup_page():
        page = SETUP_PAGE.format(host=host_name(), port=HTTPS_PORT, ca=CA_NAME, version=APP_VERSION)
        response = Response(page, mimetype="text/html; charset=utf-8")
        response.headers["Cache-Control"] = "no-store"
        response.headers["Pragma"] = "no-cache"
        return response

    @app.get("/train-log-certificate.cer")
    def certificate():
        return Response(
            ca_certificate_der(),
            mimetype="application/x-x509-ca-cert",
            headers={"Content-Disposition": "attachment; filename=train-log-certificate.cer"},
        )

    return app


# --- start, stop, and status ---------------------------------------------------------------

def running() -> bool:
    return bool(_servers)


def port_owner(port: int) -> str:
    """Name of the program listening on a port, or "" when it can't be told."""
    try:
        out = subprocess.run(
            ["lsof", "-nP", "-iTCP:{}".format(port), "-sTCP:LISTEN", "-Fc"],
            capture_output=True, text=True, timeout=5,
        ).stdout
    except (OSError, subprocess.SubprocessError):
        return ""
    for line in out.splitlines():
        if line.startswith("c") and len(line) > 1:
            return line[1:].replace("\\x20", " ")
    return ""


def _schedule_retry() -> None:
    global _retry
    if _retry is not None or _get_db is None:
        return

    def again() -> None:
        global _retry
        with _lock:
            _retry = None
        if _get_db is not None and load_state()["enabled"] and not running():
            start(_get_db)

    _retry = threading.Timer(RETRY_SECONDS, again)
    _retry.daemon = True
    _retry.start()


def _tls_context(cert_path: Path, key_path: Path):
    """TLS for Field Sync. A plain (cert, key) tuple is fine on older macOS; an explicit
    server context behaves more reliably on macOS 15+ / 26 when Safari downloads the field app."""
    import ssl

    ctx = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
    ctx.minimum_version = ssl.TLSVersion.TLSv1_2
    ctx.load_cert_chain(str(cert_path), str(key_path))
    return ctx


def start(get_db: Callable[[], Any]) -> None:
    global _error, _get_db
    from werkzeug.serving import make_server

    with _lock:
        _get_db = get_db
        if _servers:
            return
        secure = None
        try:
            paths = ensure_certificates()
            secure = make_server(
                "0.0.0.0",
                HTTPS_PORT,
                create_phone_app(get_db),
                threaded=True,
                ssl_context=_tls_context(paths["cert"], paths["key"]),
            )
            setup = make_server("0.0.0.0", SETUP_PORT, create_setup_app(), threaded=True)
        except (OSError, SystemExit) as exc:
            # werkzeug calls sys.exit(1) instead of raising when a port is already taken.
            if secure is not None:
                secure.server_close()
            port = SETUP_PORT if secure is not None else HTTPS_PORT
            owner = port_owner(port)
            if isinstance(exc, SystemExit) or owner:
                _error = "Port {} is already in use by another program{}. TRAIN LOG keeps trying every {} seconds and turns Field Sync on when the port is free.".format(
                    port, " ({})".format(owner) if owner else "", RETRY_SECONDS
                )
            else:
                _error = "Could not listen on the network (ports {} and {}): {}".format(HTTPS_PORT, SETUP_PORT, exc)
            _schedule_retry()
            return
        _error = ""
        for server, name in ((secure, "phone-sync-https"), (setup, "phone-sync-setup")):
            threading.Thread(target=server.serve_forever, name=name, daemon=True).start()
            _servers.append(server)

        def _open_easy_link():
            # Public HTTPS so field devices need no Mac certificate.
            field_tunnel.start("https://127.0.0.1:{}".format(HTTPS_PORT))

        threading.Thread(target=_open_easy_link, name="field-easy-link", daemon=True).start()


def stop() -> None:
    global _retry, _error, _get_db
    field_tunnel.stop()
    with _lock:
        if _retry is not None:
            _retry.cancel()
            _retry = None
        _error = ""
        _get_db = None
        while _servers:
            server = _servers.pop()
            try:
                server.shutdown()
                server.server_close()
            except Exception:
                pass


def set_enabled(enabled: bool, get_db: Callable[[], Any]) -> None:
    with _lock:
        state = load_state()
        state["enabled"] = bool(enabled)
        if enabled and not state["code"]:
            new_code(state)
        save_state(state)
    if enabled:
        start(get_db)
    else:
        stop()


# --- the Mac firewall ------------------------------------------------------------------------
# An ad-hoc signed app counts as a new program to the firewall after every update, and stealth
# mode drops a phone's connection without a word. A phone reaching this build proves the way is open.

def app_executable() -> str:
    """The running TRAIN LOG.app program, or "" outside the packaged Mac app."""
    if getattr(sys, "frozen", False) and sys.platform == "darwin":
        return str(Path(sys.executable).resolve())
    return ""


def build_id() -> str:
    """The code hash of the running app, which changes with every build."""
    global _build_id
    if _build_id is None:
        _build_id = ""
        exe = app_executable()
        if exe:
            try:
                out = subprocess.run(["codesign", "-dvvv", exe], capture_output=True, text=True, timeout=10).stderr
            except (OSError, subprocess.SubprocessError):
                out = ""
            for line in out.splitlines():
                if line.startswith("CDHash="):
                    _build_id = line.split("=", 1)[1].strip()
                    break
            if not _build_id:
                try:
                    _build_id = "mtime-{}".format(int(Path(exe).stat().st_mtime))
                except OSError:
                    pass
    return _build_id


def _firewall(*args: str) -> str:
    try:
        return subprocess.run([FIREWALL, *args], capture_output=True, text=True, timeout=10).stdout
    except (OSError, subprocess.SubprocessError):
        return ""


def _listed_apps(text: str) -> Dict[str, bool]:
    """Path -> allowed, from `socketfilterfw --listapps`."""
    apps: Dict[str, bool] = {}
    current = ""
    for raw in text.splitlines():
        line = raw.strip()
        if " : " in line and line.split(" : ", 1)[0].strip().isdigit():
            current = line.split(" : ", 1)[1].strip()
            apps[current] = False
        elif current and line.startswith("("):
            apps[current] = "Allow" in line
            current = ""
    return apps


def note_phone_reached(address: str) -> None:
    """Called for each request a phone makes: remember that this build is reachable."""
    if not address or address.startswith("127.") or address in ("::1", "localhost") or address in lan_addresses():
        return
    build = build_id()
    stamp = _now()
    if _reached_mark.get("mark") == (build, stamp[:16]):
        return
    with _lock:
        _reached_mark["mark"] = (build, stamp[:16])
        state = load_state()
        state["reached_build"] = build
        state["last_reached"] = stamp
        save_state(state)
    _firewall_cache["at"] = 0.0


def firewall_status(force: bool = False) -> Dict[str, Any]:
    """Whether the Mac firewall may keep phones out of this copy of TRAIN LOG."""
    exe = app_executable()
    if not exe or not Path(FIREWALL).exists():
        return {"checked": False, "blocking": False}
    cached = _firewall_cache["value"]
    if cached is not None and not force and time.monotonic() - _firewall_cache["at"] < 15:
        return cached
    on = "enabled" in _firewall("--getglobalstate").lower()
    block_all = "set to enabled" in _firewall("--getblockall").lower()
    stealth = "is on" in _firewall("--getstealthmode").lower()
    allowed = _listed_apps(_firewall("--listapps")).get(exe)
    with _lock:
        state = load_state()
    build = build_id()
    proven = bool(build) and build in (state.get("reached_build"), state.get("firewall_build"))
    if not on:
        reason = ""
    elif block_all:
        reason = "block_all"
    elif allowed is False:
        reason = "blocked"
    elif not proven:
        reason = "unproven"
    else:
        reason = ""
    value = {
        "checked": True,
        "on": on,
        "stealth": stealth,
        "block_all": block_all,
        "listed": allowed is not None,
        "allowed": bool(allowed),
        "blocking": bool(reason),
        "reason": reason,
        "app": exe,
    }
    _firewall_cache.update(at=time.monotonic(), value=value)
    return value


ALLOW_SCRIPT = """on run argv
    set fw to quoted form of (item 1 of argv)
    set exe to quoted form of (item 2 of argv)
    do shell script fw & " --remove " & exe & " >/dev/null 2>&1; " & fw & " --add " & exe & " && " & fw & " --unblockapp " & exe with prompt "TRAIN LOG needs your password once to let your field devices reach it through the Mac firewall." with administrator privileges
end run"""


def allow_through_firewall() -> Dict[str, Any]:
    """Ask macOS for the password, then add this exact build to the firewall's allowed apps."""
    exe = app_executable()
    if not exe:
        return {"success": False, "error": "This only works in the TRAIN LOG Mac app."}
    try:
        done = subprocess.run(
            ["osascript", "-e", ALLOW_SCRIPT, FIREWALL, exe], capture_output=True, text=True, timeout=300
        )
    except (OSError, subprocess.SubprocessError) as exc:
        return {"success": False, "error": "Could not change the firewall: {}".format(exc)}
    if done.returncode != 0:
        if "-128" in done.stderr:
            return {"success": False, "error": "Cancelled. The firewall was not changed."}
        return {"success": False, "error": "Could not change the firewall: {}".format(done.stderr.strip() or "unknown error")}
    with _lock:
        state = load_state()
        state["firewall_build"] = build_id()
        save_state(state)
    _firewall_cache["at"] = 0.0
    return {"success": True}


def cert_tail() -> str:
    """Last 4 characters of this Mac's server certificate, so a phone can tell Macs apart."""
    path = _paths()["cert"]
    if not path.is_file():
        return ""
    return hashlib.sha256(path.read_bytes()).hexdigest()[-4:].upper()


def preferred_host() -> str:
    """LAN IP first — .local often hangs on field devices. Fall back to Bonjour name."""
    addresses = lan_addresses()
    return addresses[0] if addresses else host_name()


def qr_svg(payload: str) -> str:
    """An SVG the phone camera can open. Empty when the QR library isn't installed."""
    if not payload:
        return ""
    try:
        import io

        import qrcode
        import qrcode.image.svg
    except ImportError:
        return ""
    image = qrcode.make(payload, image_factory=qrcode.image.svg.SvgPathImage, border=1)
    buffer = io.BytesIO()
    image.save(buffer)
    text = buffer.getvalue().decode("utf-8")
    start = text.find("<svg")
    return text[start:] if start >= 0 else ""


def sync_public_base(host: str) -> str:
    """HTTPS origin the field device should call for /sync/*. Prefer easy link (no cert)."""
    tunnel = field_tunnel.public_url()
    if tunnel:
        return tunnel.rstrip("/")
    return "https://{}:{}".format(host, HTTPS_PORT)


def pair_qr(host: str, code: str) -> str:
    """Pairing QR: opens the public field site with mac + code filled in."""
    if not code:
        return ""
    mac = sync_public_base(host)
    base = FIELD_SITE_URL.rstrip("/") + "/"
    payload = "{}?mac={}&pair={}&fp={}".format(
        base, quote(mac, safe=""), code, quote(cert_tail(), safe="")
    )
    return qr_svg(payload)


def setup_urls(host: str) -> Dict[str, str]:
    """Install / link / repair URLs. Easy-link (tunnel) preferred when available."""
    public = sync_public_base(host)
    setup = "http://{}:{}/".format(host, SETUP_PORT)
    app = "{}/?v={}".format(public, APP_VERSION)
    repair = "{}/?repair=1&v={}".format(public, APP_VERSION)
    install = FIELD_SITE_URL.rstrip("/") + "/?v={}".format(APP_VERSION)
    return {
        "setup_url": setup,
        "app_url": app,
        "repair_url": repair,
        "install_url": install,
        "sync_url": public,
        "easy_link": field_tunnel.public_url(),
        "easy_link_error": field_tunnel.status().get("error") or "",
        "easy_link_starting": bool(field_tunnel.status().get("starting")),
        "needs_certificate": not bool(field_tunnel.public_url()),
    }


def keep_state_across_updates() -> str:
    """Keep phone-sync/ with the log: copy it aside on a new version, and put it back if an update left it missing."""
    import shutil

    from version import APP_VERSION

    path = _state_path()
    folder = support_dir() / "backups"
    latest = folder / "phone-sync-latest.json"
    if path.is_file():
        folder.mkdir(parents=True, exist_ok=True)
        versioned = folder / "phone-sync-opened-{}.json".format(APP_VERSION)
        if not versioned.is_file():
            shutil.copy(path, folder / "phone-sync-before-{}.json".format(APP_VERSION))
            versioned.write_text(APP_VERSION, encoding="utf-8")
        shutil.copy(path, latest)
        return ""
    if latest.is_file():
        shutil.copy(latest, path)
        return "Field Sync settings were missing after an update. Restored them from the last backup."
    return ""


def note_restored_state() -> None:
    global _restored_note
    _restored_note = keep_state_across_updates()


_restored_note = ""


def status() -> Dict[str, Any]:
    global _restored_note
    with _lock:
        state = load_state()
        if state["enabled"] and not _servers and _get_db is not None and _retry is None:
            start(_get_db)
    host = preferred_host()
    note = _restored_note
    _restored_note = ""
    urls = setup_urls(host)
    code = state["code"] if state["enabled"] else ""
    return {
        "enabled": state["enabled"],
        "running": running(),
        "error": _error,
        "firewall": firewall_status() if state["enabled"] else {"checked": False, "blocking": False},
        "last_reached": state.get("last_reached") or "",
        "host": host,
        "bonjour_host": host_name(),
        "addresses": lan_addresses(),
        "setup_url": urls["setup_url"],
        "app_url": urls["app_url"],
        "repair_url": urls["repair_url"],
        "install_url": urls["install_url"],
        "app_version": APP_VERSION,
        "code": code,
        "cert": cert_tail(),
        "certificate_path": str(_paths()["ca_cert"]) if _paths()["ca_cert"].is_file() else "",
        "qr": pair_qr(host, code) if code else "",
        "setup_qr": qr_svg(urls["setup_url"]) if state["enabled"] else "",
        "app_qr": qr_svg(urls["app_url"]) if state["enabled"] else "",
        "install_qr": qr_svg(
            urls["install_url"]
            + ("&mac={}".format(quote(urls["sync_url"], safe="")) if urls.get("sync_url") else "")
        )
        if state["enabled"]
        else "",
        "sync_url": urls.get("sync_url") or "",
        "easy_link": urls.get("easy_link") or "",
        "easy_link_error": urls.get("easy_link_error") or "",
        "easy_link_starting": bool(urls.get("easy_link_starting")),
        "needs_certificate": bool(urls.get("needs_certificate")),
        "repair_qr": qr_svg(urls["repair_url"]) if state["enabled"] else "",
        "restored": note,
        "field_built": (field_dir() / "index.html").exists(),
        "devices": [
            {k: device.get(k) for k in ("id", "name", "paired_at", "last_sync", "received")}
            for device in state["devices"]
        ],
    }


def refresh_code() -> str:
    with _lock:
        state = load_state()
        code = new_code(state)
        save_state(state)
    return code


def remove_device(device_id: str) -> bool:
    with _lock:
        state = load_state()
        before = len(state["devices"])
        state["devices"] = [d for d in state["devices"] if d.get("id") != device_id]
        save_state(state)
    return len(state["devices"]) < before
