"""Attendee and vehicle buttons offered in Trip Details.

Defaults ship in assets/reference/trip-picks.json; edits made in Settings live in Application Support.
"""
from __future__ import annotations

import json
import re
from typing import Any, Dict, List

from paths import shipped_json, support_dir

KINDS = ("attendees", "vehicles")
MAX_NAME = 100


def picks_path():
    return support_dir() / "trip_picks.json"


def _clean(raw: Any) -> List[str]:
    names: List[str] = []
    seen = set()
    for item in raw if isinstance(raw, list) else []:
        name = re.sub(r"\s+", " ", str(item or "")).strip().strip(",;").strip()[:MAX_NAME]
        if name and name.lower() not in seen:
            seen.add(name.lower())
            names.append(name)
    return names


def shipped_picks() -> Dict[str, List[str]]:
    data = shipped_json("reference", "trip-picks.json")
    data = data if isinstance(data, dict) else {}
    return {kind: _clean(data.get(kind)) for kind in KINDS}


def list_picks() -> Dict[str, List[str]]:
    path = picks_path()
    if not path.is_file():
        return shipped_picks()
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return shipped_picks()
    data = data if isinstance(data, dict) else {}
    shipped = shipped_picks()
    return {kind: _clean(data[kind]) if kind in data else shipped[kind] for kind in KINDS}


def save_picks(raw: Dict[str, Any]) -> Dict[str, List[str]]:
    picks = list_picks()
    for kind in KINDS:
        if kind in (raw or {}):
            picks[kind] = _clean(raw[kind])
    picks_path().write_text(json.dumps(picks, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    return picks


def reset_picks() -> Dict[str, List[str]]:
    path = picks_path()
    if path.exists():
        path.unlink()
    return list_picks()
