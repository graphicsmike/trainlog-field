"""Desktop/field appearance prefs that survive a port (origin) change.

Theme used to live only in localStorage, keyed to http://127.0.0.1:<port>.
When TRAIN LOG falls back to a different preferred port, Night was lost and
Intel Macs (where Qt often reports light for prefers-color-scheme) opened on Paper.
"""
from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Dict

from paths import support_dir

THEMES = {
    "paper",
    "linen",
    "sage",
    "fog",
    "sand",
    "frost",
    "night",
    "slate",
    "ember",
    "pine",
    "ink",
    "coal",
}
LEGACY = {"light": "paper", "dark": "night"}


def appearance_path() -> Path:
    return support_dir() / "appearance.json"


def _normalize_theme(raw: Any) -> str:
    theme = LEGACY.get(str(raw or "").strip(), str(raw or "").strip())
    return theme if theme in THEMES else ""


def load_appearance() -> Dict[str, Any]:
    path = appearance_path()
    data: Dict[str, Any] = {"theme": "", "preferNight": False}
    if not path.is_file():
        return data
    try:
        raw = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return data
    if not isinstance(raw, dict):
        return data
    data["theme"] = _normalize_theme(raw.get("theme"))
    data["preferNight"] = bool(raw.get("preferNight"))
    return data


def save_appearance(payload: Dict[str, Any] | None) -> Dict[str, Any]:
    payload = payload if isinstance(payload, dict) else {}
    current = load_appearance()
    theme = _normalize_theme(payload.get("theme"))
    if theme:
        current["theme"] = theme
    if "preferNight" in payload:
        current["preferNight"] = bool(payload.get("preferNight"))
    path = appearance_path()
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(current, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    return current
