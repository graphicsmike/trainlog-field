"""Public HTTPS tunnel for Field Sync — no Mac certificate on the field device.

When Field Sync is on, TRAIN LOG can start a Cloudflare quick tunnel to the local
HTTPS field server. The field device then talks to https://….trycloudflare.com
(a real certificate), so Safari does not need the Mac's self-signed CA.

Requires network access on the Mac. The tunnel binary is downloaded once into
Application Support and reused.
"""
from __future__ import annotations

import json
import os
import platform
import re
import shutil
import subprocess
import threading
import time
import urllib.request
from pathlib import Path
from typing import Any, Dict, Optional

from paths import support_dir

_CLOUDFLARED_VERSION = "2025.11.1"
_URL_RE = re.compile(r"https://[a-z0-9-]+\.trycloudflare\.com", re.I)

_lock = threading.RLock()
_proc: Optional[subprocess.Popen] = None
_public_url = ""
_error = ""
_starting = False


def bin_dir() -> Path:
    path = support_dir() / "bin"
    path.mkdir(parents=True, exist_ok=True)
    return path


def cloudflared_path() -> Path:
    return bin_dir() / "cloudflared"


def _asset_name() -> str:
    machine = platform.machine().lower()
    if machine in ("arm64", "aarch64"):
        return "cloudflared-darwin-arm64.tgz"
    return "cloudflared-darwin-amd64.tgz"


def ensure_cloudflared() -> Path:
    """Download cloudflared once if missing. Raises OSError on failure."""
    path = cloudflared_path()
    if path.is_file() and os.access(path, os.X_OK):
        return path
    name = _asset_name()
    url = "https://github.com/cloudflare/cloudflared/releases/download/{}/{}".format(
        _CLOUDFLARED_VERSION, name
    )
    archive = bin_dir() / name
    urllib.request.urlretrieve(url, archive)
    # tgz contains a single binary named cloudflared
    import tarfile

    with tarfile.open(archive, "r:gz") as tar:
        member = next((m for m in tar.getmembers() if m.isfile() and m.name.endswith("cloudflared")), None)
        if member is None:
            raise OSError("cloudflared archive had no binary")
        member.name = "cloudflared"
        tar.extract(member, path=bin_dir())
    path.chmod(0o755)
    try:
        archive.unlink()
    except OSError:
        pass
    return path


def status() -> Dict[str, Any]:
    with _lock:
        return {
            "running": _proc is not None and _proc.poll() is None,
            "starting": _starting,
            "url": _public_url,
            "error": _error,
        }


def public_url() -> str:
    with _lock:
        return _public_url


def stop() -> None:
    global _proc, _public_url, _error, _starting
    with _lock:
        _starting = False
        proc = _proc
        _proc = None
        _public_url = ""
        _error = ""
    if proc is None:
        return
    try:
        proc.terminate()
        try:
            proc.wait(timeout=5)
        except subprocess.TimeoutExpired:
            proc.kill()
    except Exception:
        pass


def start(local_https: str, timeout: float = 45.0) -> str:
    """Start a quick tunnel to local_https (e.g. https://127.0.0.1:5443). Returns public URL or ''."""
    global _proc, _public_url, _error, _starting
    stop()
    with _lock:
        _starting = True
        _error = ""
        _public_url = ""
    try:
        binary = ensure_cloudflared()
    except Exception as exc:
        with _lock:
            _starting = False
            _error = "Could not download the easy-link helper: {}".format(exc)
        return ""

    try:
        proc = subprocess.Popen(
            [str(binary), "tunnel", "--no-autoupdate", "--url", local_https],
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            bufsize=1,
        )
    except OSError as exc:
        with _lock:
            _starting = False
            _error = "Could not start easy link: {}".format(exc)
        return ""

    with _lock:
        _proc = proc

    found = ""
    deadline = time.time() + timeout

    def reader():
        nonlocal found
        assert proc.stdout is not None
        for line in proc.stdout:
            match = _URL_RE.search(line or "")
            if match and not found:
                found = match.group(0).rstrip("/")
                with _lock:
                    global _public_url, _starting
                    _public_url = found
                    _starting = False
            if proc.poll() is not None:
                break

    thread = threading.Thread(target=reader, name="field-tunnel", daemon=True)
    thread.start()
    while time.time() < deadline and not found and proc.poll() is None:
        time.sleep(0.2)

    if found:
        return found

    # Timed out or exited
    code = proc.poll()
    stop()
    with _lock:
        _starting = False
        if code:
            _error = "Easy link exited before it was ready (code {}). Check that this Mac is online.".format(code)
        else:
            _error = "Easy link did not come up in time. Check that this Mac is online, then turn Field Sync off and on."
    return ""
