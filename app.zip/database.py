"""SQLite persistence for Railroad Train Log."""
from __future__ import annotations

import csv
import hashlib
import io
import json
import re
import sqlite3
import tempfile
import threading
import uuid
from datetime import date, datetime
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Tuple

from models import (
    DEFAULT_REGION,
    LocationHistory,
    LocomotiveHistory,
    PendingImport,
    TrainEntry,
    parse_types_value,
    types_to_storage,
)
from reference import reference_text
from special_power import special_power_storage
from trip_packing import clean_packing, packing_list, packing_text
from stations import spot_name
from validators import (
    DUPLICATE_WINDOW_MINUTES,
    combine_datetime,
    duplicate_window_message,
    exact_duplicate,
    is_within_window,
    normalize_consist,
    validate_entry,
    ValidationError,
)


NEW_COLUMNS = (
    ("lead_status", "TEXT NOT NULL DEFAULT ''"),
    ("night", "INTEGER NOT NULL DEFAULT 0"),
    ("coal_mark", "TEXT NOT NULL DEFAULT ''"),
    ("con_overseas", "INTEGER NOT NULL DEFAULT 0"),
    ("con_domestic", "INTEGER NOT NULL DEFAULT 0"),
    ("stopped", "INTEGER NOT NULL DEFAULT 0"),
    ("in_siding", "INTEGER NOT NULL DEFAULT 0"),
    ("crew_change", "INTEGER NOT NULL DEFAULT 0"),
    ("no_crew", "INTEGER NOT NULL DEFAULT 0"),
)


def _ensure_columns(conn: sqlite3.Connection) -> bool:
    """Add missing columns. Returns True when location_state was just added."""
    columns = {
        row["name"] for row in conn.execute("PRAGMA table_info(train_entries)").fetchall()
    }
    if "load_status" not in columns:
        conn.execute(
            "ALTER TABLE train_entries ADD COLUMN load_status TEXT NOT NULL DEFAULT ''"
        )
    if "trip_name" not in columns:
        conn.execute(
            "ALTER TABLE train_entries ADD COLUMN trip_name TEXT NOT NULL DEFAULT ''"
        )
    if "trip_date_from" not in columns:
        conn.execute(
            "ALTER TABLE train_entries ADD COLUMN trip_date_from TEXT NOT NULL DEFAULT ''"
        )
    if "trip_date_to" not in columns:
        conn.execute(
            "ALTER TABLE train_entries ADD COLUMN trip_date_to TEXT NOT NULL DEFAULT ''"
        )
    if "time_zone" not in columns:
        conn.execute(
            "ALTER TABLE train_entries ADD COLUMN time_zone TEXT NOT NULL DEFAULT ''"
        )
    if "train_symbol" not in columns:
        conn.execute(
            "ALTER TABLE train_entries ADD COLUMN train_symbol TEXT NOT NULL DEFAULT ''"
        )
    if "train_number" not in columns:
        conn.execute(
            "ALTER TABLE train_entries ADD COLUMN train_number TEXT NOT NULL DEFAULT ''"
        )
    if "train_info" not in columns:
        conn.execute(
            "ALTER TABLE train_entries ADD COLUMN train_info TEXT NOT NULL DEFAULT ''"
        )
    if "special_power" not in columns:
        conn.execute(
            "ALTER TABLE train_entries ADD COLUMN special_power TEXT NOT NULL DEFAULT ''"
        )
    if "uid" not in columns:
        conn.execute("ALTER TABLE train_entries ADD COLUMN uid TEXT NOT NULL DEFAULT ''")
    for name, kind in NEW_COLUMNS:
        if name not in columns:
            conn.execute("ALTER TABLE train_entries ADD COLUMN {} {}".format(name, kind))
    conn.execute("UPDATE train_entries SET stopped = 1, direction = '' WHERE direction = 'Stopped'")
    conn.execute("UPDATE train_entries SET in_siding = 1, direction = '' WHERE direction = 'Parked'")
    trip_columns = {row["name"] for row in conn.execute("PRAGMA table_info(trip_details)").fetchall()}
    if "vehicle" not in trip_columns:
        conn.execute("ALTER TABLE trip_details ADD COLUMN vehicle TEXT NOT NULL DEFAULT ''")
    if "fuel_log" not in trip_columns:
        conn.execute("ALTER TABLE trip_details ADD COLUMN fuel_log TEXT NOT NULL DEFAULT ''")
    if "logging_defaults" not in trip_columns:
        conn.execute("ALTER TABLE trip_details ADD COLUMN logging_defaults TEXT NOT NULL DEFAULT ''")
    if "packing" not in trip_columns:
        conn.execute("ALTER TABLE trip_details ADD COLUMN packing TEXT NOT NULL DEFAULT ''")
    if "temperature" not in trip_columns:
        conn.execute("ALTER TABLE trip_details ADD COLUMN temperature TEXT NOT NULL DEFAULT ''")
    if "location_state" not in columns:
        conn.execute(
            "ALTER TABLE train_entries ADD COLUMN location_state TEXT NOT NULL DEFAULT ''"
        )
        return True
    return False


def _fill_uids(conn: sqlite3.Connection) -> None:
    """Give every sighting a permanent ID so other devices can tell it apart from look-alikes."""
    for row in conn.execute("SELECT id FROM train_entries WHERE uid = ''").fetchall():
        conn.execute("UPDATE train_entries SET uid = ? WHERE id = ?", (uuid.uuid4().hex, row["id"]))
    conn.execute("CREATE UNIQUE INDEX IF NOT EXISTS idx_entries_uid ON train_entries(uid) WHERE uid != ''")


def _fill_states(conn: sqlite3.Connection) -> None:
    """Give existing sightings the state of their station from the station book."""
    from stations import station_state

    rows = conn.execute(
        "SELECT id, railroad, location_spot, location_subdivision FROM train_entries WHERE location_state = ''"
    ).fetchall()
    for row in rows:
        state = station_state(row["location_spot"] or "", row["railroad"] or "", row["location_subdivision"] or "")
        if state:
            conn.execute("UPDATE train_entries SET location_state = ? WHERE id = ?", (state, row["id"]))


def _fill_train_info(conn: sqlite3.Connection) -> None:
    rows = conn.execute(
        "SELECT id, railroad, train_symbol, train_number FROM train_entries "
        "WHERE train_info = '' AND (train_symbol != '' OR train_number != '')"
    ).fetchall()
    for row in rows:
        text = reference_text(row["railroad"] or "", row["train_symbol"] or "", row["train_number"] or "")
        if text:
            conn.execute("UPDATE train_entries SET train_info = ? WHERE id = ?", (text, row["id"]))


def _rewrite_canonical_train_types(conn: sqlite3.Connection) -> None:
    for table in ("train_entries", "locomotive_history"):
        try:
            rows = conn.execute("SELECT id, train_types FROM {}".format(table)).fetchall()
        except sqlite3.OperationalError:
            continue
        for row in rows:
            original = row["train_types"]
            if original is None:
                continue
            stored = types_to_storage(parse_types_value(original))
            if stored != original:
                conn.execute(
                    "UPDATE {} SET train_types = ? WHERE id = ?".format(table),
                    (stored, row["id"]),
                )
    try:
        pending_rows = conn.execute("SELECT id, payload FROM pending_imports").fetchall()
    except sqlite3.OperationalError:
        pending_rows = []
    for row in pending_rows:
        raw = row["payload"]
        if not raw:
            continue
        try:
            payload = json.loads(raw)
        except (TypeError, json.JSONDecodeError):
            continue
        if not isinstance(payload, dict) or "train_types" not in payload:
            continue
        types = parse_types_value(payload.get("train_types"))
        if types == payload.get("train_types"):
            continue
        payload["train_types"] = types
        conn.execute(
            "UPDATE pending_imports SET payload = ? WHERE id = ?",
            (json.dumps(payload, ensure_ascii=False), row["id"]),
        )

SCHEMA = """
CREATE TABLE IF NOT EXISTS train_entries (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    date DATE NOT NULL,
    time TIME NOT NULL,
    railroad TEXT NOT NULL,
    lead_locomotive TEXT NOT NULL,
    direction TEXT NOT NULL,
    power_consist TEXT NOT NULL,
    train_types TEXT NOT NULL,
    car_counts TEXT NOT NULL,
    location_spot TEXT NOT NULL,
    location_subdivision TEXT,
    location_region TEXT,
    location_coordinates TEXT,
    notes TEXT,
    photographed INTEGER NOT NULL DEFAULT 0,
    videoed INTEGER NOT NULL DEFAULT 0,
    load_status TEXT NOT NULL DEFAULT '',
    trip_name TEXT NOT NULL DEFAULT '',
    trip_date_from TEXT NOT NULL DEFAULT '',
    trip_date_to TEXT NOT NULL DEFAULT '',
    time_zone TEXT NOT NULL DEFAULT '',
    location_state TEXT NOT NULL DEFAULT '',
    train_symbol TEXT NOT NULL DEFAULT '',
    train_number TEXT NOT NULL DEFAULT '',
    train_info TEXT NOT NULL DEFAULT '',
    special_power TEXT NOT NULL DEFAULT '',
    uid TEXT NOT NULL DEFAULT '',
    lead_status TEXT NOT NULL DEFAULT '',
    night INTEGER NOT NULL DEFAULT 0,
    coal_mark TEXT NOT NULL DEFAULT '',
    con_overseas INTEGER NOT NULL DEFAULT 0,
    con_domestic INTEGER NOT NULL DEFAULT 0,
    stopped INTEGER NOT NULL DEFAULT 0,
    in_siding INTEGER NOT NULL DEFAULT 0,
    crew_change INTEGER NOT NULL DEFAULT 0,
    no_crew INTEGER NOT NULL DEFAULT 0,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS sync_sent (
    uid TEXT PRIMARY KEY,
    content_hash TEXT NOT NULL,
    sent_at TIMESTAMP NOT NULL
);

CREATE TABLE IF NOT EXISTS location_history (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    location_spot TEXT NOT NULL,
    location_subdivision TEXT,
    location_region TEXT,
    last_used TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    use_count INTEGER NOT NULL DEFAULT 1,
    UNIQUE (location_spot, location_subdivision, location_region)
);

CREATE TABLE IF NOT EXISTS locomotive_history (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    railroad TEXT NOT NULL,
    lead_locomotive TEXT NOT NULL,
    train_types TEXT,
    car_counts TEXT,
    last_used TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE (railroad, lead_locomotive)
);

CREATE TABLE IF NOT EXISTS pending_imports (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    source TEXT,
    payload TEXT NOT NULL,
    match_entry_id INTEGER,
    reason TEXT,
    status TEXT NOT NULL DEFAULT 'pending',
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (match_entry_id) REFERENCES train_entries(id) ON DELETE SET NULL
);

CREATE TABLE IF NOT EXISTS activity_log (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    action TEXT NOT NULL,
    summary TEXT NOT NULL,
    payload TEXT
);

CREATE TABLE IF NOT EXISTS import_review (
    entry_id INTEGER PRIMARY KEY,
    source TEXT,
    sub_status TEXT NOT NULL DEFAULT '',
    sub_reason TEXT NOT NULL DEFAULT '',
    zone_status TEXT NOT NULL DEFAULT '',
    zone_reason TEXT NOT NULL DEFAULT '',
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (entry_id) REFERENCES train_entries(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS trip_details (
    name_key TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    start_miles TEXT NOT NULL DEFAULT '',
    end_miles TEXT NOT NULL DEFAULT '',
    notes TEXT NOT NULL DEFAULT '',
    attendees TEXT NOT NULL DEFAULT '',
    vehicle TEXT NOT NULL DEFAULT '',
    fuel_log TEXT NOT NULL DEFAULT '',
    temperature TEXT NOT NULL DEFAULT '',
    logging_defaults TEXT NOT NULL DEFAULT '',
    packing TEXT NOT NULL DEFAULT '',
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS app_meta (
    key TEXT PRIMARY KEY,
    value TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_activity_created ON activity_log(created_at);
CREATE INDEX IF NOT EXISTS idx_entries_date ON train_entries(date);
CREATE INDEX IF NOT EXISTS idx_entries_railroad ON train_entries(railroad);
CREATE INDEX IF NOT EXISTS idx_entries_location ON train_entries(location_spot);
CREATE INDEX IF NOT EXISTS idx_entries_loco ON train_entries(lead_locomotive);
CREATE INDEX IF NOT EXISTS idx_pending_status ON pending_imports(status);
"""

CSV_FIELDS = [
    "date",
    "time",
    "railroad",
    "lead_locomotive",
    "direction",
    "power_consist",
    "train_types",
    "load_status",
    "car_counts",
    "location_spot",
    "subdivision",
    "state",
    "location_region",
    "location_coordinates",
    "symbol",
    "train_number",
    "train_info",
    "special_power",
    "notes",
    "photographed",
    "videoed",
    "trip_name",
    "trip_date_from",
    "trip_date_to",
    "time_zone",
    "lead_status",
    "night",
    "stopped",
    "in_siding",
    "crew_change",
    "no_crew",
    "coal_mark",
    "con_overseas",
    "con_domestic",
    "uid",
]

HEADER_ALIASES = {
    "date": "date",
    "date trackside": "date",
    "sighting date": "date",
    "time": "time",
    "time zone": "time_zone",
    "time_zone": "time_zone",
    "timezone": "time_zone",
    "tz": "time_zone",
    "railroad": "railroad",
    "rr": "railroad",
    "road": "railroad",
    "lead_locomotive": "lead_locomotive",
    "lead locomotive": "lead_locomotive",
    "lead loco": "lead_locomotive",
    "lead": "lead_locomotive",
    "loco": "lead_locomotive",
    "lead_loco": "lead_locomotive",
    "direction": "direction",
    "dir": "direction",
    "power_consist": "power_consist",
    "consist": "power_consist",
    "power": "power_consist",
    "train_types": "train_types",
    "train type": "train_types",
    "train types": "train_types",
    "type": "train_types",
    "types": "train_types",
    "load_status": "load_status",
    "load status": "load_status",
    "loads or empties": "load_status",
    "loads": "load_status",
    "empties": "load_status",
    "loaded": "load_status",
    "empty": "load_status",
    "load": "load_status",
    "car_counts": "car_counts",
    "cars": "car_counts",
    "car counts": "car_counts",
    "location_spot": "location_spot",
    "location": "location_spot",
    "spot": "location_spot",
    "location_subdivision": "location_subdivision",
    "subdivision": "location_subdivision",
    "sub": "location_subdivision",
    "location_state": "location_state",
    "state": "location_state",
    "location_region": "location_region",
    "region": "location_region",
    "location_coordinates": "location_coordinates",
    "coordinates": "location_coordinates",
    "train_symbol": "train_symbol",
    "train symbol": "train_symbol",
    "symbol": "train_symbol",
    "train_number": "train_number",
    "train number": "train_number",
    "train #": "train_number",
    "train no": "train_number",
    "train_info": "train_info",
    "train info": "train_info",
    "symbol info": "train_info",
    "special_power": "special_power",
    "special power": "special_power",
    "notes": "notes",
    "note": "notes",
    "remarks": "notes",
    "photographed": "photographed",
    "photo": "photographed",
    "videoed": "videoed",
    "video": "videoed",
    "media": "media",
    "trip_name": "trip_name",
    "trip": "trip_name",
    "trip name": "trip_name",
    "outing": "trip_name",
    "trip_date_from": "trip_date_from",
    "trip from": "trip_date_from",
    "trip_from": "trip_date_from",
    "trip_date_to": "trip_date_to",
    "trip to": "trip_date_to",
    "trip_to": "trip_date_to",
    "lead_status": "lead_status",
    "lead status": "lead_status",
    "night": "night",
    "nighttime": "night",
    "stopped": "stopped",
    "in_siding": "in_siding",
    "in siding": "in_siding",
    "crew_change": "crew_change",
    "crew change": "crew_change",
    "no_crew": "no_crew",
    "no crew": "no_crew",
    "no crew onboard": "no_crew",
    "coal_mark": "coal_mark",
    "coal mark": "coal_mark",
    "con_overseas": "con_overseas",
    "con overseas": "con_overseas",
    "con_domestic": "con_domestic",
    "con domestic": "con_domestic",
    "uid": "uid",
}


UPGRADE_BACKUPS_KEPT = 5


def upgrade_backups_dir() -> Path:
    from paths import support_dir

    return support_dir() / "backups"


def _stored_app_version(path: Path) -> Optional[str]:
    """The TRAIN LOG version that last opened this log, "" if older than 1.0.4, None if unreadable."""
    try:
        conn = sqlite3.connect(path.resolve().as_uri() + "?mode=ro", uri=True)
    except sqlite3.Error:
        return None
    try:
        conn.execute("SELECT count(*) FROM sqlite_master").fetchone()
    except sqlite3.Error:
        conn.close()
        return None
    try:
        row = conn.execute("SELECT value FROM app_meta WHERE key = 'app_version'").fetchone()
        return str(row[0]) if row else ""
    except sqlite3.Error:
        return ""
    finally:
        conn.close()


def backup_before_upgrade(path: Path) -> Optional[Path]:
    """Copy the log aside the first time a different TRAIN LOG version opens it, before anything changes."""
    from version import APP_VERSION

    import os

    # A test log opened with only TRAINS_DB set must not be copied into the real Application Support.
    if os.environ.get("TRAINS_DB") and not os.environ.get("TRAINS_SUPPORT_DIR"):
        return None
    path = Path(path)
    if not path.is_file() or path.stat().st_size == 0:
        return None
    stored = _stored_app_version(path)
    if stored is None or stored == APP_VERSION:
        return None
    folder = upgrade_backups_dir()
    folder.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now().strftime("%Y%m%d-%H%M%S")
    dest = folder / "{}-before-{}-{}.db".format(path.stem, APP_VERSION, stamp)
    source = sqlite3.connect(path.resolve().as_uri() + "?mode=ro", uri=True)
    out = sqlite3.connect(str(dest))
    try:
        source.backup(out)
        out.commit()
    finally:
        out.close()
        source.close()
    previous = sorted(folder.glob("{}-before-*.db".format(path.stem)), key=lambda p: p.stat().st_mtime, reverse=True)
    for old in previous[UPGRADE_BACKUPS_KEPT:]:
        try:
            old.unlink()
        except OSError:
            pass
    return dest


def default_db_path() -> Path:
    override = Path(__import__("os").environ.get("TRAINS_DB", "")).expanduser() if __import__("os").environ.get("TRAINS_DB") else None
    if override:
        override.parent.mkdir(parents=True, exist_ok=True)
        return override
    from paths import support_dir

    return support_dir() / "trains.db"


def _now() -> str:
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")


def _entry_from_row(row: Any) -> TrainEntry:
    entry = TrainEntry.from_row(row)
    entry.power_consist = normalize_consist(entry.power_consist)
    return entry


_NEW_FIELDS = {name for name, _kind in NEW_COLUMNS}
_HASH_SKIP = {"id", "uid", "created_at", "updated_at", "train_types_label", "content_hash", "changed"}


def _same_sighting(a: Dict[str, Any], b: Dict[str, Any]) -> bool:
    skip = {"force", "row", "uid"}
    return {k: v for k, v in a.items() if k not in skip} == {k: v for k, v in b.items() if k not in skip}


def content_hash(entry: Dict[str, Any]) -> str:
    """Fingerprint of what a sighting says, ignoring IDs and timestamps.

    Fields added after a log was made only count once they're set, so an
    upgrade doesn't make every sighting look changed to Phone Sync."""
    body = {
        k: v for k, v in entry.items()
        if k not in _HASH_SKIP and not (k in _NEW_FIELDS and not v)
    }
    return hashlib.sha256(json.dumps(body, sort_keys=True, ensure_ascii=False, default=str).encode()).hexdigest()[:24]


MILES_RE = re.compile(r"^\d{1,7}(?:\.\d)?$")
FUEL_GALLONS_RE = re.compile(r"^\d{1,4}(?:\.\d{1,3})?$")
TEMP_RE = re.compile(r"^-?\d{1,3}(?:\.\d)?$")
FUEL_COST_RE = re.compile(r"^\d{1,5}(?:\.\d{1,2})?$")


def trip_key(name: str) -> str:
    return (name or "").strip().lower()


def split_attendees(text: Any) -> List[str]:
    found: List[str] = []
    for part in re.split(r"\s*[,;\n]\s*", str(text or "")):
        part = re.sub(r"\s+", " ", part).strip()
        if part and part.lower() not in [name.lower() for name in found]:
            found.append(part)
    return found


def join_attendees(names: List[str]) -> str:
    return ", ".join(split_attendees(", ".join(names)))


def clean_fuel_log(raw: Any) -> List[Dict[str, str]]:
    """Fill-ups for one trip. Each kept line has gallons, a cost, or both, plus optional place, time, and outside temperature."""
    if isinstance(raw, str):
        text = raw.strip()
        if not text:
            return []
        try:
            raw = json.loads(text)
        except ValueError:
            raise ValidationError("The fuel log could not be read", "fuel_log")
    if raw is None:
        return []
    if not isinstance(raw, list):
        raise ValidationError("The fuel log is a list of fill-ups", "fuel_log")
    if len(raw) > 40:
        raise ValidationError("A trip can hold 40 fill-ups", "fuel_log")
    kept: List[Dict[str, str]] = []
    for item in raw:
        if not isinstance(item, dict):
            continue
        day = str(item.get("date") or "").strip()
        when = str(item.get("time") or "").strip()
        gallons = str(item.get("gallons") or "").replace(",", "").strip()
        cost = str(item.get("cost") or "").replace(",", "").replace("$", "").strip()
        place = re.sub(r"\s+", " ", str(item.get("place") or "")).strip()
        temp_text = str(item.get("temperature") or "").strip()
        if not day and not when and not gallons and not cost and not place and not temp_text:
            continue
        if day:
            try:
                date.fromisoformat(day)
            except ValueError:
                raise ValidationError("Fill-up date must be a real date", "fuel_log")
        if when:
            match = re.match(r"^(\d{1,2}):(\d{2})(?::\d{2})?$", when)
            if not match or not (0 <= int(match.group(1)) <= 23) or not (0 <= int(match.group(2)) <= 59):
                raise ValidationError("Fill-up time looks like 15:42", "fuel_log")
            when = "{:02d}:{:02d}".format(int(match.group(1)), int(match.group(2)))
        if gallons and (not FUEL_GALLONS_RE.match(gallons) or float(gallons) <= 0):
            raise ValidationError("Gallons must be a number, like 12.4", "fuel_log")
        if cost and not FUEL_COST_RE.match(cost):
            raise ValidationError("Fuel cost must be a number, like 48.20", "fuel_log")
        if not gallons and not cost and not day:
            raise ValidationError("Each fill-up needs gallons or a cost", "fuel_log")
        if len(place) > 80:
            raise ValidationError("The fill-up place is too long", "fuel_log")
        try:
            temperature = clean_temperature(temp_text)
        except ValidationError as exc:
            raise ValidationError(exc.message, "fuel_log")
        kept.append(
            {
                "date": day,
                "time": when,
                "gallons": gallons,
                "cost": cost,
                "place": place,
                "temperature": temperature,
            }
        )
    return kept


def fuel_metrics(log: Any, miles: Any = None, trains: Any = None) -> Dict[str, Any]:
    """Gallons, cost, and the rates for one fuel log. Trains is how many trains that fuel covered."""
    gallons = 0.0
    cost = 0.0
    for item in log or []:
        if not isinstance(item, dict):
            continue
        if item.get("gallons"):
            gallons += float(item["gallons"])
        if item.get("cost"):
            cost += float(item["cost"])
    driven = None
    try:
        if miles not in (None, ""):
            driven = float(miles)
    except (TypeError, ValueError):
        driven = None
    if driven is not None and driven <= 0:
        driven = None
    count = None
    try:
        if trains not in (None, ""):
            count = int(trains)
    except (TypeError, ValueError):
        count = None
    if count is not None and count <= 0:
        count = None
    return {
        "gallons": round(gallons, 3),
        "cost": round(cost, 2),
        "per_gallon": round(cost / gallons, 3) if gallons and cost else None,
        "mpg": round(driven / gallons, 1) if driven and gallons else None,
        "per_mile": round(cost / driven, 3) if driven and cost else None,
        "per_train": round(cost / count, 2) if count and cost else None,
        "trains_per_gallon": round(count / gallons, 3) if count and gallons else None,
        "trains_per_mile": round(count / driven, 3) if count and driven else None,
    }


def _fuel_log_text(raw: Any) -> List[Dict[str, str]]:
    try:
        return clean_fuel_log(raw)
    except ValidationError:
        return []


def clean_temperature(raw: Any) -> str:
    """Optional outside temperature in Fahrenheit, such as 72 or -5."""
    text = str(raw or "").replace("°", "").replace("º", "").strip()
    text = re.sub(r"\s*[fF]\s*$", "", text).strip()
    if not text:
        return ""
    if not TEMP_RE.match(text):
        raise ValidationError("Outside temperature is a number in °F, like 72", "temperature")
    value = float(text)
    if value < -80 or value > 130:
        raise ValidationError("Outside temperature is a number in °F, like 72", "temperature")
    if text.endswith(".0"):
        text = text[:-2]
    return text


def clean_logging_defaults(raw: Any) -> Dict[str, Any]:
    """Trip pad defaults: railroad + hotspot list (subdivision / location / state).
    Empty dict means no defaults. Does not invent station names."""
    if raw is None or raw == "":
        return {}
    if isinstance(raw, str):
        text = raw.strip()
        if not text:
            return {}
        try:
            data = json.loads(text)
        except json.JSONDecodeError as exc:
            raise ValidationError("Logging defaults could not be read", "logging_defaults") from exc
    elif isinstance(raw, dict):
        data = raw
    else:
        raise ValidationError("Logging defaults could not be read", "logging_defaults")
    railroad = re.sub(r"\s+", " ", str(data.get("railroad") or "")).strip()
    if len(railroad) > 80:
        raise ValidationError("Default railroad is too long", "logging_defaults")
    hotspots_in = data.get("hotspots") or []
    if not isinstance(hotspots_in, list):
        raise ValidationError("Hotspots must be a list", "logging_defaults")
    hotspots = []
    for item in hotspots_in[:24]:
        if not isinstance(item, dict):
            continue
        sub = re.sub(r"\s+", " ", str(item.get("subdivision") or "")).strip()
        loc = re.sub(r"\s+", " ", str(item.get("location") or "")).strip()
        state = re.sub(r"[^A-Za-z]", "", str(item.get("state") or "")).upper()[:2]
        label = re.sub(r"\s+", " ", str(item.get("label") or "")).strip()
        if not sub and not loc:
            continue
        if len(sub) > 120 or len(loc) > 120 or len(label) > 80:
            raise ValidationError("A hotspot name is too long", "logging_defaults")
        row = {"subdivision": sub, "location": loc, "state": state}
        if label:
            row["label"] = label
        hotspots.append(row)
    try:
        active = int(data.get("active") if data.get("active") is not None else 0)
    except (TypeError, ValueError):
        active = 0
    if hotspots:
        active = max(0, min(active, len(hotspots) - 1))
    else:
        active = 0
    if not railroad and not hotspots:
        return {}
    return {"railroad": railroad, "hotspots": hotspots, "active": active}


def logging_defaults_dict(text: Any) -> Dict[str, Any]:
    try:
        return clean_logging_defaults(text)
    except ValidationError:
        return {}


def _logging_defaults_text(raw: Any) -> str:
    data = clean_logging_defaults(raw) if not isinstance(raw, dict) else clean_logging_defaults(raw)
    if not data:
        return ""
    return json.dumps(data, ensure_ascii=False, separators=(",", ":"))


def clean_trip_details(raw: Dict[str, Any]) -> Dict[str, Any]:
    fields: Dict[str, str] = {}
    for key, label in (("start_miles", "Starting mileage"), ("end_miles", "Ending mileage")):
        text = str(raw.get(key) or "").replace(",", "").strip()
        if text and not MILES_RE.match(text):
            raise ValidationError("{} must be a number, like 48210".format(label), key)
        fields[key] = text
    if fields["start_miles"] and fields["end_miles"] and float(fields["end_miles"]) < float(fields["start_miles"]):
        raise ValidationError("Ending mileage is less than starting mileage", "end_miles")
    notes = str(raw.get("notes") or "").strip()
    if len(notes) > 5000:
        raise ValidationError("Trip notes are too long", "notes")
    fields["notes"] = notes
    fields["attendees"] = join_attendees(split_attendees(raw.get("attendees")))
    vehicle = re.sub(r"\s+", " ", str(raw.get("vehicle") or "")).strip()
    if len(vehicle) > 100:
        raise ValidationError("Vehicle is too long", "vehicle")
    fields["vehicle"] = vehicle
    fields["temperature"] = clean_temperature(raw.get("temperature"))
    fields["fuel_log"] = clean_fuel_log(raw.get("fuel_log"))
    fields["logging_defaults"] = clean_logging_defaults(raw.get("logging_defaults"))
    fields["packing"] = clean_packing(raw.get("packing"))
    return fields


def _payload_json(payload: Any) -> Optional[str]:
    if payload is None:
        return None
    return json.dumps(payload, ensure_ascii=False, default=str)


def entry_activity_summary(verb: str, entry: TrainEntry) -> str:
    types = "/".join(entry.train_types or [])
    loc = (entry.location_spot or "").strip()
    sub = (entry.location_subdivision or "").strip()
    if loc and sub:
        where = "{} · {}".format(loc, sub)
    else:
        where = loc or sub
    parts = [verb]
    if entry.railroad:
        parts.append(entry.railroad)
    if types:
        parts.append(types)
    if getattr(entry, "load_status", ""):
        parts.append(entry.load_status)
    if where:
        parts.append("at " + where)
    if entry.date:
        parts.append("on " + str(entry.date))
    return " ".join(parts)


class Database:
    def __init__(self, path: Optional[Path] = None) -> None:
        self._lock = threading.RLock()
        self.path = Path(path) if path else default_db_path()
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.upgrade_backup = self._backup_for_upgrade(self.path)
        self._conn = self._connect(self.path)
        self._note_upgrade_backup()

    def _backup_for_upgrade(self, path: Path) -> Optional[Path]:
        try:
            return backup_before_upgrade(path)
        except (OSError, sqlite3.Error) as exc:
            import sys

            print("Could not save a copy of the log before upgrading: {}".format(exc), file=sys.stderr)
            return None

    def _note_upgrade_backup(self) -> None:
        if not self.upgrade_backup:
            return
        from version import APP_VERSION

        self.log_activity(
            "backup.upgrade",
            "Saved a copy of the log before opening it with TRAIN LOG {}.".format(APP_VERSION),
            {"path": str(self.upgrade_backup)},
        )

    def _connect(self, path: Path) -> sqlite3.Connection:
        conn = sqlite3.connect(str(path), check_same_thread=False, timeout=10)
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA foreign_keys = ON")
        conn.executescript(SCHEMA)
        if _ensure_columns(conn):
            _fill_states(conn)
        _fill_uids(conn)
        conn.execute(
            "UPDATE train_entries SET train_types = replace(train_types, 'ETH/GAS', 'ETH-GAS') "
            "WHERE train_types LIKE '%ETH/GAS%'"
        )
        conn.execute(
            "UPDATE locomotive_history SET train_types = replace(train_types, 'ETH/GAS', 'ETH-GAS') "
            "WHERE train_types LIKE '%ETH/GAS%'"
        )
        _rewrite_canonical_train_types(conn)
        _fill_train_info(conn)
        for row in conn.execute(
            "SELECT id, railroad, lead_locomotive FROM train_entries "
            "WHERE upper(lead_locomotive) LIKE upper(railroad) || ' ' || upper(railroad) || ' %'"
        ).fetchall():
            mark = row["railroad"]
            lead = row["lead_locomotive"]
            prefix = mark.upper() + " "
            while lead.upper().startswith(prefix + prefix):
                lead = lead[len(prefix):]
            conn.execute("UPDATE train_entries SET lead_locomotive = ? WHERE id = ?", (lead, row["id"]))
        from version import APP_VERSION

        conn.execute("INSERT OR REPLACE INTO app_meta (key, value) VALUES ('app_version', ?)", (APP_VERSION,))
        conn.commit()
        return conn

    def reopen(self, path: Path) -> None:
        with self._lock:
            new_path = Path(path).expanduser()
            new_path.parent.mkdir(parents=True, exist_ok=True)
            backup = self._backup_for_upgrade(new_path)
            new_conn = self._connect(new_path)
            old = self._conn
            self._conn = new_conn
            self.path = new_path
            old.close()
            self.upgrade_backup = backup
            self._note_upgrade_backup()

    def close(self) -> None:
        with self._lock:
            self._conn.close()

    def info(self) -> Dict[str, Any]:
        with self._lock:
            count = self._conn.execute("SELECT COUNT(*) FROM train_entries").fetchone()[0]
            pending = self._conn.execute(
                "SELECT COUNT(*) FROM pending_imports WHERE status = 'pending'"
            ).fetchone()[0]
        return {
            "path": str(self.path),
            "entry_count": count,
            "pending_import_count": pending,
            "import_review_count": self.import_review_count(),
            "upgrade_backup": str(self.upgrade_backup) if self.upgrade_backup else "",
        }

    def log_activity(self, action: str, summary: str, payload: Any = None) -> None:
        with self._lock:
            self._conn.execute(
                "INSERT INTO activity_log (created_at, action, summary, payload) VALUES (?, ?, ?, ?)",
                (_now(), action, summary or "", _payload_json(payload)),
            )
            self._conn.commit()

    def list_activity(self, limit: int = 500) -> List[Dict[str, Any]]:
        cap = max(1, min(int(limit or 500), 2000))
        with self._lock:
            rows = self._conn.execute(
                "SELECT id, created_at, action, summary, payload FROM activity_log "
                "ORDER BY id DESC LIMIT ?",
                (cap,),
            ).fetchall()
        items: List[Dict[str, Any]] = []
        for row in rows:
            raw = row["payload"]
            loaded: Any = None
            if raw:
                try:
                    loaded = json.loads(raw)
                except (TypeError, json.JSONDecodeError):
                    loaded = raw
            items.append(
                {
                    "id": row["id"],
                    "created_at": row["created_at"],
                    "action": row["action"],
                    "summary": row["summary"] or "",
                    "payload": loaded,
                }
            )
        return items

    def clear_activity(self) -> int:
        with self._lock:
            count = self._conn.execute("SELECT COUNT(*) FROM activity_log").fetchone()[0]
            self._conn.execute("DELETE FROM activity_log")
            try:
                self._conn.execute("DELETE FROM sqlite_sequence WHERE name = 'activity_log'")
            except sqlite3.OperationalError:
                pass
            self._conn.commit()
        return int(count)

    def create_entry(self, cleaned: Dict[str, Any], *, log: bool = True) -> TrainEntry:
        stamp = _now()
        with self._lock:
            uid = cleaned.get("uid") or ""
            if not uid or self.entry_by_uid(uid) is not None:
                uid = uuid.uuid4().hex
            cursor = self._conn.execute(
                """
                INSERT INTO train_entries (
                    date, time, railroad, lead_locomotive, direction, power_consist,
                    train_types, car_counts, location_spot, location_subdivision,
                    location_region, location_coordinates, notes, photographed, videoed,
                    load_status, trip_name, trip_date_from, trip_date_to, time_zone,
                    location_state, train_symbol, train_number, train_info, special_power,
                    lead_status, night, stopped, in_siding, crew_change, no_crew, coal_mark,
                    con_overseas, con_domestic, uid, created_at, updated_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    cleaned["date"],
                    cleaned["time"],
                    cleaned["railroad"],
                    cleaned["lead_locomotive"],
                    cleaned["direction"],
                    cleaned["power_consist"],
                    types_to_storage(cleaned["train_types"]),
                    cleaned["car_counts"],
                    cleaned["location_spot"],
                    cleaned.get("location_subdivision") or "",
                    cleaned.get("location_region") or DEFAULT_REGION,
                    cleaned.get("location_coordinates"),
                    cleaned.get("notes") or "",
                    1 if cleaned.get("photographed") else 0,
                    1 if cleaned.get("videoed") else 0,
                    cleaned.get("load_status") or "",
                    cleaned.get("trip_name") or "",
                    cleaned.get("trip_date_from") or "",
                    cleaned.get("trip_date_to") or "",
                    cleaned.get("time_zone") or "",
                    cleaned.get("location_state") or "",
                    cleaned.get("train_symbol") or "",
                    cleaned.get("train_number") or "",
                    cleaned.get("train_info") or "",
                    cleaned.get("special_power") or "",
                    cleaned.get("lead_status") or "",
                    1 if cleaned.get("night") else 0,
                    1 if cleaned.get("stopped") else 0,
                    1 if cleaned.get("in_siding") else 0,
                    1 if cleaned.get("crew_change") else 0,
                    1 if cleaned.get("no_crew") else 0,
                    cleaned.get("coal_mark") or "",
                    1 if cleaned.get("con_overseas") else 0,
                    1 if cleaned.get("con_domestic") else 0,
                    uid,
                    stamp,
                    stamp,
                ),
            )
            entry_id = cursor.lastrowid
            self._touch_history(cleaned)
            self._conn.commit()
            entry = self.get_entry(entry_id)
        if log and entry is not None:
            self.log_activity(
                "entry.create",
                entry_activity_summary("Logged", entry),
                entry.to_dict(),
            )
        return entry

    def update_entry(self, entry_id: int, cleaned: Dict[str, Any]) -> Optional[TrainEntry]:
        existing = self.get_entry(entry_id)
        if existing is None:
            return None
        stamp = _now()
        with self._lock:
            self._conn.execute(
                """
                UPDATE train_entries SET
                    date = ?, time = ?, railroad = ?, lead_locomotive = ?,
                    direction = ?, power_consist = ?, train_types = ?, car_counts = ?,
                    location_spot = ?, location_subdivision = ?, location_region = ?,
                    location_coordinates = ?, notes = ?, photographed = ?, videoed = ?,
                    load_status = ?, trip_name = ?, trip_date_from = ?, trip_date_to = ?,
                    time_zone = ?, location_state = ?, train_symbol = ?, train_number = ?,
                    train_info = ?, special_power = ?, lead_status = ?, night = ?,
                    stopped = ?, in_siding = ?, crew_change = ?, no_crew = ?, coal_mark = ?,
                    con_overseas = ?, con_domestic = ?, updated_at = ?
                WHERE id = ?
                """,
                (
                    cleaned["date"],
                    cleaned["time"],
                    cleaned["railroad"],
                    cleaned["lead_locomotive"],
                    cleaned["direction"],
                    cleaned["power_consist"],
                    types_to_storage(cleaned["train_types"]),
                    cleaned["car_counts"],
                    cleaned["location_spot"],
                    cleaned.get("location_subdivision") or "",
                    cleaned.get("location_region") or DEFAULT_REGION,
                    cleaned.get("location_coordinates"),
                    cleaned.get("notes") or "",
                    1 if cleaned.get("photographed") else 0,
                    1 if cleaned.get("videoed") else 0,
                    cleaned.get("load_status") or "",
                    cleaned.get("trip_name") or "",
                    cleaned.get("trip_date_from") or "",
                    cleaned.get("trip_date_to") or "",
                    cleaned.get("time_zone") or "",
                    cleaned.get("location_state") or "",
                    cleaned.get("train_symbol") or "",
                    cleaned.get("train_number") or "",
                    cleaned.get("train_info") or "",
                    cleaned.get("special_power") or "",
                    cleaned.get("lead_status") or "",
                    1 if cleaned.get("night") else 0,
                    1 if cleaned.get("stopped") else 0,
                    1 if cleaned.get("in_siding") else 0,
                    1 if cleaned.get("crew_change") else 0,
                    1 if cleaned.get("no_crew") else 0,
                    cleaned.get("coal_mark") or "",
                    1 if cleaned.get("con_overseas") else 0,
                    1 if cleaned.get("con_domestic") else 0,
                    stamp,
                    entry_id,
                ),
            )
            self._touch_history(cleaned)
            self._settle_review(
                [entry_id],
                sub=(cleaned.get("location_subdivision") or "") != (existing.location_subdivision or ""),
                zone=(cleaned.get("time_zone") or "") != (existing.time_zone or ""),
            )
            self._conn.commit()
        entry = self.get_entry(entry_id)
        if entry is not None:
            self.log_activity(
                "entry.update",
                entry_activity_summary("Edited", entry),
                {"before": existing.to_dict(), "after": entry.to_dict()},
            )
        return entry

    def delete_entry(self, entry_id: int) -> bool:
        existing = self.get_entry(entry_id)
        with self._lock:
            cursor = self._conn.execute("DELETE FROM train_entries WHERE id = ?", (entry_id,))
            self._conn.commit()
            removed = cursor.rowcount > 0
        if removed and existing is not None:
            self.log_activity(
                "entry.delete",
                entry_activity_summary("Deleted", existing),
                existing.to_dict(),
            )
        return removed

    def delete_entries(self, entry_ids: Iterable[int]) -> int:
        snapshot = self.entries_by_ids(entry_ids)
        ids = sorted(snapshot)
        if not ids:
            return 0
        marks = ",".join("?" * len(ids))
        with self._lock:
            cursor = self._conn.execute("DELETE FROM train_entries WHERE id IN ({})".format(marks), ids)
            self._conn.commit()
            removed = cursor.rowcount
        self.log_activity(
            "entry.delete_selected",
            "Deleted {} selected sighting{}.".format(removed, "" if removed == 1 else "s"),
            {"count": removed, "ids": ids, "entries": [snapshot[i] for i in ids]},
        )
        return removed

    def trip_member_ids(self, name: str) -> List[int]:
        name = (name or "").strip()
        if not name:
            return []
        with self._lock:
            rows = self._conn.execute(
                "SELECT id FROM train_entries WHERE lower(trim(trip_name)) = lower(?)", (name,)
            ).fetchall()
        return [row["id"] for row in rows]

    def set_trip(self, entry_ids: Iterable[int], name: str) -> Tuple[str, str, str]:
        """Put many sightings in one trip, or take them out of their trip when
        the name is empty. A name matching an existing trip in any letter case
        joins that trip, and its dates stretch to cover every selected day;
        the rest of that trip gets the same dates. Returns (name, from, to)."""
        ids = sorted({int(item) for item in entry_ids})
        name = (name or "").strip()
        if not ids:
            return name, "", ""
        marks = ",".join("?" * len(ids))
        stamp = _now()
        with self._lock:
            if not name:
                self._conn.execute(
                    "UPDATE train_entries SET trip_name = '', trip_date_from = '', trip_date_to = '', updated_at = ? "
                    "WHERE id IN ({}) AND (trip_name != '' OR trip_date_from != '' OR trip_date_to != '')".format(marks),
                    [stamp] + ids,
                )
                self._conn.commit()
                return "", "", ""
            picked = self._conn.execute(
                "SELECT date FROM train_entries WHERE id IN ({})".format(marks), ids
            ).fetchall()
            members = self._conn.execute(
                "SELECT id, trip_name, trip_date_from, trip_date_to, date FROM train_entries "
                "WHERE lower(trim(trip_name)) = lower(?) ORDER BY date DESC, id DESC",
                (name,),
            ).fetchall()
            if members:
                name = members[0]["trip_name"].strip()
            dates = [row["date"] for row in picked if row["date"]]
            for row in members:
                dates.extend(value for value in (row["date"], row["trip_date_from"], row["trip_date_to"]) if value)
            start, end = (min(dates), max(dates)) if dates else ("", "")
            self._conn.execute(
                "UPDATE train_entries SET trip_name = ?, trip_date_from = ?, trip_date_to = ?, updated_at = ? "
                "WHERE id IN ({}) AND NOT (trip_name = ? AND trip_date_from = ? AND trip_date_to = ?)".format(marks),
                [name, start, end, stamp] + ids + [name, start, end],
            )
            chosen = set(ids)
            others = [row["id"] for row in members if row["id"] not in chosen]
            if others:
                other_marks = ",".join("?" * len(others))
                self._conn.execute(
                    "UPDATE train_entries SET trip_date_from = ?, trip_date_to = ?, updated_at = ? "
                    "WHERE id IN ({}) AND NOT (trip_date_from = ? AND trip_date_to = ?)".format(other_marks),
                    [start, end, stamp] + others + [start, end],
                )
            self._conn.commit()
        return name, start, end

    def rename_trip(self, old: str, new: str) -> Tuple[str, str, str, List[int]]:
        """Give a trip a new name on every train in it, letter case included. A name
        that matches another trip joins the two, with dates covering both, and the
        trip details are combined so no notes, attendees, or mileage are lost.
        Returns (name, from, to, ids of the trains whose trip changed)."""
        old = (old or "").strip()
        new = re.sub(r"\s+", " ", new or "").strip()
        if not old:
            raise ValidationError("Pick a trip to rename", "from")
        if not new:
            raise ValidationError("Type the new trip name", "to")
        if len(new) > 120:
            raise ValidationError("Trip name is too long", "to")
        if new == old:
            raise ValidationError("The new name is the same as the old one", "to")
        details = self.trip_details()
        old_details = details.get(trip_key(old))
        with self._lock:
            rows = self._conn.execute(
                "SELECT id, date, trip_date_from, trip_date_to FROM train_entries "
                "WHERE trim(trip_name) = ? OR lower(trim(trip_name)) IN (lower(?), lower(?))",
                (old, old, new),
            ).fetchall()
        mine = list(rows)
        if not mine and old_details is None:
            raise ValidationError("No trip is named {}".format(old), "from")
        ids = sorted(row["id"] for row in mine)
        days = [d for row in mine for d in (row["date"], row["trip_date_from"], row["trip_date_to"]) if d]
        start, end = (min(days), max(days)) if days else ("", "")
        stamp = _now()
        with self._lock:
            if ids:
                marks = ",".join("?" * len(ids))
                self._conn.execute(
                    "UPDATE train_entries SET trip_name = ?, trip_date_from = ?, trip_date_to = ?, updated_at = ? "
                    "WHERE id IN ({}) AND NOT (trip_name = ? AND trip_date_from = ? AND trip_date_to = ?)".format(marks),
                    [new, start, end, stamp] + ids + [new, start, end],
                )
            if old_details is not None:
                fields = {k: old_details[k] for k in self.TRIP_DETAIL_FIELDS}
                target = details.get(trip_key(new)) if trip_key(new) != trip_key(old) else None
                if target is not None:
                    fields = self._join_trip_details(target, fields)
                if trip_key(new) != trip_key(old):
                    self._conn.execute("DELETE FROM trip_details WHERE name_key = ?", (trip_key(old),))
                self._write_trip_details(new, fields, stamp)
            elif details.get(trip_key(new)) is not None:
                target = details[trip_key(new)]
                self._write_trip_details(new, {k: target[k] for k in self.TRIP_DETAIL_FIELDS}, stamp)
            self._conn.commit()
        return new, start, end, ids

    def _join_trip_details(self, keep: Dict[str, str], extra: Dict[str, str]) -> Dict[str, str]:
        """Two trips' details as one: blanks filled, attendees combined, both notes kept."""
        out = {}
        for key in ("start_miles", "end_miles", "vehicle", "temperature"):
            out[key] = keep.get(key) or extra.get(key) or ""
        keep_fuel = keep.get("fuel_log") or []
        extra_fuel = extra.get("fuel_log") or []
        if keep_fuel and extra_fuel and keep_fuel != extra_fuel:
            out["fuel_log"] = list(keep_fuel) + [row for row in extra_fuel if row not in keep_fuel]
        else:
            out["fuel_log"] = keep_fuel or extra_fuel
        keep_def = keep.get("logging_defaults") or {}
        extra_def = extra.get("logging_defaults") or {}
        out["logging_defaults"] = keep_def if keep_def else extra_def
        keep_pack = keep.get("packing") or []
        extra_pack = extra.get("packing") or []
        out["packing"] = keep_pack if keep_pack else extra_pack
        ours, theirs = keep["notes"], extra["notes"]
        if not theirs or theirs in ours:
            out["notes"] = ours
        elif not ours or ours in theirs:
            out["notes"] = theirs
        else:
            out["notes"] = ours + "\n\n" + theirs
        out["attendees"] = join_attendees(split_attendees(keep["attendees"]) + split_attendees(extra["attendees"]))
        return out

    FIXABLE_COLUMNS = (
        "lead_locomotive", "power_consist", "car_counts", "train_types", "railroad", "train_symbol",
        "train_number", "train_info", "location_spot", "location_subdivision", "location_state",
        "special_power",
    )

    def set_fields(self, updates: Dict[int, Dict[str, Any]]) -> int:
        """Write a few columns on many sightings at once. Only columns in
        FIXABLE_COLUMNS can be set; notes are never touched."""
        stamp = _now()
        changed = 0
        with self._lock:
            for entry_id, fields in updates.items():
                cols = [key for key in fields if key in self.FIXABLE_COLUMNS]
                if not cols:
                    continue
                cursor = self._conn.execute(
                    "UPDATE train_entries SET {}, updated_at = ? WHERE id = ?".format(
                        ", ".join("{} = ?".format(key) for key in cols)
                    ),
                    [fields[key] for key in cols] + [stamp, int(entry_id)],
                )
                changed += cursor.rowcount
            self._conn.commit()
        return changed

    def set_time_zone(self, entry_ids: Iterable[int], time_zone: str, *, log: bool = True) -> int:
        ids = sorted({int(item) for item in entry_ids})
        if not ids:
            return 0
        marks = ",".join("?" * len(ids))
        with self._lock:
            cursor = self._conn.execute(
                "UPDATE train_entries SET time_zone = ?, updated_at = ? WHERE id IN ({})".format(marks),
                [time_zone, _now()] + ids,
            )
            changed = cursor.rowcount
            self._settle_review(ids, zone=True)
            self._conn.commit()
        if not log:
            return changed
        self.log_activity(
            "entry.time_zone",
            "Set time zone {} on {} sighting{}.".format(
                time_zone or "(none)", changed, "" if changed == 1 else "s"
            ),
            {"ids": ids, "time_zone": time_zone},
        )
        return changed

    def set_place(
        self,
        entry_ids: Iterable[int],
        *,
        subdivision: Optional[str] = None,
        state: Optional[str] = None,
        log: bool = True,
    ) -> int:
        """Set subdivision and/or state on many sightings. A new subdivision
        also picks up each location's milepost and state from the station
        book unless a state is given too."""
        from stations import station_state, with_milepost

        ids = sorted({int(item) for item in entry_ids})
        if not ids or (subdivision is None and state is None):
            return 0
        marks = ",".join("?" * len(ids))
        stamp = _now()
        with self._lock:
            rows = self._conn.execute(
                "SELECT id, railroad, location_spot, location_subdivision, location_state FROM train_entries "
                "WHERE id IN ({})".format(marks),
                ids,
            ).fetchall()
            for row in rows:
                spot = row["location_spot"] or ""
                sub = row["location_subdivision"] or ""
                new_state = row["location_state"] or ""
                if subdivision is not None:
                    sub = subdivision
                    spot = with_milepost(spot, row["railroad"] or "", sub) or spot
                    if state is None:
                        new_state = station_state(spot, row["railroad"] or "", sub) or new_state
                if state is not None:
                    new_state = state
                self._conn.execute(
                    "UPDATE train_entries SET location_subdivision = ?, location_spot = ?, location_state = ?, "
                    "updated_at = ? WHERE id = ?",
                    (sub, spot, new_state, stamp, row["id"]),
                )
            if subdivision is not None:
                self._settle_review(ids, sub=True)
            self._conn.commit()
        if not log:
            return len(rows)
        parts = []
        if subdivision is not None:
            parts.append("subdivision {}".format(subdivision or "(none)"))
        if state is not None:
            parts.append("state {}".format(state or "(none)"))
        self.log_activity(
            "entry.place",
            "Set {} on {} sighting{}.".format(" and ".join(parts), len(rows), "" if len(rows) == 1 else "s"),
            {"ids": ids, "subdivision": subdivision, "state": state},
        )
        return len(rows)

    def set_time_zone_from_state(self, entry_ids: Iterable[int], *, log: bool = True) -> Tuple[int, int]:
        """Set each sighting's zone from its state. States split between two
        zones, and sightings with no state, are left alone. Returns
        (changed, left alone)."""
        from states import SPLIT_STATES, STATE_ZONES

        ids = sorted({int(item) for item in entry_ids})
        if not ids:
            return 0, 0
        marks = ",".join("?" * len(ids))
        changed: List[int] = []
        skipped = 0
        stamp = _now()
        with self._lock:
            rows = self._conn.execute(
                "SELECT id, location_state, time_zone FROM train_entries WHERE id IN ({})".format(marks), ids
            ).fetchall()
            for row in rows:
                state = row["location_state"] or ""
                zone = "" if state in SPLIT_STATES else STATE_ZONES.get(state, "")
                if not zone:
                    skipped += 1
                    continue
                if zone == (row["time_zone"] or ""):
                    continue
                self._conn.execute(
                    "UPDATE train_entries SET time_zone = ?, updated_at = ? WHERE id = ?", (zone, stamp, row["id"])
                )
                changed.append(row["id"])
            self._settle_review(ids, zone=True)
            self._conn.commit()
        if not log:
            return len(changed), skipped
        self.log_activity(
            "entry.time_zone",
            "Matched the time zone to the state on {} sighting{}.".format(len(changed), "" if len(changed) == 1 else "s"),
            {"ids": changed, "time_zone": "from state", "left_alone": skipped},
        )
        return len(changed), skipped

    def delete_all_entries(self) -> int:
        snapshot = [item.to_dict() for item in self.list_entries()]
        trips = list(self.trip_details().values())
        with self._lock:
            count = self._conn.execute("SELECT COUNT(*) FROM train_entries").fetchone()[0]
            self._conn.execute("DELETE FROM train_entries")
            self._conn.execute("DELETE FROM trip_details")
            self._conn.execute("DELETE FROM location_history")
            self._conn.execute("DELETE FROM locomotive_history")
            self._conn.execute("DELETE FROM pending_imports")
            self._conn.execute("DELETE FROM import_review")
            try:
                self._conn.execute(
                    "DELETE FROM sqlite_sequence WHERE name IN "
                    "('train_entries', 'location_history', 'locomotive_history', 'pending_imports')"
                )
            except sqlite3.OperationalError:
                pass
            self._conn.commit()
            self._conn.execute("VACUUM")
        self.log_activity(
            "entry.clear",
            "Deleted all {} sightings.".format(int(count)),
            {"count": int(count), "entries": snapshot, "trip_details": trips},
        )
        return int(count)

    def entries_by_ids(self, entry_ids: Iterable[int]) -> Dict[int, Dict[str, Any]]:
        ids = sorted({int(item) for item in entry_ids})
        if not ids:
            return {}
        marks = ",".join("?" * len(ids))
        with self._lock:
            rows = self._conn.execute(
                "SELECT * FROM train_entries WHERE id IN ({})".format(marks), ids
            ).fetchall()
        return {int(row["id"]): _entry_from_row(row).to_dict() for row in rows}

    def get_entry(self, entry_id: int) -> Optional[TrainEntry]:
        with self._lock:
            row = self._conn.execute(
                "SELECT * FROM train_entries WHERE id = ?", (entry_id,)
            ).fetchone()
        return _entry_from_row(row) if row else None

    def entry_by_uid(self, uid: str) -> Optional[TrainEntry]:
        if not uid:
            return None
        with self._lock:
            row = self._conn.execute("SELECT * FROM train_entries WHERE uid = ?", (uid,)).fetchone()
        return _entry_from_row(row) if row else None

    def sync_outbox(self) -> List[Dict[str, Any]]:
        """Sightings not yet sent to the Mac, or changed since they were sent, oldest first."""
        with self._lock:
            sent = {
                row["uid"]: row["content_hash"]
                for row in self._conn.execute("SELECT uid, content_hash FROM sync_sent").fetchall()
            }
        out = []
        for entry in reversed(self.list_entries()):
            item = entry.to_dict()
            digest = content_hash(item)
            if sent.get(item["uid"]) != digest:
                item["content_hash"] = digest
                item["changed"] = item["uid"] in sent
                out.append(item)
        return out

    def mark_synced(self, items: Iterable[Dict[str, Any]]) -> int:
        stamp = _now()
        count = 0
        with self._lock:
            for item in items:
                uid = str(item.get("uid") or "")
                digest = str(item.get("content_hash") or "")
                if uid and digest:
                    self._conn.execute(
                        "INSERT OR REPLACE INTO sync_sent (uid, content_hash, sent_at) VALUES (?, ?, ?)",
                        (uid, digest, stamp),
                    )
                    count += 1
            self._conn.commit()
        return count

    def clear_sync_sent(self) -> int:
        """Forget what this device already sent, so the next sync sends the whole log again."""
        with self._lock:
            count = self._conn.execute("SELECT COUNT(*) FROM sync_sent").fetchone()[0]
            self._conn.execute("DELETE FROM sync_sent")
            self._conn.commit()
        return int(count)

    def write_log_snapshot(self) -> str:
        """Keep the last few JSON copies of this device's log in its own storage."""
        import json

        from paths import support_dir

        rows = self.export_rows()
        if not rows:
            return ""
        folder = support_dir() / "log-snapshots"
        folder.mkdir(parents=True, exist_ok=True)
        stamp = datetime.now().strftime("%Y%m%d-%H%M%S")
        name = "log-{}.json".format(stamp)
        path = folder / name
        path.write_text(json.dumps(rows, ensure_ascii=False), encoding="utf-8")
        try:
            from durability import prune_log_snapshots

            prune_log_snapshots()
        except Exception:
            older = sorted(folder.glob("log-*.json"))
            for stale in older[:-5]:
                try:
                    stale.unlink()
                except OSError:
                    pass
        return name

    def log_snapshots(self) -> List[Dict[str, Any]]:
        from paths import support_dir

        folder = support_dir() / "log-snapshots"
        if not folder.is_dir():
            return []
        found = []
        for path in sorted(folder.glob("log-*.json"), reverse=True):
            found.append({"name": path.name, "bytes": path.stat().st_size, "saved": datetime.fromtimestamp(path.stat().st_mtime).strftime("%Y-%m-%d %H:%M")})
        return found[:5]

    def restore_log_snapshot(self, name: str) -> Dict[str, Any]:
        import json
        import re

        from paths import support_dir

        if not re.fullmatch(r"log-\d{8}-\d{6}\.json", name or ""):
            raise ValidationError("That backup isn't one of this device's copies", "name")
        path = support_dir() / "log-snapshots" / name
        if not path.is_file():
            raise ValidationError("That backup is no longer on this device", "name")
        try:
            rows = json.loads(path.read_text(encoding="utf-8"))
        except (OSError, ValueError) as exc:
            raise ValidationError("That backup could not be read", "name") from exc
        if not isinstance(rows, list):
            raise ValidationError("That backup is not a train log", "name")
        return self.import_records(rows, source="Log copy: " + name)

    def list_entries(self, filters: Optional[Dict[str, Any]] = None) -> List[TrainEntry]:
        filters = filters or {}
        clauses = ["1=1"]
        params: List[Any] = []
        if filters.get("ids") is not None:
            ids = sorted({int(item) for item in filters["ids"]})
            clauses.append("id IN ({})".format(",".join("?" * len(ids))) if ids else "0")
            params.extend(ids)
        if filters.get("date"):
            clauses.append("date = ?")
            params.append(filters["date"])
        if filters.get("date_from"):
            clauses.append("date >= ?")
            params.append(filters["date_from"])
        if filters.get("date_to"):
            clauses.append("date <= ?")
            params.append(filters["date_to"])
        if filters.get("railroad"):
            clauses.append("railroad = ?")
            params.append(filters["railroad"])
        if filters.get("direction") in ("Stopped", "In Siding", "Crew Change", "No Crew Onboard"):
            clauses.append({
                "Stopped": "stopped = 1",
                "In Siding": "in_siding = 1",
                "Crew Change": "crew_change = 1",
                "No Crew Onboard": "no_crew = 1",
            }[filters["direction"]])
        elif filters.get("direction"):
            from models import DIRECTION_ALIASES, DIRECTIONS

            raw_dir = filters["direction"]
            canonical = DIRECTION_ALIASES.get(str(raw_dir).upper(), raw_dir)
            aliases = {canonical, str(raw_dir), str(raw_dir).upper()[:1]}
            if canonical == "North":
                aliases.add("N")
            elif canonical == "South":
                aliases.add("S")
            elif canonical == "East":
                aliases.add("E")
            elif canonical == "West":
                aliases.add("W")
            aliases = [item for item in aliases if item]
            clauses.append("direction IN ({})".format(",".join("?" * len(aliases))))
            params.extend(aliases)
        if filters.get("location_spot"):
            clauses.append("location_spot LIKE ?")
            params.append("%{}%".format(filters["location_spot"]))
        if filters.get("train_types"):
            clauses.append("upper(train_types) LIKE ?")
            params.append("%{}%".format(filters["train_types"].upper()))
        if filters.get("lead_locomotive"):
            clauses.append("lead_locomotive LIKE ?")
            params.append("%{}%".format(filters["lead_locomotive"]))
        if filters.get("load_status"):
            wanted = filters["load_status"]
            clauses.append("(load_status = ? OR load_status LIKE ? OR load_status LIKE ?)")
            params.extend([wanted, wanted + "/%", "%/" + wanted])
        if filters.get("trip_name"):
            clauses.append("lower(trim(trip_name)) = lower(trim(?))")
            params.append(filters["trip_name"])
        for key in ("train_symbol", "power_consist", "car_counts", "location_subdivision"):
            if filters.get(key):
                clauses.append("{} LIKE ?".format(key))
                params.append("%{}%".format(filters[key]))
        if filters.get("location_state"):
            clauses.append("upper(location_state) = upper(?)")
            params.append(filters["location_state"])
        if filters.get("time_zone"):
            clauses.append("time_zone = ?")
            params.append(filters["time_zone"])
        if filters.get("notes"):
            clauses.append(
                "(notes LIKE ? OR train_info LIKE ? OR "
                "(CASE WHEN json_valid(special_power) THEN json_remove(special_power, '$.units') ELSE special_power END) LIKE ?)"
            )
            params.extend(["%{}%".format(filters["notes"])] * 3)
        media = filters.get("media")
        if media == "photo":
            clauses.append("photographed = 1")
        elif media == "video":
            clauses.append("videoed = 1")
        elif media == "any":
            clauses.append("(photographed = 1 OR videoed = 1)")
        elif media == "none":
            clauses.append("photographed = 0 AND videoed = 0")
        elif media == "night":
            clauses.append("night = 1")
        sql = (
            "SELECT * FROM train_entries WHERE "
            + " AND ".join(clauses)
            + " ORDER BY date DESC, id DESC"
        )
        with self._lock:
            rows = self._conn.execute(sql, params).fetchall()
        return [_entry_from_row(row) for row in rows]

    def list_trips(self) -> List[Dict[str, str]]:
        with self._lock:
            rows = self._conn.execute(
                """
                SELECT trip_name, trip_date_from, trip_date_to, date
                FROM train_entries
                WHERE trip_name IS NOT NULL AND trim(trip_name) != ''
                ORDER BY date DESC, id DESC
                """
            ).fetchall()
        seen = []
        found = set()
        for row in rows:
            name = row["trip_name"]
            if not name or name in found:
                continue
            found.add(name)
            seen.append(
                {
                    "name": name,
                    "trip_date_from": row["trip_date_from"] or "",
                    "trip_date_to": row["trip_date_to"] or "",
                    "latest": row["date"] or "",
                }
            )
        seen.sort(key=lambda item: item["name"].lower())
        return seen

    def trip_counts(self) -> Dict[str, int]:
        """Trains in each trip, by the exact trip name."""
        with self._lock:
            rows = self._conn.execute(
                "SELECT trip_name, COUNT(*) AS n FROM train_entries WHERE trim(trip_name) != '' GROUP BY trip_name"
            ).fetchall()
        return {row["trip_name"]: row["n"] for row in rows}

    TRIP_DETAIL_FIELDS = ("start_miles", "end_miles", "notes", "attendees", "vehicle", "temperature", "fuel_log", "logging_defaults", "packing")

    def trip_details(self) -> Dict[str, Dict[str, Any]]:
        """Mileage, vehicle, fuel, notes, and attendees for each trip, keyed by the trip name in lower case."""
        with self._lock:
            rows = self._conn.execute("SELECT * FROM trip_details").fetchall()
        return {
            row["name_key"]: {
                "name": row["name"],
                "start_miles": row["start_miles"],
                "end_miles": row["end_miles"],
                "notes": row["notes"],
                "attendees": row["attendees"],
                "vehicle": row["vehicle"],
                "temperature": row["temperature"] if "temperature" in row.keys() else "",
                "fuel_log": _fuel_log_text(row["fuel_log"] if "fuel_log" in row.keys() else ""),
                "logging_defaults": logging_defaults_dict(row["logging_defaults"] if "logging_defaults" in row.keys() else ""),
                "packing": packing_list(row["packing"] if "packing" in row.keys() else ""),
                "updated_at": row["updated_at"],
            }
            for row in rows
        }

    def _write_trip_details(self, name: str, fields: Dict[str, Any], stamp: str) -> None:
        fuel = json.dumps(fields.get("fuel_log") or [], separators=(",", ":"))
        defaults = _logging_defaults_text(fields.get("logging_defaults") or {})
        packing = packing_text(fields.get("packing") or [])
        self._conn.execute(
            "INSERT INTO trip_details (name_key, name, start_miles, end_miles, notes, attendees, vehicle, temperature, fuel_log, logging_defaults, packing, updated_at) "
            "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?) ON CONFLICT(name_key) DO UPDATE SET name = excluded.name, "
            "start_miles = excluded.start_miles, end_miles = excluded.end_miles, notes = excluded.notes, "
            "attendees = excluded.attendees, vehicle = excluded.vehicle, temperature = excluded.temperature, "
            "fuel_log = excluded.fuel_log, logging_defaults = excluded.logging_defaults, packing = excluded.packing, updated_at = excluded.updated_at",
            (
                trip_key(name), name, fields["start_miles"], fields["end_miles"],
                fields["notes"], fields["attendees"], fields["vehicle"], fields.get("temperature") or "", fuel, defaults or "", packing, stamp,
            ),
        )

    def save_trip_details(self, name: str, raw: Dict[str, Any]) -> Dict[str, str]:
        name = (name or "").strip()
        if not name:
            raise ValidationError("Pick a trip first", "trip_name")
        fields = clean_trip_details(raw)
        before = self.trip_details().get(trip_key(name))
        stamp = _now()
        with self._lock:
            self._write_trip_details(name, fields, stamp)
            self._conn.commit()
        after = dict(fields, name=name, updated_at=stamp)
        if before is None or any(before[k] != after[k] for k in self.TRIP_DETAIL_FIELDS):
            self.log_activity(
                "trip.details",
                "Saved the details for trip {}.".format(name),
                {"trip": name, "before": before, "after": after},
            )
        return after

    def merge_trip_details(self, items: Iterable[Dict[str, Any]], source: str = "") -> int:
        """Add trip details from another device without losing anything already here:
        blank fields are filled, attendees are combined, differing notes are both kept,
        and mileage, vehicle, temperature, and the fuel log take the newer value."""
        current = self.trip_details()
        changed = 0
        for item in items or []:
            if not isinstance(item, dict):
                continue
            name = str(item.get("name") or "").strip()
            if not name:
                continue
            try:
                incoming = clean_trip_details(item)
            except ValidationError:
                continue
            mine = current.get(trip_key(name))
            if mine is None:
                merged = incoming
            else:
                newer = str(item.get("updated_at") or "") > str(mine.get("updated_at") or "")
                merged = {}
                for key in ("start_miles", "end_miles", "vehicle", "temperature", "fuel_log"):
                    merged[key] = incoming[key] if incoming[key] and (not mine[key] or newer) else mine[key]
                ours, theirs = mine["notes"], incoming["notes"]
                if not theirs or theirs in ours:
                    merged["notes"] = ours
                elif not ours or ours in theirs:
                    merged["notes"] = theirs
                else:
                    merged["notes"] = ours + "\n\n" + theirs
                merged["attendees"] = join_attendees(split_attendees(mine["attendees"]) + split_attendees(incoming["attendees"]))
                # Keep pad defaults / packing from this Mac unless the incoming trip has them
                # and ours are empty (or the phone copy is newer with values).
                for key in ("logging_defaults", "packing"):
                    theirs = incoming.get(key) or ({} if key == "logging_defaults" else [])
                    ours = mine.get(key) or ({} if key == "logging_defaults" else [])
                    merged[key] = theirs if theirs and (not ours or newer) else ours
                if all(merged[k] == mine[k] for k in self.TRIP_DETAIL_FIELDS):
                    continue
                name = mine["name"]
            stamp = _now()
            with self._lock:
                self._write_trip_details(name, merged, stamp)
                self._conn.commit()
            self.log_activity(
                "trip.details",
                "Updated the details for trip {}{}.".format(name, " from " + source if source else ""),
                {"trip": name, "before": mine, "after": dict(merged, name=name, updated_at=stamp)},
            )
            changed += 1
        return changed

    def find_duplicates(
        self,
        cleaned: Dict[str, Any],
        exclude_id: Optional[int] = None,
        minutes: int = DUPLICATE_WINDOW_MINUTES,
        max_id: Optional[int] = None,
    ) -> List[TrainEntry]:
        target = combine_datetime(cleaned["date"], cleaned["time"])
        target_spot = spot_name(cleaned.get("location_spot") or "").upper()
        # Match railroad / lead / direction in SQL; compare place by spot name so
        # "Needles" and "Needles (MP 578.4)" still count as the same location.
        clauses = [
            "upper(railroad) = ?",
            "upper(lead_locomotive) = ?",
            "upper(direction) = ?",
        ]
        params: List[Any] = [
            cleaned["railroad"].upper(),
            cleaned["lead_locomotive"].upper(),
            (cleaned.get("direction") or "").upper(),
        ]
        if exclude_id is not None:
            clauses.append("id != ?")
            params.append(exclude_id)
        if max_id is not None:
            clauses.append("id <= ?")
            params.append(max_id)
        sql = "SELECT * FROM train_entries WHERE " + " AND ".join(clauses)
        with self._lock:
            rows = self._conn.execute(sql, params).fetchall()
        has_lead = bool((cleaned.get("lead_locomotive") or "").strip())
        matches = []
        for row in rows:
            entry = _entry_from_row(row)
            if spot_name(entry.location_spot or "").upper() != target_spot:
                continue
            if not has_lead:
                if exact_duplicate(cleaned, entry.to_dict()):
                    matches.append(entry)
                continue
            existing_dt = combine_datetime(entry.date, entry.time)
            if is_within_window(target, existing_dt, minutes=minutes):
                matches.append(entry)
        return matches

    def autocomplete_locations(self, query: str, limit: int = 12) -> List[LocationHistory]:
        query = (query or "").strip()
        sql = """
            SELECT * FROM location_history
            WHERE location_spot LIKE ? OR location_subdivision LIKE ?
            ORDER BY use_count DESC, last_used DESC
            LIMIT ?
        """
        like = "%{}%".format(query)
        with self._lock:
            rows = self._conn.execute(sql, (like, like, limit)).fetchall()
        results = []
        for row in rows:
            results.append(
                LocationHistory(
                    id=row["id"],
                    location_spot=row["location_spot"],
                    location_subdivision=row["location_subdivision"] or "",
                    location_region=row["location_region"] or DEFAULT_REGION,
                    last_used=row["last_used"],
                    use_count=row["use_count"],
                )
            )
        return results

    def last_locomotive(self, railroad: Optional[str] = None) -> Optional[Dict[str, Any]]:
        if railroad:
            sql = """
                SELECT * FROM locomotive_history
                WHERE railroad = ?
                ORDER BY last_used DESC LIMIT 1
            """
            params: Tuple[Any, ...] = (railroad,)
        else:
            sql = "SELECT * FROM locomotive_history ORDER BY last_used DESC LIMIT 1"
            params = ()
        with self._lock:
            row = self._conn.execute(sql, params).fetchone()
        if not row:
            return None
        history = LocomotiveHistory(
            id=row["id"],
            railroad=row["railroad"],
            lead_locomotive=row["lead_locomotive"],
            train_types=parse_types_value(row["train_types"]),
            car_counts=row["car_counts"] or "",
            last_used=row["last_used"],
        )
        return history.to_dict()

    def last_entry(self) -> Optional[TrainEntry]:
        with self._lock:
            row = self._conn.execute(
                "SELECT * FROM train_entries ORDER BY created_at DESC, id DESC LIMIT 1"
            ).fetchone()
        return _entry_from_row(row) if row else None

    def _touch_history(self, cleaned: Dict[str, Any]) -> None:
        stamp = _now()
        self._conn.execute(
            """
            INSERT INTO location_history (
                location_spot, location_subdivision, location_region, last_used, use_count
            ) VALUES (?, ?, ?, ?, 1)
            ON CONFLICT(location_spot, location_subdivision, location_region)
            DO UPDATE SET use_count = use_count + 1, last_used = excluded.last_used
            """,
            (
                cleaned["location_spot"],
                cleaned.get("location_subdivision") or "",
                cleaned.get("location_region") or DEFAULT_REGION,
                stamp,
            ),
        )
        if not cleaned.get("lead_locomotive"):
            return
        self._conn.execute(
            """
            INSERT INTO locomotive_history (
                railroad, lead_locomotive, train_types, car_counts, last_used
            ) VALUES (?, ?, ?, ?, ?)
            ON CONFLICT(railroad, lead_locomotive)
            DO UPDATE SET
                train_types = excluded.train_types,
                car_counts = excluded.car_counts,
                last_used = excluded.last_used
            """,
            (
                cleaned["railroad"],
                cleaned["lead_locomotive"],
                types_to_storage(cleaned["train_types"]),
                cleaned["car_counts"],
                stamp,
            ),
        )

    def add_pending(
        self,
        payload: Dict[str, Any],
        source: str,
        reason: str,
        match_entry_id: Optional[int],
    ) -> int:
        with self._lock:
            cursor = self._conn.execute(
                """
                INSERT INTO pending_imports (source, payload, match_entry_id, reason, status)
                VALUES (?, ?, ?, ?, 'pending')
                """,
                (source, json.dumps(payload, ensure_ascii=False), match_entry_id, reason),
            )
            self._conn.commit()
            return int(cursor.lastrowid)

    def list_pending(self, status: str = "pending") -> List[PendingImport]:
        with self._lock:
            rows = self._conn.execute(
                """
                SELECT p.*, e.date AS match_date, e.time AS match_time,
                       e.railroad AS match_railroad, e.lead_locomotive AS match_loco,
                       e.location_spot AS match_location, e.uid AS match_uid,
                       e.notes AS match_notes, e.train_symbol AS match_symbol
                FROM pending_imports p
                LEFT JOIN train_entries e ON e.id = p.match_entry_id
                WHERE p.status = ?
                ORDER BY p.id DESC
                """,
                (status,),
            ).fetchall()
        items = []
        for row in rows:
            payload = json.loads(row["payload"])
            match_entry = None
            if row["match_entry_id"]:
                match_entry = {
                    "id": row["match_entry_id"],
                    "date": row["match_date"],
                    "time": row["match_time"],
                    "railroad": row["match_railroad"],
                    "lead_locomotive": row["match_loco"],
                    "location_spot": row["match_location"],
                    "uid": row["match_uid"] or "",
                    "notes": row["match_notes"] or "",
                    "train_symbol": row["match_symbol"] or "",
                }
            incoming_uid = str(payload.get("uid") or "")
            reason = row["reason"] or ""
            conflict = bool(
                row["match_entry_id"]
                and (
                    (incoming_uid and (row["match_uid"] or "") == incoming_uid)
                    or "edited on both sides" in reason
                    or "Changed since it was last sent" in reason
                )
            )
            items.append(
                PendingImport(
                    id=row["id"],
                    source=row["source"] or "",
                    payload=payload,
                    match_entry_id=row["match_entry_id"],
                    match_entry=match_entry,
                    reason=row["reason"] or "",
                    status=row["status"],
                    created_at=row["created_at"],
                    conflict=conflict,
                )
            )
        return items

    def _set_pending_status(self, pending_id: int, status: str) -> Optional[PendingImport]:
        with self._lock:
            row = self._conn.execute(
                "SELECT * FROM pending_imports WHERE id = ?", (pending_id,)
            ).fetchone()
            if not row:
                return None
            self._conn.execute(
                "UPDATE pending_imports SET status = ? WHERE id = ?",
                (status, pending_id),
            )
            self._conn.commit()
        return PendingImport(
            id=row["id"],
            source=row["source"] or "",
            payload=json.loads(row["payload"]),
            match_entry_id=row["match_entry_id"],
            reason=row["reason"] or "",
            status=status,
            created_at=row["created_at"],
        )

    def discard_pending(self, pending_id: int) -> bool:
        item = self._set_pending_status(pending_id, "discarded")
        if item is not None:
            self.log_activity(
                "import.discard",
                "Discarded held import #{}.".format(pending_id),
                item.to_dict(),
            )
        return item is not None

    def accept_pending(self, pending_id: int, edited: Optional[Dict[str, Any]] = None) -> TrainEntry:
        with self._lock:
            row = self._conn.execute(
                "SELECT * FROM pending_imports WHERE id = ? AND status = 'pending'",
                (pending_id,),
            ).fetchone()
            if not row:
                raise ValidationError("Pending import not found", "id")
            payload = json.loads(row["payload"])
        review = payload.pop("import_review", None)
        if edited:
            payload = {k: v for k, v in edited.items() if k not in ("force", "row", "import_review")}
        cleaned = validate_entry(payload)
        cleaned["force"] = True
        entry = self.create_entry(cleaned, log=False)
        if isinstance(review, dict) and review:
            self._add_review(entry.id, row["source"] or "", review)
        self._set_pending_status(pending_id, "accepted")
        self.log_activity(
            "import.accept",
            entry_activity_summary("Accepted import", entry),
            {"pending_id": pending_id, "pending": payload, "entry": entry.to_dict()},
        )
        return entry

    def resolve_pending(self, pending_id: int, resolution: str) -> Dict[str, Any]:
        """Resolve a held import: keep_both, prefer_existing (Mac), or prefer_incoming (phone)."""
        choice = (resolution or "").strip().lower().replace("-", "_")
        aliases = {
            "prefer_mac": "prefer_existing",
            "discard": "prefer_existing",
            "prefer_phone": "prefer_incoming",
            "use_incoming": "prefer_incoming",
            "add": "keep_both",
            "accept": "keep_both",
        }
        choice = aliases.get(choice, choice)
        if choice == "prefer_existing":
            if not self.discard_pending(pending_id):
                raise ValidationError("Pending import not found", "id")
            return {"resolution": "prefer_existing", "entry": None}
        if choice == "keep_both":
            entry = self.accept_pending(pending_id)
            return {"resolution": "keep_both", "entry": entry.to_dict()}
        if choice != "prefer_incoming":
            raise ValidationError(
                "Pick keep_both, prefer_existing, or prefer_incoming", "resolution"
            )
        with self._lock:
            row = self._conn.execute(
                "SELECT * FROM pending_imports WHERE id = ? AND status = 'pending'",
                (pending_id,),
            ).fetchone()
            if not row:
                raise ValidationError("Pending import not found", "id")
            payload = json.loads(row["payload"])
            match_id = row["match_entry_id"]
        if not match_id:
            raise ValidationError("No existing sighting to replace", "resolution")
        existing = self.get_entry(int(match_id))
        if existing is None:
            raise ValidationError("Existing sighting #{} is gone".format(match_id), "id")
        review = payload.pop("import_review", None)
        cleaned = validate_entry({k: v for k, v in payload.items() if k not in ("force", "row", "import_review")})
        # Keep the Mac row id/uid; overwrite fields with the incoming copy.
        cleaned["uid"] = existing.uid or cleaned.get("uid") or ""
        entry = self.update_entry(int(match_id), cleaned)
        if entry is None:
            raise ValidationError("Could not update existing sighting", "id")
        if isinstance(review, dict) and review:
            self._add_review(entry.id, row["source"] or "", review)
        self._set_pending_status(pending_id, "accepted")
        self.log_activity(
            "import.prefer_incoming",
            entry_activity_summary("Preferred incoming over Mac copy", entry),
            {
                "pending_id": pending_id,
                "pending": payload,
                "before": existing.to_dict(),
                "after": entry.to_dict(),
                "resolution": "prefer_incoming",
            },
        )
        return {"resolution": "prefer_incoming", "entry": entry.to_dict()}

    def import_records(
        self, records: Iterable[Dict[str, Any]], source: str = "import"
    ) -> Dict[str, Any]:
        from guess import fill_guesses
        from states import state_from_region
        from stations import with_milepost
        from work import begin, finish, update

        created = 0
        pending = 0
        already = 0
        guessed_sub = 0
        guessed_zone = 0
        review_rows = 0
        errors: List[Dict[str, Any]] = []
        rows = list(records or [])
        total = len(rows)
        with self._lock:
            start_max = self._conn.execute("SELECT COALESCE(MAX(id), 0) FROM train_entries").fetchone()[0]
        begin("Importing trains…", total=total, message="Importing trains…")
        try:
            items: List[Dict[str, Any]] = []
            for index, raw in enumerate(rows, start=1):
                if index % 25 == 1:
                    update(current=0, total=total, message="Checking {} of {}…".format(index, total))
                try:
                    cleaned = validate_entry(raw)
                except ValidationError as exc:
                    errors.append({"row": index, "error": exc.message, "field": exc.field})
                    continue
                raw_sub = str(raw.get("location_subdivision") or raw.get("subdivision") or "").strip()
                raw_loc = str(raw.get("location_spot") or "")
                raw_region = str(raw.get("location_region") or "").strip()
                region_given = bool(raw_region) and raw_region != DEFAULT_REGION
                state_given = bool(str(raw.get("location_state") or raw.get("state") or "").strip())
                if not state_given and region_given and state_from_region(raw_region):
                    cleaned["location_state"] = state_from_region(raw_region)
                    state_given = True
                items.append(
                    {
                        "cleaned": cleaned,
                        "sub_blank": not raw_sub and not re.search(r"[·•]", raw_loc),
                        "zone_blank": not str(raw.get("time_zone") or "").strip(),
                        "region_given": region_given,
                        "state_given": state_given,
                    }
                )
            if items:
                update(current=0, total=total, message="Guessing subdivisions and time zones…")
                fill_guesses(items, (entry.to_dict() for entry in self.list_entries()))
            for index, item in enumerate(items, start=1):
                update(
                    current=index - 1,
                    total=len(items),
                    message="Importing {} of {}…".format(index, len(items)),
                )
                cleaned = item["cleaned"]
                review = item.get("review") or {}
                if review.get("sub_status") == "guessed":
                    guessed_sub += 1
                    cleaned["location_spot"] = with_milepost(
                        cleaned["location_spot"], cleaned.get("railroad") or "", cleaned["location_subdivision"]
                    )
                if review.get("zone_status") == "guessed":
                    guessed_zone += 1
                known = self.entry_by_uid(cleaned.get("uid") or "")
                if known is not None:
                    if _same_sighting(cleaned, validate_entry(known.to_dict())):
                        already += 1
                        continue
                    # Keep uid so Review can flag the conflict and Prefer incoming
                    # can update the Mac row in place. Keep both still mints a new uid.
                    payload = {k: v for k, v in cleaned.items() if k not in ("force", "row")}
                    self.add_pending(
                        payload=payload,
                        source=source,
                        reason="Same sighting was edited on both sides; the log still has #{} as it was. "
                        "Keep both, prefer this Mac, or prefer the incoming copy — "
                        "nothing is overwritten unless you choose.".format(known.id),
                        match_entry_id=known.id,
                    )
                    pending += 1
                    continue
                matches = self.find_duplicates(cleaned, max_id=start_max)
                if matches:
                    exact = any(
                        exact_duplicate(cleaned, match.to_dict()) for match in matches
                    )
                    reason = (
                        "Exact duplicate of existing entry #{}".format(matches[0].id)
                        if exact
                        else duplicate_window_message(matches[0].id)
                    )
                    payload = {k: v for k, v in cleaned.items() if k not in ("force", "row")}
                    if review:
                        payload["import_review"] = review
                    self.add_pending(
                        payload=payload,
                        source=source,
                        reason=reason,
                        match_entry_id=matches[0].id,
                    )
                    pending += 1
                    continue
                entry = self.create_entry(cleaned, log=False)
                created += 1
                if review:
                    self._add_review(entry.id, source, review)
                    review_rows += 1
            update(current=total, total=total, message="Finishing import…")
        finally:
            finish()
        result = {
            "created": created,
            "pending": pending,
            "already": already,
            "errors": errors,
            "source": source,
            "guessed_subdivisions": guessed_sub,
            "guessed_time_zones": guessed_zone,
            "to_check": review_rows,
        }
        summary = "Imported {created} entries; {pending} held for review.".format(created=created, pending=pending)
        if already:
            summary += " {} already in the log.".format(already)
        self.log_activity("import.file", summary, result)
        return {
            "created": created,
            "pending": pending,
            "already": already,
            "errors": errors,
            "guessed_subdivisions": guessed_sub,
            "guessed_time_zones": guessed_zone,
            "to_check": review_rows,
        }

    def _add_review(self, entry_id: int, source: str, review: Dict[str, str]) -> None:
        with self._lock:
            self._conn.execute(
                """
                INSERT OR REPLACE INTO import_review
                    (entry_id, source, sub_status, sub_reason, zone_status, zone_reason, created_at)
                VALUES (?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    entry_id,
                    source or "",
                    review.get("sub_status") or "",
                    review.get("sub_reason") or "",
                    review.get("zone_status") or "",
                    review.get("zone_reason") or "",
                    _now(),
                ),
            )
            self._conn.commit()

    def _settle_review(self, entry_ids: Iterable[int], *, sub: bool = False, zone: bool = False) -> None:
        ids = sorted({int(item) for item in entry_ids})
        if not ids or not (sub or zone):
            return
        marks = ",".join("?" * len(ids))
        sets = []
        if sub:
            sets.append("sub_status = '', sub_reason = ''")
        if zone:
            sets.append("zone_status = '', zone_reason = ''")
        with self._lock:
            self._conn.execute(
                "UPDATE import_review SET {} WHERE entry_id IN ({})".format(", ".join(sets), marks), ids
            )
            self._conn.execute("DELETE FROM import_review WHERE sub_status = '' AND zone_status = ''")

    def import_review_count(self) -> int:
        with self._lock:
            return int(self._conn.execute("SELECT COUNT(*) FROM import_review").fetchone()[0])

    def list_import_review(self) -> List[Dict[str, Any]]:
        with self._lock:
            rows = self._conn.execute(
                """
                SELECT r.entry_id, r.source, r.sub_status, r.sub_reason, r.zone_status, r.zone_reason,
                       r.created_at AS review_created_at, e.*
                FROM import_review r
                JOIN train_entries e ON e.id = r.entry_id
                ORDER BY e.date, e.time, e.id
                """
            ).fetchall()
        items = []
        for row in rows:
            entry = _entry_from_row(row).to_dict()
            items.append(
                {
                    "entry": entry,
                    "source": row["source"] or "",
                    "sub_status": row["sub_status"] or "",
                    "sub_reason": row["sub_reason"] or "",
                    "zone_status": row["zone_status"] or "",
                    "zone_reason": row["zone_reason"] or "",
                }
            )
        return items

    def apply_import_review(
        self,
        entry_ids: Iterable[int],
        *,
        subdivision: Optional[str] = None,
        time_zone: Optional[str] = None,
        keep: bool = False,
    ) -> Dict[str, int]:
        """Set subdivision and/or time zone on reviewed sightings, or keep the guesses."""
        from stations import station_state, with_milepost

        ids = sorted({int(item) for item in entry_ids})
        if not ids:
            return {"updated": 0, "cleared": 0}
        marks = ",".join("?" * len(ids))
        stamp = _now()
        updated = 0
        with self._lock:
            if subdivision is not None:
                rows = self._conn.execute(
                    "SELECT id, railroad, location_spot, location_state FROM train_entries WHERE id IN ({})".format(marks),
                    ids,
                ).fetchall()
                for row in rows:
                    spot = with_milepost(row["location_spot"] or "", row["railroad"] or "", subdivision)
                    state = station_state(spot or row["location_spot"] or "", row["railroad"] or "", subdivision)
                    self._conn.execute(
                        "UPDATE train_entries SET location_subdivision = ?, location_spot = ?, location_state = ?, "
                        "updated_at = ? WHERE id = ?",
                        (subdivision, spot or row["location_spot"] or "", state or row["location_state"] or "", stamp, row["id"]),
                    )
                updated = max(updated, len(rows))
            if time_zone is not None:
                cursor = self._conn.execute(
                    "UPDATE train_entries SET time_zone = ?, updated_at = ? WHERE id IN ({})".format(marks),
                    [time_zone, stamp] + ids,
                )
                updated = max(updated, cursor.rowcount)
            before = self.import_review_count()
            if keep:
                self._conn.execute("DELETE FROM import_review WHERE entry_id IN ({})".format(marks), ids)
            else:
                self._settle_review(ids, sub=subdivision is not None, zone=time_zone is not None)
            self._conn.commit()
            cleared = before - self.import_review_count()
        parts = []
        if subdivision is not None:
            parts.append("subdivision {}".format(subdivision or "(none)"))
        if time_zone is not None:
            parts.append("time zone {}".format(time_zone or "(none)"))
        summary = (
            "Set {} on {} imported sighting{}.".format(" and ".join(parts), updated, "" if updated == 1 else "s")
            if parts
            else "Kept guesses on {} imported sighting{}.".format(len(ids), "" if len(ids) == 1 else "s")
        )
        self.log_activity(
            "import.review",
            summary,
            {"ids": ids, "subdivision": subdivision, "time_zone": time_zone, "keep": keep},
        )
        return {"updated": updated, "cleared": cleared}

    def export_rows(self, filters: Optional[Dict[str, Any]] = None) -> List[Dict[str, Any]]:
        return [entry.to_dict() for entry in reversed(self.list_entries(filters))]

    def backup_to(self, dest: Path) -> Path:
        dest = Path(dest)
        dest.parent.mkdir(parents=True, exist_ok=True)
        if dest.exists():
            dest.unlink()
        out = sqlite3.connect(str(dest))
        try:
            with self._lock:
                self._conn.backup(out)
            out.execute("VACUUM")
            out.commit()
        finally:
            out.close()
        return dest

    def special_power_values(self) -> List[str]:
        with self._lock:
            rows = self._conn.execute(
                "SELECT special_power FROM train_entries WHERE special_power != ''"
            ).fetchall()
        return [row["special_power"] for row in rows]

    def backup_bytes(self) -> bytes:
        handle = tempfile.NamedTemporaryFile(suffix=".db", delete=False)
        tmp_path = Path(handle.name)
        handle.close()
        try:
            self.backup_to(tmp_path)
            return tmp_path.read_bytes()
        finally:
            try:
                tmp_path.unlink()
            except OSError:
                pass

    def recovery_pack_bytes(self) -> bytes:
        """Zip a database copy + JSON export + manifest for wipe recovery / AirDrop."""
        import io
        import json
        import zipfile

        from version import APP_VERSION

        db_bytes = self.backup_bytes()
        rows = self.export_rows()
        dates = sorted({str(row.get("date") or "") for row in rows if row.get("date")})
        manifest = {
            "app": "TRAIN LOG",
            "format": 1,
            "version": APP_VERSION,
            "created": datetime.now().strftime("%Y-%m-%dT%H:%M:%S"),
            "trains": len(rows),
            "first_date": dates[0] if dates else "",
            "last_date": dates[-1] if dates else "",
            "db_bytes": len(db_bytes),
            "contents": ["manifest.json", "trains.db", "trains.json", "README.txt"],
        }
        readme = (
            "TRAIN LOG recovery pack\n"
            "======================\n\n"
            "trains.db   — SQLite database (restore on a Mac with Backup / replace trains.db)\n"
            "trains.json — sightings export (Import on Mac, iPhone, or iPad)\n"
            "manifest.json — counts and dates when this pack was made\n\n"
            "AirDrop or copy this zip somewhere safe. Keep the newest pack after big trips.\n"
        )
        buf = io.BytesIO()
        with zipfile.ZipFile(buf, "w", compression=zipfile.ZIP_DEFLATED) as zf:
            zf.writestr("manifest.json", json.dumps(manifest, indent=2))
            zf.writestr("trains.db", db_bytes)
            zf.writestr("trains.json", json.dumps(rows, ensure_ascii=False))
            zf.writestr("README.txt", readme)
        return buf.getvalue()


def decode_import_bytes(raw_bytes: bytes) -> str:
    raw = raw_bytes or b""
    if raw.startswith(b"\xff\xfe") or raw.startswith(b"\xfe\xff"):
        return raw.decode("utf-16")
    for encoding in ("utf-8-sig", "utf-8", "utf-16", "cp1252", "latin-1"):
        try:
            return raw.decode(encoding)
        except UnicodeDecodeError:
            continue
    return raw.decode("utf-8", errors="replace")


def _normalize_header(name: str) -> str:
    text = (name or "").strip().lstrip("\ufeff").lower()
    text = re.sub(r"[\s_]+", " ", text).strip()
    if not text:
        return ""
    return HEADER_ALIASES.get(text) or HEADER_ALIASES.get(text.replace(" ", "_")) or text.replace(" ", "_")


def _map_import_row(row: Dict[str, Any]) -> Dict[str, Any]:
    mapped: Dict[str, Any] = {}
    for key, value in row.items():
        if key is None:
            continue
        canon = _normalize_header(str(key))
        if not canon:
            continue
        text_val = value.strip() if isinstance(value, str) else value
        if canon in mapped and (text_val is None or str(text_val).strip() == ""):
            continue
        mapped[canon] = text_val
    media = str(mapped.get("media") or "").lower()
    if "photo" in media:
        mapped["photographed"] = True
    if "video" in media:
        mapped["videoed"] = True
    return mapped


def _row_has_values(row: Dict[str, Any]) -> bool:
    return any(str(value).strip() for value in row.values() if value is not None)


def parse_tabular_records(text: str) -> List[Dict[str, Any]]:
    cleaned = (text or "").replace("\r\n", "\n").replace("\r", "\n")
    stripped = cleaned.lstrip()
    if not stripped.strip():
        return []
    sample = stripped.split("\n", 1)[0]
    if "\t" in sample and sample.count("\t") >= sample.count(","):
        delimiter = "\t"
    elif sample.count(";") > sample.count(","):
        delimiter = ";"
    else:
        delimiter = ","
    reader = csv.DictReader(io.StringIO(cleaned), delimiter=delimiter)
    rows = []
    for row in reader:
        mapped = _map_import_row(row)
        if _row_has_values(mapped):
            rows.append(mapped)
    return rows


def parse_import_payload(filename: str, raw_bytes: bytes) -> List[Dict[str, Any]]:
    name = (filename or "").lower()
    text = decode_import_bytes(raw_bytes)
    stripped = text.lstrip()
    as_json = name.endswith(".json") or (
        not name.endswith(".csv") and not name.endswith(".tsv") and stripped[:1] in "{["
    )
    if as_json:
        try:
            data = json.loads(text)
        except json.JSONDecodeError as exc:
            raise ValidationError("Could not read that JSON file", "file") from exc
        if isinstance(data, dict):
            if isinstance(data.get("entries"), list):
                return data["entries"]
            if isinstance(data.get("csv"), str):
                return parse_tabular_records(data["csv"])
            return [data]
        if isinstance(data, list):
            return data
        raise ValidationError("JSON import must be an object or array")
    return parse_tabular_records(text)


def _coords_text(value: Any) -> str:
    if value in (None, ""):
        return ""
    return value if isinstance(value, str) else json.dumps(value)


def rows_to_csv(rows: List[Dict[str, Any]]) -> str:
    buffer = io.StringIO()
    writer = csv.DictWriter(buffer, fieldnames=CSV_FIELDS, extrasaction="ignore")
    writer.writeheader()
    for row in rows:
        writer.writerow(
            {
                "date": row.get("date"),
                "time": row.get("time"),
                "time_zone": row.get("time_zone") or "",
                "railroad": row.get("railroad"),
                "lead_locomotive": row.get("lead_locomotive"),
                "direction": row.get("direction"),
                "power_consist": row.get("power_consist"),
                "train_types": "|".join(row.get("train_types") or []),
                "load_status": row.get("load_status") or "",
                "car_counts": row.get("car_counts"),
                "location_spot": row.get("location_spot"),
                "subdivision": row.get("location_subdivision") or row.get("subdivision") or "",
                "state": row.get("location_state") or row.get("state") or "",
                "location_region": row.get("location_region") or "",
                "location_coordinates": _coords_text(row.get("location_coordinates")),
                "symbol": row.get("train_symbol") or "",
                "train_number": row.get("train_number") or "",
                "train_info": row.get("train_info") or "",
                "special_power": special_power_storage(row.get("special_power")),
                "notes": row.get("notes") or "",
                "photographed": "true" if row.get("photographed") else "false",
                "videoed": "true" if row.get("videoed") else "false",
                "trip_name": row.get("trip_name") or "",
                "trip_date_from": row.get("trip_date_from") or "",
                "trip_date_to": row.get("trip_date_to") or "",
                "lead_status": row.get("lead_status") or "",
                "night": "true" if row.get("night") else "",
                "stopped": "true" if row.get("stopped") else "",
                "in_siding": "true" if row.get("in_siding") else "",
                "crew_change": "true" if row.get("crew_change") else "",
                "no_crew": "true" if row.get("no_crew") else "",
                "coal_mark": row.get("coal_mark") or "",
                "con_overseas": "true" if row.get("con_overseas") else "",
                "con_domestic": "true" if row.get("con_domestic") else "",
                "uid": row.get("uid") or "",
            }
        )
    return buffer.getvalue()
