"""In-app work progress for long jobs such as imports."""
from __future__ import annotations

import threading
import time
from typing import Any, Dict, List, Optional

_lock = threading.Lock()
_stack: List[Dict[str, Any]] = []


def _frame(
    title: str,
    total: int = 0,
    current: int = 0,
    message: str = "",
) -> Dict[str, Any]:
    return {
        "active": True,
        "title": title or "Working…",
        "message": message or title or "Working…",
        "current": max(0, int(current or 0)),
        "total": max(0, int(total or 0)),
        "started": time.time(),
    }


def begin(title: str, total: int = 0, message: str = "") -> None:
    with _lock:
        _stack.append(_frame(title, total=total, message=message))


def update(
    current: Optional[int] = None,
    total: Optional[int] = None,
    message: Optional[str] = None,
    title: Optional[str] = None,
) -> None:
    with _lock:
        if not _stack:
            _stack.append(_frame(title or "Working…", total=total or 0, message=message or ""))
            return
        frame = _stack[-1]
        if title:
            frame["title"] = title
        if message is not None:
            frame["message"] = message
        elif title:
            frame["message"] = title
        if total is not None:
            frame["total"] = max(0, int(total))
        if current is not None:
            frame["current"] = max(0, int(current))


def finish() -> None:
    with _lock:
        if _stack:
            _stack.pop()


def snapshot() -> Dict[str, Any]:
    with _lock:
        if not _stack:
            return {
                "active": False,
                "title": "",
                "message": "",
                "current": 0,
                "total": 0,
            }
        frame = dict(_stack[-1])
        frame["elapsed"] = max(0, time.time() - float(frame.get("started") or time.time()))
        return frame
