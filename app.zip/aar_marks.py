"""AAR reporting marks guide: shipped list plus optional corrections on this Mac.

The big list ships in static/reference/aar-marks.json. Edits made in the guide
live in Application Support and overlay that list on read. Restore removes a
mark's override (or clears every override).
"""
from __future__ import annotations

import json
import re
from functools import lru_cache
from pathlib import Path
from typing import Any, Dict, List, Optional, Set, Tuple

from paths import resource_root, support_dir

MAX_MARK = 12
MAX_NAME = 200
MAX_NAMES = 40
_FLAG_OK = {"", "*", "+"}


def custom_path() -> Path:
    return support_dir() / "aar_marks_custom.json"


def shipped_path() -> Path:
    return resource_root() / "static" / "reference" / "aar-marks.json"


def _clean_mark(raw: Any) -> str:
    mark = re.sub(r"[^A-Za-z0-9]", "", str(raw or "")).upper()[:MAX_MARK]
    return mark


def _clean_flag(raw: Any) -> str:
    flag = str(raw or "").strip()
    return flag if flag in _FLAG_OK else ""


def _clean_name_row(raw: Any) -> Optional[Dict[str, str]]:
    if isinstance(raw, dict):
        name = re.sub(r"\s+", " ", str(raw.get("n") or "")).strip()[:MAX_NAME]
        flag = _clean_flag(raw.get("f"))
    else:
        text = re.sub(r"\s+", " ", str(raw or "")).strip()
        flag = ""
        if text[:1] in ("*", "+") and len(text) > 1:
            flag = text[0]
            text = text[1:].strip()
        name = text[:MAX_NAME]
    if not name:
        return None
    return {"n": name, "f": flag}


def _clean_names(raw: Any) -> List[Dict[str, str]]:
    rows: List[Dict[str, str]] = []
    seen: Set[str] = set()
    for item in raw if isinstance(raw, list) else []:
        row = _clean_name_row(item)
        if not row:
            continue
        key = row["n"].casefold()
        if key in seen:
            continue
        seen.add(key)
        rows.append(row)
        if len(rows) >= MAX_NAMES:
            break
    return rows


def _blank_book() -> Dict[str, Any]:
    return {
        "source": "",
        "notes": [],
        "count": 0,
        "unique": 0,
        "marks": [],
        "edited": [],
    }


@lru_cache(maxsize=1)
def _shipped_book_cached(mtime_ns: int) -> Dict[str, Any]:
    del mtime_ns  # cache key only
    path = shipped_path()
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return _blank_book()
    if not isinstance(data, dict):
        return _blank_book()
    marks = []
    for entry in data.get("marks") or []:
        if not isinstance(entry, dict):
            continue
        mark = _clean_mark(entry.get("m"))
        if not mark:
            continue
        marks.append({"m": mark, "n": _clean_names(entry.get("n"))})
    notes = data.get("notes") if isinstance(data.get("notes"), list) else []
    return {
        "source": str(data.get("source") or ""),
        "notes": [str(item) for item in notes],
        "count": int(data.get("count") or len(marks)),
        "unique": int(data.get("unique") or len(marks)),
        "marks": marks,
        "edited": [],
    }


def shipped_book() -> Dict[str, Any]:
    path = shipped_path()
    try:
        mtime_ns = path.stat().st_mtime_ns
    except OSError:
        mtime_ns = 0
    book = _shipped_book_cached(mtime_ns)
    # Return a shallow-copied shell so callers can mutate marks/edited safely.
    return {
        "source": book["source"],
        "notes": list(book["notes"]),
        "count": book["count"],
        "unique": book["unique"],
        "marks": [dict(entry, n=list(entry["n"])) for entry in book["marks"]],
        "edited": [],
    }


def _read_custom() -> Dict[str, Any]:
    path = custom_path()
    if not path.is_file():
        return {"marks": {}, "removed": []}
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return {"marks": {}, "removed": []}
    data = data if isinstance(data, dict) else {}
    marks: Dict[str, List[Dict[str, str]]] = {}
    raw_marks = data.get("marks") if isinstance(data.get("marks"), dict) else {}
    for key, value in raw_marks.items():
        mark = _clean_mark(key)
        if not mark:
            continue
        if isinstance(value, dict) and "n" in value:
            names = _clean_names(value.get("n"))
        else:
            names = _clean_names(value)
        if names:
            marks[mark] = names
    removed: List[str] = []
    seen: Set[str] = set()
    for item in data.get("removed") if isinstance(data.get("removed"), list) else []:
        mark = _clean_mark(item)
        if mark and mark not in seen:
            seen.add(mark)
            removed.append(mark)
    return {"marks": marks, "removed": removed}


def _write_custom(custom: Dict[str, Any]) -> None:
    marks = custom.get("marks") if isinstance(custom.get("marks"), dict) else {}
    removed = custom.get("removed") if isinstance(custom.get("removed"), list) else []
    payload = {
        "marks": {mark: names for mark, names in sorted(marks.items()) if names},
        "removed": sorted({_clean_mark(item) for item in removed if _clean_mark(item)}),
    }
    if not payload["marks"] and not payload["removed"]:
        path = custom_path()
        if path.exists():
            path.unlink()
        return
    custom_path().write_text(json.dumps(payload, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")


def list_book() -> Dict[str, Any]:
    book = shipped_book()
    custom = _read_custom()
    removed = set(custom["removed"])
    overrides: Dict[str, List[Dict[str, str]]] = custom["marks"]
    edited: Set[str] = set()
    merged: List[Dict[str, Any]] = []
    seen: Set[str] = set()
    for entry in book["marks"]:
        mark = entry["m"]
        if mark in removed:
            edited.add(mark)
            continue
        if mark in overrides:
            merged.append({"m": mark, "n": [dict(row) for row in overrides[mark]]})
            edited.add(mark)
        else:
            merged.append({"m": mark, "n": [dict(row) for row in entry["n"]]})
        seen.add(mark)
    for mark, names in overrides.items():
        if mark in seen or mark in removed:
            continue
        merged.append({"m": mark, "n": [dict(row) for row in names]})
        edited.add(mark)
    merged.sort(key=lambda row: row["m"])
    book["marks"] = merged
    book["count"] = len(merged)
    book["unique"] = len(merged)
    book["edited"] = sorted(edited)
    return book


def save_mark(mark: Any, names: Any) -> Dict[str, Any]:
    cleaned_mark = _clean_mark(mark)
    if not cleaned_mark:
        raise ValueError("Type a reporting mark first.")
    cleaned_names = _clean_names(names)
    if not cleaned_names:
        raise ValueError("Add at least one name.")
    custom = _read_custom()
    custom["marks"][cleaned_mark] = cleaned_names
    if cleaned_mark in custom["removed"]:
        custom["removed"] = [item for item in custom["removed"] if item != cleaned_mark]
    _write_custom(custom)
    return list_book()


def restore_mark(mark: Any) -> Dict[str, Any]:
    cleaned_mark = _clean_mark(mark)
    if not cleaned_mark:
        raise ValueError("Pick a reporting mark first.")
    custom = _read_custom()
    changed = False
    if cleaned_mark in custom["marks"]:
        del custom["marks"][cleaned_mark]
        changed = True
    if cleaned_mark in custom["removed"]:
        custom["removed"] = [item for item in custom["removed"] if item != cleaned_mark]
        changed = True
    if changed:
        _write_custom(custom)
    return list_book()


def remove_mark(mark: Any) -> Dict[str, Any]:
    """Hide a shipped mark from the guide (or drop a custom-only mark)."""
    cleaned_mark = _clean_mark(mark)
    if not cleaned_mark:
        raise ValueError("Pick a reporting mark first.")
    custom = _read_custom()
    shipped = {entry["m"] for entry in shipped_book()["marks"]}
    if cleaned_mark in custom["marks"]:
        del custom["marks"][cleaned_mark]
    if cleaned_mark in shipped:
        if cleaned_mark not in custom["removed"]:
            custom["removed"].append(cleaned_mark)
    _write_custom(custom)
    return list_book()


def reset_all() -> Dict[str, Any]:
    path = custom_path()
    if path.exists():
        path.unlink()
    _shipped_book_cached.cache_clear()
    return list_book()


def mark_entry(book: Dict[str, Any], mark: Any) -> Optional[Dict[str, Any]]:
    want = _clean_mark(mark)
    for entry in book.get("marks") or []:
        if entry.get("m") == want:
            return entry
    return None
