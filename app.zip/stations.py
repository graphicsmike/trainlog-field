"""Station book from hand-built CSVs in assets/subdivisions/.

Each CSV lists one or more railroads on row 1 (trackage rights as
`BNSF or UP`), then Subdivision, Location, Milepost, State rows (State is
optional). Bundled files
and any CSVs added from the pad are merged. Drop in more files anytime;
they are re-read when the lists are used. Location stays whatever the
user types; these names are suggestions only.
"""
from __future__ import annotations

import csv
import io
import json
import os
import re
import threading
from collections import defaultdict
from functools import lru_cache
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

from paths import resource_root, support_dir
import railroads as rr_mod
from states import normalize_state

CSV_DIR = resource_root() / "assets" / "subdivisions"
_RR_SPLIT = re.compile(r"\s*(?:\bor\b|/|&|,|;|\||\band\b)\s*", re.I)
_SAFE_NAME = re.compile(r"[^A-Za-z0-9._ -]+")

_HEADER_MAP = {
    "subdivision": "sub",
    "sub": "sub",
    "location": "spot",
    "station": "spot",
    "siding": "spot",
    "name": "spot",
    "milepost": "mp",
    "mile": "mp",
    "mp": "mp",
    "state": "state",
    "province": "state",
}

StationRow = Tuple[Tuple[str, ...], str, str, str, str]

_LOADED = False
_CACHE_MTIME = None
SUBDIVISIONS: Dict[str, List[str]] = {}
STATIONS: List[StationRow] = []
STATION_STATES: Dict[Tuple[str, str], str] = {}
_BY_NAME: Dict[str, List[StationRow]] = {}
_BY_CORE: Dict[str, List[StationRow]] = {}
_SUB_STATES_CACHE: Dict[Tuple[str, str], List[str]] = {}
_CHECKED_AT = 0.0
_CHECK_SECONDS = 2.0


@lru_cache(maxsize=65536)
def _n(text: str) -> str:
    return re.sub(r"[^a-z0-9]+", "", (text or "").lower())


_MP_SUFFIX = re.compile(r"\s*\(MP\s*[^)]+\)\s*$", re.I)


def spot_name(location: str) -> str:
    return _MP_SUFFIX.sub("", location or "").strip()


def location_label(name: str, mp: str = "") -> str:
    name = spot_name(name)
    mp = (mp or "").strip()
    if not name:
        return ""
    if not mp:
        return name
    return "{} (MP {})".format(name, mp)


def _sub_key(text: str) -> str:
    n = _n(spot_name(text))
    n = n.replace("subdivision", "")
    if n.endswith("sub"):
        n = n[:-3]
    return n


_SUB_TAG = re.compile(r"\s*\(([A-Za-z0-9 /&.-]+)\)\s*$")


def _same_sub(selected: str, display: str, original: str, owners: Tuple[str, ...] = ()) -> bool:
    if not selected:
        return True
    sel_n = _n(selected)
    if sel_n == _n(display):
        return True
    if sel_n == _n(original):
        return True
    sel_k = _sub_key(selected)
    if sel_k and sel_k == _sub_key(original):
        return True
    tag = _SUB_TAG.search(selected)
    if not tag or not owners or _sub_key(selected[:tag.start()]) != _sub_key(original):
        return False
    marks = {_n(mark) for mark in tag.group(1).split("/")}
    return bool(marks & {_n(owner) for owner in owners})


def user_subdivisions_dir() -> Path:
    override = os.environ.get("TRAINS_SUBS_DIR")
    if override:
        path = Path(override).expanduser()
        path.mkdir(parents=True, exist_ok=True)
        return path
    path = support_dir() / "subdivisions"
    path.mkdir(parents=True, exist_ok=True)
    return path


_INBOUND_README = (
    "TRAIN LOG watch folder\n\n"
    "Use this folder to add extra subdivision CSVs in bulk instead of one at a "
    "time from Add subdivision. Drop in as many files as you like. While TRAIN "
    "LOG is open it checks every few seconds, imports each CSV into the station "
    "book, and moves the file into imported/. A file that cannot be read goes "
    "into failed/ with a .txt note saying why.\n\n"
    "CSV layout, one subdivision per file:\n"
    "Row 1: railroad marks, such as BNSF or UP\n"
    "Row 2: Subdivision,Location,Milepost,State (State is optional, like AZ)\n"
)
_inbound_lock = threading.Lock()
_inbound_state: Dict[str, Any] = {
    "last_imported_at": "",
    "imported": [],
    "failed": [],
}


def inbound_dir() -> Path:
    base = support_dir()
    path = base / "watch"
    legacy = base / "inbound"
    if legacy.is_dir() and not path.exists():
        try:
            legacy.rename(path)
        except OSError:
            pass
    path.mkdir(parents=True, exist_ok=True)
    (path / "imported").mkdir(parents=True, exist_ok=True)
    (path / "failed").mkdir(parents=True, exist_ok=True)
    readme = path / "README.txt"
    if not readme.exists() or readme.read_text(encoding="utf-8") != _INBOUND_README:
        readme.write_text(_INBOUND_README, encoding="utf-8")
    return path


def inbound_status() -> Dict[str, Any]:
    folder = inbound_dir()
    pending = sorted(path.name for path in folder.glob("*.csv") if path.is_file())
    with _inbound_lock:
        imported = list(_inbound_state["imported"])
        failed = list(_inbound_state["failed"])
        last = _inbound_state["last_imported_at"]
    return {
        "path": str(folder),
        "pending": pending,
        "imported": imported,
        "failed": failed,
        "last_imported_at": last,
    }


def _unique_path(folder: Path, name: str) -> Path:
    dest = folder / name
    if not dest.exists():
        return dest
    stem = dest.stem
    suffix = dest.suffix
    n = 2
    while True:
        candidate = folder / "{}-{}{}".format(stem, n, suffix)
        if not candidate.exists():
            return candidate
        n += 1


def ingest_inbound_csvs() -> Dict[str, Any]:
    from datetime import datetime, timezone

    from validators import ValidationError

    folder = inbound_dir()
    imported: List[Dict[str, Any]] = []
    failed: List[Dict[str, Any]] = []
    with _inbound_lock:
        for path in sorted(folder.glob("*.csv")):
            if not path.is_file():
                continue
            try:
                info = import_subdivision_csv(path.name, path.read_bytes())
                dest = _unique_path(folder / "imported", path.name)
                path.replace(dest)
                info["inbound"] = dest.name
                imported.append(info)
            except (OSError, ValidationError, UnicodeDecodeError) as exc:
                message = getattr(exc, "message", None) or str(exc) or "Could not import that CSV."
                err_dest = _unique_path(folder / "failed", path.name)
                try:
                    path.replace(err_dest)
                    note = err_dest.with_suffix(err_dest.suffix + ".txt")
                    note.write_text(message + "\n", encoding="utf-8")
                except OSError:
                    pass
                failed.append({"file": path.name, "error": message})
        if imported or failed:
            _inbound_state["last_imported_at"] = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
            _inbound_state["imported"] = imported
            _inbound_state["failed"] = failed
    status = inbound_status()
    status["imported"] = imported
    status["failed"] = failed
    return status


def csv_dirs() -> List[Path]:
    dirs = []
    bundled = CSV_DIR
    extra = user_subdivisions_dir()
    if bundled.is_dir():
        dirs.append(bundled)
    if extra.is_dir() and extra.resolve() != bundled.resolve():
        dirs.append(extra)
    return dirs


def _dirs_mtime() -> float:
    latest = 0.0
    for folder in csv_dirs():
        try:
            latest = max(latest, folder.stat().st_mtime)
            for path in folder.glob("*.csv"):
                latest = max(latest, path.stat().st_mtime)
        except OSError:
            continue
    try:
        latest = max(latest, _hidden_path().stat().st_mtime)
    except OSError:
        pass
    return latest


_LOC_SUB_SPLIT = re.compile(r"\s*[·•]\s*")


def _looks_like_sub(text: str) -> bool:
    name = (text or "").strip()
    if not name:
        return False
    if re.search(r"\bsub(?:division)?\b", name, re.I):
        return True
    ensure_loaded()
    key = _sub_key(name)
    return any(_sub_key(display) == key or _sub_key(original) == key for _rrs, display, original, _name, _mp in STATIONS)


def infer_subdivision(location: str, railroad: str = "") -> str:
    ensure_loaded()
    needle = _n(spot_name(location))
    label_n = _n(location)
    if not needle:
        return ""
    rr_n = _n(railroad)
    found: List[str] = []
    seen = set()
    for rrs, display, original, name, mp in STATIONS:
        if rr_n and not any(_n(item) == rr_n for item in rrs):
            continue
        if _n(name) != needle and _n(location_label(name, mp)) != label_n:
            continue
        key = _sub_key(display)
        if key in seen:
            continue
        seen.add(key)
        found.append(display)
    if len(found) == 1:
        return found[0]
    return ""


def milepost_of(location: str) -> str:
    match = re.search(r"\(MP\s*([^)]+)\)\s*$", location or "", re.I)
    return match.group(1).strip() if match else ""


def _same_mp(a: str, b: str) -> bool:
    try:
        return abs(float(a) - float(b)) < 0.05
    except (TypeError, ValueError):
        return _n(a) == _n(b)


def station_subdivision_candidates(location: str, railroad: str = "", fuzzy: bool = False) -> List[str]:
    """Subdivisions with a station named like this location.

    A milepost in the location narrows exact matches to the subdivision
    where that station sits at that milepost.
    """
    ensure_loaded()
    needle = _n(spot_name(location))
    if len(needle) < 3:
        return []
    want_mp = milepost_of(location)
    rr_n = _n(railroad)
    exact: List[str] = []
    at_mp: List[str] = []
    loose: List[str] = []
    for rrs, display, _original, name, mp in STATIONS:
        if rr_n and not any(_n(item) == rr_n for item in rrs):
            continue
        hay = _n(name)
        if not hay:
            continue
        if hay == needle:
            if display not in exact:
                exact.append(display)
            if want_mp and mp and _same_mp(want_mp, mp) and display not in at_mp:
                at_mp.append(display)
        elif fuzzy and len(hay) >= 4 and (hay in needle or needle in hay):
            if display not in loose:
                loose.append(display)
    if at_mp:
        return at_mp
    if exact or not fuzzy:
        return exact
    return loose


_CORE_PREFIX = re.compile(r"^(?:(?:e|w|n|s)\s*o|east|west|north|south|e|w|n|s)\s+")
_CORE_SUFFIX = re.compile(r"\s+(?:jct|junction|rd|road|siding|yard|east|west|north|south)$")


def _core(name: str) -> str:
    """A station name without East/West/E O and Jct/Rd, for loose matching."""
    text = re.sub(r"[^a-z0-9]+", " ", spot_name(name).lower()).strip()
    for _ in range(2):
        text = _CORE_SUFFIX.sub("", _CORE_PREFIX.sub("", text)).strip()
    return text.replace(" ", "")


def station_state(location: str, railroad: str = "", subdivision: str = "", by_name_only: bool = False) -> str:
    """State of a station from the station book, or "" if unknown or unclear.

    A milepost in the location or a subdivision narrows same-named
    stations. A name with no exact match is tried without East/West or
    Jct/Rd (Flagstaff matches East and West Flagstaff). If those still
    disagree, the subdivision's own state is used when the whole
    subdivision is in one state (unless by_name_only).
    """
    ensure_loaded()
    want_mp = milepost_of(location)
    rr_n = _n(railroad)

    def states_in(rows: List[StationRow]) -> Tuple[List[str], List[str]]:
        found: List[str] = []
        at_mp: List[str] = []
        for rrs, display, original, name, mp in rows:
            if rr_n and not any(_n(item) == rr_n for item in rrs):
                continue
            if subdivision and not _same_sub(subdivision, display, original, rrs):
                continue
            state = STATION_STATES.get((display, name), "")
            if not state:
                continue
            found.append(state)
            if want_mp and mp and _same_mp(want_mp, mp):
                at_mp.append(state)
        return found, at_mp

    needle = _n(spot_name(location))
    if needle:
        found, at_mp = states_in(_BY_NAME.get(needle, []))
        if not found:
            core = _core(location)
            if len(core) >= 3:
                found, at_mp = states_in(_BY_CORE.get(core, []))
        for group in (at_mp, found):
            if group and len(set(group)) == 1:
                return group[0]
    if subdivision and not by_name_only:
        states = subdivision_states(subdivision, railroad)
        if len(states) == 1:
            return states[0]
    return ""


def subdivision_states(subdivision: str, railroad: str = "") -> List[str]:
    """States a subdivision runs through, most stations first."""
    ensure_loaded()
    key = (subdivision, railroad)
    if key in _SUB_STATES_CACHE:
        return list(_SUB_STATES_CACHE[key])
    rr_n = _n(railroad)
    counts: Dict[str, int] = defaultdict(int)
    for rrs, display, original, name, _mp in STATIONS:
        if rr_n and not any(_n(item) == rr_n for item in rrs):
            continue
        if not _same_sub(subdivision, display, original, rrs):
            continue
        state = STATION_STATES.get((display, name), "")
        if state:
            counts[state] += 1
    result = sorted(counts, key=lambda s: (-counts[s], s))
    _SUB_STATES_CACHE[key] = result
    return list(result)


def railroad_has_stations(railroad: str) -> bool:
    ensure_loaded()
    rr_n = _n(railroad)
    return bool(rr_n) and any(any(_n(item) == rr_n for item in rrs) for rrs, *_rest in STATIONS)


def resolve_location_fields(location: str, subdivision: str = "", railroad: str = "") -> Tuple[str, str]:
    """Keep location and subdivision as separate fields, even if a sheet combined them."""
    location = (location or "").strip()
    subdivision = (subdivision or "").strip()
    parts = [part.strip() for part in _LOC_SUB_SPLIT.split(location) if part.strip()]
    if len(parts) >= 2:
        left = parts[0]
        right = parts[-1]
        if _looks_like_sub(right):
            if not subdivision or _same_sub(subdivision, right, right):
                location, extra = left, right
                if not subdivision:
                    subdivision = extra
            elif not _looks_like_sub(left):
                location = left
    if not subdivision:
        subdivision = infer_subdivision(location, railroad)
    return location, subdivision


def with_milepost(location: str, railroad: str = "", subdivision: str = "") -> str:
    ensure_loaded()
    location = (location or "").strip()
    if not location or _MP_SUFFIX.search(location):
        return location
    rr_n = _n(railroad)
    needle = _n(location)
    matches = []
    for rrs, display, original, name, mp in STATIONS:
        if not mp:
            continue
        if rr_n and not any(_n(item) == rr_n for item in rrs):
            continue
        if _n(name) != needle:
            continue
        if subdivision and not _same_sub(subdivision, display, original, rrs):
            continue
        matches.append((rrs, display, original, name, mp))
    if not matches:
        return location
    if subdivision:
        preferred = [row for row in matches if _same_sub(subdivision, row[1], row[2], row[0])]
        if len(preferred) == 1:
            return location_label(preferred[0][3], preferred[0][4])
    unique_mp = {row[4] for row in matches}
    if len(unique_mp) == 1:
        return location_label(matches[0][3], matches[0][4])
    return location


def _cell(row: List[str], index: int) -> str:
    if index < 0 or index >= len(row):
        return ""
    return (row[index] or "").strip()


def _railroads_from_text(text: str) -> List[str]:
    cleaned = re.sub(r"(?i)\b(?:railroad|rr)\b", " ", text or "")
    found: List[str] = []
    seen = set()
    for token in _RR_SPLIT.split(cleaned):
        name = rr_mod.RR_ALIASES.get(token.upper().strip(" :.-"))
        if not name:
            mark = token.upper().strip(" :.-")
            if re.fullmatch(r"[A-Z][A-Z0-9]{1,5}", mark):
                name = mark
        if name and name not in seen:
            seen.add(name)
            found.append(name)
    return found


def _railroads_from_row(row: List[str]) -> List[str]:
    cells = [cell.strip() for cell in row if cell and cell.strip()]
    if not cells:
        return []
    found = _railroads_from_text(" ".join(cells))
    if found:
        return found
    for cell in cells:
        for name in _railroads_from_text(cell):
            if name not in found:
                found.append(name)
    return found


def _header_indexes(row: List[str]) -> Dict[str, int]:
    found: Dict[str, int] = {}
    for index, raw in enumerate(row):
        key = _HEADER_MAP.get(_n(raw))
        if key and key not in found:
            found[key] = index
    return found


def _read_csv_text(text: str) -> Tuple[List[str], List[Tuple[str, str, str, str]]]:
    rows = list(csv.reader((text or "").splitlines()))
    if len(rows) < 3:
        return [], []
    railroads = _railroads_from_row(rows[0])
    headers = _header_indexes(rows[1])
    if not railroads or "sub" not in headers or "spot" not in headers:
        return [], []
    mp_idx = headers.get("mp", -1)
    state_idx = headers.get("state", -1)
    stations = []
    for row in rows[2:]:
        sub = _cell(row, headers["sub"])
        spot = _cell(row, headers["spot"])
        mp = _cell(row, mp_idx) if mp_idx >= 0 else ""
        state = normalize_state(_cell(row, state_idx)) if state_idx >= 0 else ""
        if not sub or not spot:
            continue
        stations.append((sub, spot, mp, state))
    return railroads, stations


_CSV_CACHE: Dict[str, Tuple[Tuple[int, int], List[str], List[Tuple[str, str, str, str]]]] = {}


def _read_csv(path: Path) -> Tuple[List[str], List[Tuple[str, str, str, str]]]:
    key = str(path)
    try:
        info = path.stat()
        stamp = (info.st_mtime_ns, info.st_size)
    except OSError:
        _CSV_CACHE.pop(key, None)
        raise
    cached = _CSV_CACHE.get(key)
    if cached and cached[0] == stamp:
        return list(cached[1]), list(cached[2])
    railroads, rows = _read_csv_text(path.read_text(encoding="utf-8-sig"))
    _CSV_CACHE[key] = (stamp, list(railroads), list(rows))
    return railroads, rows


def _qualifier(owners: Tuple[str, ...]) -> str:
    for name in owners:
        if name in rr_mod.FREIGHT_RAILROADS:
            return name
    return owners[0] if owners else ""


def _hidden_path() -> Path:
    return user_subdivisions_dir() / ".hidden.json"


def hidden_filenames() -> set:
    path = _hidden_path()
    if not path.is_file():
        return set()
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return set()
    if not isinstance(data, list):
        return set()
    return {str(item) for item in data if item}


def _save_hidden(names: set) -> None:
    path = _hidden_path()
    folder = path.parent
    folder.mkdir(parents=True, exist_ok=True)
    cleaned = sorted(name for name in names if name)
    if not cleaned:
        if path.exists():
            path.unlink()
        return
    path.write_text(json.dumps(cleaned, indent=2) + "\n", encoding="utf-8")


def iter_csv_paths(*, include_hidden: bool = False) -> List[Path]:
    hidden = hidden_filenames()
    by_name: Dict[str, Path] = {}
    for folder in csv_dirs():
        for path in sorted(folder.glob("*.csv")):
            if not include_hidden and path.name in hidden:
                continue
            by_name[path.name] = path
    return [by_name[name] for name in sorted(by_name)]


def _load_csvs() -> Tuple[Dict[str, List[str]], List[StationRow], Dict[Tuple[str, str], str]]:
    order = rr_mod.RR_ORDER or ()
    grouped: Dict[str, List[str]] = {key: [] for key in order}
    parsed = []
    for path in iter_csv_paths():
        railroads, rows = _read_csv(path)
        if not railroads or not rows:
            continue
        original = rows[0][0]
        ordered = sort_locations_by_milepost(
            [{"sub": sub, "spot": spot, "mp": mp, "state": state} for sub, spot, mp, state in rows]
        )
        rows = [
            (item.get("sub") or original, item.get("spot") or "", item.get("mp") or "", item.get("state") or "")
            for item in ordered
        ]
        parsed.append((tuple(railroads), original, rows, path.name))
    name_groups: Dict[str, set] = defaultdict(set)
    for owners, original, _rows, _name in parsed:
        name_groups[original].add(owners)
    tags: Dict[Tuple[str, Tuple[str, ...]], str] = {}
    for original, group in name_groups.items():
        if len(group) < 2:
            continue
        for pick in (
            lambda o: _qualifier(o),
            lambda o: "/".join(r for r in o if r in rr_mod.FREIGHT_RAILROADS) or "/".join(o),
            lambda o: "/".join(o),
        ):
            trial = {owners: pick(owners) for owners in group}
            if len(set(trial.values())) == len(trial):
                break
        for owners, tag in trial.items():
            tags[(original, owners)] = tag
    stations: List[StationRow] = []
    states: Dict[Tuple[str, str], str] = {}
    seen_sub: Dict[str, set] = defaultdict(set)
    seen_sta = set()
    for owners, original, rows, _name in parsed:
        display = original
        tag = tags.get((original, owners), "")
        if tag:
            display = "{} ({})".format(original, tag)
        for railroad in owners:
            if display not in seen_sub[railroad]:
                seen_sub[railroad].add(display)
                grouped.setdefault(railroad, []).append(display)
        for _sub, spot, mp, state in rows:
            key = (owners, display, spot)
            if key in seen_sta:
                continue
            seen_sta.add(key)
            stations.append((owners, display, original, spot, mp))
            if state:
                states[(display, spot)] = state
    for key in order:
        grouped.setdefault(key, [])
    return grouped, stations, states


def ensure_loaded(force: bool = False) -> None:
    global SUBDIVISIONS, STATIONS, STATION_STATES, _CACHE_MTIME, _LOADED, _BY_NAME, _BY_CORE, _CHECKED_AT
    import time

    now = time.monotonic()
    if not force and _LOADED and now - _CHECKED_AT < _CHECK_SECONDS:
        return
    _CHECKED_AT = now
    stamp = (_dirs_mtime(), tuple(rr_mod.FREIGHT_RAILROADS or ()), tuple(rr_mod.RR_ORDER or ()))
    if not force and _LOADED and _CACHE_MTIME == stamp:
        return
    SUBDIVISIONS, STATIONS, STATION_STATES = _load_csvs()
    by_name: Dict[str, List[StationRow]] = defaultdict(list)
    by_core: Dict[str, List[StationRow]] = defaultdict(list)
    for row in STATIONS:
        by_name[_n(row[3])].append(row)
        by_core[_core(row[3])].append(row)
    _BY_NAME, _BY_CORE = dict(by_name), dict(by_core)
    _SUB_STATES_CACHE.clear()
    _CACHE_MTIME = stamp
    _LOADED = True


def reload_gazetteer() -> Dict[str, List[str]]:
    ensure_loaded(force=True)
    return grouped_subdivisions()


def import_subdivision_csv(filename: str, raw: bytes) -> Dict[str, Any]:
    from validators import ValidationError

    try:
        text = raw.decode("utf-8-sig")
    except UnicodeDecodeError as exc:
        raise ValidationError("Subdivision CSV must be UTF-8 text", "file") from exc
    railroads, rows = _read_csv_text(text)
    if not railroads or not rows:
        raise ValidationError(
            "CSV needs railroad names on row 1, then Subdivision, Location, Milepost",
            "file",
        )
    name = Path(filename or "subdivision.csv").name
    name = _SAFE_NAME.sub("-", name).strip(". -") or "subdivision.csv"
    if not name.lower().endswith(".csv"):
        name += ".csv"
    folder = user_subdivisions_dir()
    folder.mkdir(parents=True, exist_ok=True)
    dest = folder / name
    dest.write_text(text if text.endswith("\n") else text + "\n", encoding="utf-8")
    reload_gazetteer()
    original = rows[0][0]
    display = original
    for _rrs, shown, orig, _spot, _mp in STATIONS:
        if orig == original and set(_rrs) == set(railroads):
            display = shown
            break
    return {
        "filename": dest.name,
        "railroads": railroads,
        "subdivision": display,
        "stations": len(rows),
        "message": "Added {} ({} locations).".format(display, len(rows)),
    }


def grouped_subdivisions() -> Dict[str, List[str]]:
    ensure_loaded()
    keys = list(rr_mod.RR_ORDER) + [key for key in SUBDIVISIONS if key not in rr_mod.RR_ORDER]
    return {key: list(SUBDIVISIONS.get(key, [])) for key in keys}


def subdivision_location_counts() -> Dict[str, int]:
    ensure_loaded()
    counts: Dict[str, int] = {}
    for _rrs, display, _original, _name, _mp in STATIONS:
        counts[display] = counts.get(display, 0) + 1
    return counts


def list_subdivisions(railroad: str = "", query: str = "", limit: int = 400) -> List[Dict[str, Any]]:
    q = (query or "").strip().lower()
    rr = (railroad or "").strip().upper()
    out = []
    grouped = grouped_subdivisions()
    keys = [rr] if rr in grouped else list(grouped.keys())
    for key in keys:
        for name in grouped[key]:
            if q and q not in name.lower() and q not in key.lower():
                continue
            out.append({"railroad": key, "name": name})
            if len(out) >= limit:
                return out
    return out


def search_stations(
    railroad: str = "",
    subdivision: str = "",
    query: str = "",
    limit: Optional[int] = None,
) -> List[Dict[str, Any]]:
    ensure_loaded()
    if limit is None:
        limit = None if subdivision else 24
    rr_n = _n(railroad)
    q_n = _n(query)
    scored = []
    for rrs, display, original, name, mp in STATIONS:
        if rr_n and not any(_n(item) == rr_n for item in rrs):
            continue
        if subdivision and not _same_sub(subdivision, display, original, rrs):
            continue
        hay = _n(name + display + original + (mp or ""))
        if q_n and q_n not in hay:
            continue
        score = 0
        if subdivision and _n(subdivision) == _n(display):
            score += 5
        if q_n and _n(name).startswith(q_n):
            score += 3
        label = location_label(name, mp)
        shown_rr = next((item for item in rrs if _n(item) == rr_n), rrs[0]) if rrs else ""
        scored.append(
            (
                score,
                name,
                {
                    "railroad": shown_rr,
                    "railroads": list(rrs),
                    "location_spot": label,
                    "location_spot_label": label,
                    "location_subdivision": display,
                    "location_state": STATION_STATES.get((display, name), ""),
                    "milepost": mp or None,
                    "source": "csv",
                },
            )
        )
    scored.sort(key=lambda item: (-item[0], item[1]))
    out = []
    seen = set()
    for _score, _name, row in scored:
        key = (row["location_subdivision"], row["location_spot"])
        if key in seen:
            continue
        seen.add(key)
        out.append(row)
        if limit is not None and len(out) >= limit:
            break
    return out


def resolve_csv(filename: str) -> Optional[Path]:
    name = Path(filename or "").name
    if not name or name.startswith("."):
        return None
    for path in iter_csv_paths(include_hidden=True):
        if path.name == name:
            return path
    return None


def _safe_csv_name(railroads: List[str], subdivision: str, filename: str = "") -> str:
    if filename:
        name = Path(filename).name
        name = _SAFE_NAME.sub("-", name).strip(". -") or "subdivision.csv"
        if not name.lower().endswith(".csv"):
            name += ".csv"
        return name
    prefix = (railroads[0] if railroads else "RR").replace(" ", "")
    base = _SAFE_NAME.sub("-", "{}-{}".format(prefix, subdivision or "Sub")).strip(" -")
    name = (base or "subdivision") + ".csv"
    existing = {path.name.lower() for path in iter_csv_paths(include_hidden=True)}
    if name.lower() not in existing:
        return name
    for index in range(2, 50):
        candidate = "{}-{}.csv".format(base, index)
        if candidate.lower() not in existing:
            return candidate
    return "{}-{}.csv".format(base, "new")


def milepost_value(mp: str) -> Optional[float]:
    match = re.search(r"-?\d+(?:\.\d+)?", str(mp or ""))
    if not match:
        return None
    try:
        return float(match.group())
    except ValueError:
        return None


def milepost_sort_descending(values: List[Optional[float]]) -> bool:
    """Infer list direction from consecutive steps (majority), not just endpoints.

    Endpoint-only detection flips the whole list when one bad milepost sits at
    either end (e.g. a mistyped East Seligman MP of 247.7 on an ascending sub).
    """
    numbered = [value for value in values if value is not None]
    if len(numbered) < 2:
        return False
    ups = downs = 0
    prev: Optional[float] = None
    for value in values:
        if value is None:
            continue
        if prev is not None:
            if value > prev:
                ups += 1
            elif value < prev:
                downs += 1
        prev = value
    if ups == downs:
        return numbered[0] > numbered[-1]
    return downs > ups


def sort_locations_by_milepost(locations: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    rows = [dict(row) for row in locations or []]
    values = [milepost_value(row.get("mp") or row.get("milepost") or "") for row in rows]
    descending = milepost_sort_descending(values)

    def key(item: Tuple[int, Dict[str, Any], Optional[float]]) -> Tuple[int, float, int]:
        index, _row, value = item
        if value is None:
            return (1, 0.0, index)
        return (0, -value if descending else value, index)

    ranked = [(index, row, values[index]) for index, row in enumerate(rows)]
    ranked.sort(key=key)
    return [row for _index, row, _value in ranked]


def write_subdivision_csv(path: Path, railroads: List[str], subdivision: str, locations: List[Dict[str, Any]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    handle = io.StringIO()
    writer = csv.writer(handle)
    writer.writerow([" or ".join(railroads), "", "", ""])
    writer.writerow(["Subdivision", "Location", "Milepost", "State"])
    for row in locations:
        spot = str(row.get("spot") or row.get("location") or "").strip()
        mp = str(row.get("mp") or row.get("milepost") or "").strip()
        state = normalize_state(row.get("state"))
        if not spot:
            continue
        writer.writerow([subdivision, spot, mp, state])
    text = handle.getvalue()
    if not text.endswith("\n"):
        text += "\n"
    path.write_text(text, encoding="utf-8")


def catalog_items() -> List[Dict[str, Any]]:
    ensure_loaded()
    hidden = hidden_filenames()
    user_dir = user_subdivisions_dir().resolve()
    bundled = CSV_DIR.resolve() if CSV_DIR.is_dir() else None
    items = []
    shown_by_key: Dict[Tuple[str, Tuple[str, ...]], str] = {}
    for rrs, shown, orig, _spot, _mp in STATIONS:
        shown_by_key.setdefault((orig, tuple(rrs)), shown)
    for path in iter_csv_paths(include_hidden=True):
        railroads, rows = _read_csv(path)
        if not railroads or not rows:
            continue
        original = rows[0][0]
        display = shown_by_key.get((original, tuple(railroads)), original)
        resolved = path.resolve()
        source = "user"
        if bundled and resolved.parent == bundled:
            source = "bundled"
        elif resolved.parent == user_dir:
            source = "user"
            if bundled and (CSV_DIR / path.name).is_file() and path.name not in hidden:
                source = "edited"
        items.append(
            {
                "id": path.name,
                "filename": path.name,
                "subdivision": display,
                "original": original,
                "railroads": railroads,
                "locations": len(rows),
                "source": source,
                "hidden": path.name in hidden,
            }
        )
    items.sort(key=lambda item: (item["subdivision"].lower(), item["filename"].lower()))
    return items


def get_subdivision(filename: str) -> Dict[str, Any]:
    from validators import ValidationError

    path = resolve_csv(filename)
    if path is None:
        raise ValidationError("Subdivision file not found", "filename")
    railroads, rows = _read_csv(path)
    if not railroads or not rows:
        raise ValidationError("Could not read that subdivision CSV", "filename")
    matching = [item for item in catalog_items() if item["filename"] == path.name]
    meta = matching[0] if matching else {}
    return {
        "filename": path.name,
        "subdivision": meta.get("subdivision") or rows[0][0],
        "railroads": railroads,
        "source": meta.get("source") or "user",
        "locations": sort_locations_by_milepost(
            [{"spot": spot, "mp": mp, "state": state} for _sub, spot, mp, state in rows]
        ),
    }


def save_subdivision(
    filename: str,
    railroads: List[str],
    subdivision: str,
    locations: List[Dict[str, Any]],
    create: bool = False,
) -> Dict[str, Any]:
    from validators import ValidationError

    roads = [str(item).strip().upper() for item in railroads or [] if str(item).strip()]
    name = (subdivision or "").strip()
    spots = [row for row in locations or [] if str(row.get("spot") or row.get("location") or "").strip()]
    if not roads:
        raise ValidationError("Pick at least one railroad", "railroads")
    if not name:
        raise ValidationError("Subdivision name is required", "subdivision")
    if not spots:
        raise ValidationError("Add at least one location", "locations")
    spots = sort_locations_by_milepost(spots)
    dest_name = _safe_csv_name(roads, name, filename if not create else "")
    dest = user_subdivisions_dir() / dest_name
    hidden = hidden_filenames()
    if dest_name in hidden:
        hidden.discard(dest_name)
        _save_hidden(hidden)
    write_subdivision_csv(dest, roads, name, spots)
    reload_gazetteer()
    detail = get_subdivision(dest_name)
    detail["message"] = "Saved {} ({} locations).".format(detail["subdivision"], len(detail["locations"]))
    return detail


def delete_subdivision(filename: str) -> Dict[str, Any]:
    from validators import ValidationError

    name = Path(filename or "").name
    if not name or name.startswith("."):
        raise ValidationError("Subdivision file not found", "filename")
    user = user_subdivisions_dir() / name
    bundled = CSV_DIR / name
    found = user.is_file() or bundled.is_file() or name in hidden_filenames()
    if not found:
        raise ValidationError("Subdivision file not found", "filename")
    if user.is_file():
        user.unlink()
    if bundled.is_file():
        hidden = hidden_filenames()
        hidden.add(name)
        _save_hidden(hidden)
    reload_gazetteer()
    return {"success": True, "filename": name, "message": "Removed {}.".format(name)}


def hide_subdivision(filename: str) -> Dict[str, Any]:
    from validators import ValidationError

    name = Path(filename or "").name
    if not name or name.startswith("."):
        raise ValidationError("Subdivision file not found", "filename")
    user = user_subdivisions_dir() / name
    bundled = CSV_DIR / name
    if not user.is_file() and not bundled.is_file():
        raise ValidationError("Subdivision file not found", "filename")
    hidden = hidden_filenames()
    hidden.add(name)
    _save_hidden(hidden)
    reload_gazetteer()
    return {"success": True, "filename": name, "hidden": True, "message": "Hid {}.".format(name)}


def unhide_subdivision(filename: str) -> Dict[str, Any]:
    from validators import ValidationError

    name = Path(filename or "").name
    if not name or name.startswith("."):
        raise ValidationError("Subdivision file not found", "filename")
    hidden = hidden_filenames()
    if name not in hidden:
        raise ValidationError("That subdivision is not hidden", "filename")
    hidden.discard(name)
    _save_hidden(hidden)
    reload_gazetteer()
    return {"success": True, "filename": name, "hidden": False, "message": "Showing {} again.".format(name)}


def restore_shipped_subdivisions() -> Dict[str, Any]:
    from datetime import datetime

    user_dir = user_subdivisions_dir()
    edited = []
    if CSV_DIR.is_dir() and user_dir.resolve() != CSV_DIR.resolve():
        edited = sorted(
            path for path in user_dir.glob("*.csv") if path.is_file() and (CSV_DIR / path.name).is_file()
        )
    backup = None
    if edited:
        backup = support_dir() / "subdivision-backups" / datetime.now().strftime("%Y%m%d-%H%M%S")
        backup.mkdir(parents=True, exist_ok=True)
        for path in edited:
            path.replace(_unique_path(backup, path.name))
    unhidden = sorted(hidden_filenames())
    _save_hidden(set())
    reload_gazetteer()
    parts = []
    if edited:
        parts.append("{} edited shipped file{} put back".format(len(edited), "" if len(edited) == 1 else "s"))
    if unhidden:
        parts.append("{} hidden file{} shown again".format(len(unhidden), "" if len(unhidden) == 1 else "s"))
    message = "Restored the shipped subdivision list: " + ", ".join(parts) + "." if parts else "The shipped subdivision list was already in place."
    return {
        "success": True,
        "restored": [path.name for path in edited],
        "unhidden": unhidden,
        "backup": str(backup) if backup else "",
        "message": message,
    }


ensure_loaded()
