"""Read freight train symbols and passenger train numbers back as plain text."""
from __future__ import annotations

import json
import re
from functools import lru_cache
from typing import Any, Dict, Optional

from data_updates import reference_path


@lru_cache(maxsize=None)
def _load(name: str) -> Dict[str, Any]:
    path = reference_path(name)
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return {"railroads": {}}


def freight_book() -> Dict[str, Any]:
    return _load("freight_symbols.json")


def passenger_book() -> Dict[str, Any]:
    return _load("passenger_trains.json")


def _book(books: Dict[str, Any], railroad: str) -> Any:
    """A railroad's entry, found under its own mark or any other mark for the same railroad."""
    import railroads as rr_mod

    rr = (railroad or "").strip().upper()
    if rr in books:
        return books[rr]
    canon = rr_mod.canonical_mark(rr)
    for mark in [canon] + [a for a, m in rr_mod.mark_aliases().items() if m == canon]:
        if mark in books:
            return books[mark]
    return None


def _norm(text: str) -> str:
    return re.sub(r"[^A-Z0-9]", "", str(text or "").upper())


def _series_key(rr: str, key: str, series: Dict[str, str]) -> str:
    if rr == "NS" and key[:1].isdigit():
        return key[0] + "xx"
    if len(key) > 1 and key[:2] in series:
        return key[:2]
    return key[:1]


def _place_text(origin: str, dest: str) -> str:
    if origin and dest:
        return "{} → {}".format(origin, dest)
    return origin or dest


_TYPE_HINTS = (
    (("coal",), "COAL"),
    (("grain",), "GRAIN"),
    (("intermodal", "stack"), "CON"),
    (("vehicle", "automotive"), "AUTO"),
    (("baretable",), "BR TBL"),
    (("ethanol",), "ETH-GAS"),
    (("manifest", "merchandise"), "MIXED"),
    (("lite power", "power move", "light engine"), "LGT PWR"),
    (("helper",), "LGT HLP"),
    (("work train",), "MOW"),
    (("passenger", "amtrak"), "PASS"),
    (("office car",), "OCS"),
)


def suggest_types(series_label: str) -> Dict[str, Any]:
    """Train types and Loads/Empties a symbol series points to, e.g. BNSF C (Loaded Coal) -> COAL, Loads."""
    text = (series_label or "").lower()
    types = []
    for words, train_type in _TYPE_HINTS:
        if any(word in text for word in words) and train_type not in types:
            types.append(train_type)
    loads = "Loads" if "loaded" in text else "Empties" if "empty" in text else ""
    return {"types": types, "loads": loads}


def decode_symbol(railroad: str, symbol: str) -> Optional[Dict[str, Any]]:
    """Explain a train symbol, matching the longest listed symbol at its start.

    Symbols are typed with dates and section digits (Q-LACCIC1-23), so the list
    entry is the longest prefix of the typed text. Unlisted symbols still get the
    series letter, and BNSF/UP origin and destination from their station codes.
    """
    books = freight_book().get("railroads", {})
    book = _book(books, railroad)
    rr = next((mark for mark, value in books.items() if value is book), (railroad or "").strip().upper())
    key = _norm(symbol)
    if not book or not key:
        return None
    series = book.get("series", {})
    symbols = book.get("symbols", {})
    for end in range(len(key), 2, -1):
        row = symbols.get(key[:end])
        if row:
            listed, series_key, origin, dest, frequency, notes = row
            label = series.get(series_key, "")
            text = " · ".join(part for part in (
                "{} {}".format(listed, label).strip() if label else listed,
                _place_text(origin, dest),
                frequency,
                notes,
            ) if part)
            return {
                "listed": True, "symbol": listed, "series_key": series_key, "series": label, "origin": origin,
                "destination": dest, "frequency": frequency, "notes": notes, "text": text, **suggest_types(label),
            }
    series_key = _series_key(rr, key, series)
    label = series.get(series_key, "") or series.get(key[:1], "")
    origin = dest = ""
    usual = ""
    if rr == "CSX" and len(key) >= 4 and key[1] in "89" and key[2:4].isdigit():
        label = "{}, {}".format(label or key[:1], "curfewed (track work)" if key[1] == "8" else "rerouted")
        bases = [key[0] + d + key[2:4] for d in "01234567" if key[0] + d + key[2:4] in symbols]
        if len(bases) == 1:
            row = symbols[bases[0]]
            usual = "usually {}".format(row[0])
            origin, dest = row[2], row[3]
    codes = book.get("codes", {})
    width = {"BNSF": 3, "UP": 2}.get(rr)
    if width and codes:
        origin = codes.get(key[1:1 + width], "")
        dest = codes.get(key[1 + width:1 + 2 * width], "")
    if not (label or origin or dest):
        return None
    text = " · ".join(part for part in (
        "{} series: {}".format(series_key if series_key.endswith("xx") else key[:1], label) if label else "",
        usual,
        _place_text(origin, dest),
        "" if usual else "not in the symbol list",
    ) if part)
    return {
        "listed": False, "symbol": "", "series_key": series_key if label else "", "series": label, "origin": origin,
        "destination": dest, "frequency": "", "notes": "", "text": text, **suggest_types(label),
    }


def symbol_base(symbol: str) -> str:
    """The typed symbol without its trailing date, so Q-LACCHI1-23 and Q-LACCHI1-24 count together."""
    text = re.sub(r"\s+", "", str(symbol or "").upper())
    trimmed = re.sub(r"-\d{1,2}$", "", text)
    return trimmed or text


def symbol_stats_parts(railroad: str, symbol: str) -> Dict[str, Any]:
    rr = (railroad or "").strip().upper()
    found = decode_symbol(rr, symbol) or {}
    base = found.get("symbol") if found.get("listed") else symbol_base(symbol)
    series = ""
    if found.get("series"):
        key = found.get("series_key") or ""
        series = "{} {}: {}".format(rr, key, found["series"]).replace("  ", " ").strip()
    if found.get("listed"):
        check = "In the symbol list"
    elif _book(freight_book().get("railroads", {}), rr) is not None:
        check = "Not in the symbol list"
    else:
        check = "No symbol list for this railroad"
    return {
        "base": base,
        "series": series,
        "origin": found.get("origin") or "",
        "destination": found.get("destination") or "",
        "check": check,
    }


def decode_train_number(railroad: str, number: str) -> Optional[Dict[str, Any]]:
    trains = _book(passenger_book().get("railroads", {}), railroad)
    digits = re.sub(r"\D", "", str(number or ""))
    if not trains or not digits:
        return None
    row = trains.get(str(int(digits)))
    if not row:
        return None
    route, origin, dest = row
    return {
        "route": route, "origin": origin, "destination": dest,
        "text": " · ".join(part for part in (route, _place_text(origin, dest)) if part),
    }


def read_symbol(railroad: str, symbol: str, number: str = "") -> Optional[Dict[str, Any]]:
    """A freight symbol, or a passenger/commuter train number typed in the Symbol box.

    Skips the number when the Train # box already holds it, so it reads back once.
    """
    found = decode_symbol(railroad, symbol)
    key = _norm(symbol)
    if found or not re.fullmatch(r"\d{1,5}", key):
        return found
    if key.lstrip("0") == re.sub(r"\D", "", str(number or "")).lstrip("0"):
        return None
    found = decode_train_number(railroad, key)
    if found:
        found.update({"types": ["PASS"], "loads": ""})
    return found


def reference_text(railroad: str, symbol: str, number: str) -> str:
    parts = []
    if symbol:
        found = read_symbol(railroad, symbol, number)
        if found and found.get("text"):
            parts.append(found["text"])
    if number:
        found = decode_train_number(railroad, number)
        if found and found.get("text"):
            parts.append(found["text"])
    return " — ".join(parts)


REFERENCE_KINDS = ("passenger", "freight", "series", "codes")


def _reference_marks(kind: str) -> list:
    if kind == "passenger":
        books = passenger_book().get("railroads", {})
        return [{"railroad": rr, "count": len(rows)} for rr, rows in books.items()]
    key = {"freight": "symbols", "series": "series", "codes": "codes"}[kind]
    books = freight_book().get("railroads", {})
    return [
        {"railroad": rr, "count": len(book.get(key, {}))}
        for rr, book in books.items()
        if book.get(key)
    ]


def _reference_table(kind: str, rr: str) -> list:
    if kind == "passenger":
        trains = passenger_book().get("railroads", {}).get(rr, {})
        return [
            [number, route, origin, dest]
            for number, (route, origin, dest) in sorted(trains.items(), key=lambda kv: int(kv[0]))
        ]
    book = freight_book().get("railroads", {}).get(rr, {})
    series = book.get("series", {})
    if kind == "series":
        return [[key, label] for key, label in sorted(series.items())]
    if kind == "codes":
        return [[code, place] for code, place in sorted(book.get("codes", {}).items())]
    return [
        [listed, series.get(series_key, series_key), origin, dest, frequency, notes]
        for listed, series_key, origin, dest, frequency, notes in sorted(
            book.get("symbols", {}).values(), key=lambda row: row[0]
        )
    ]


def reference_rows(kind: str, railroad: str = "", query: str = "", limit: int = 400) -> Dict[str, Any]:
    """List the shipped reference data for review: one railroad, filtered by a search."""
    kind = kind if kind in REFERENCE_KINDS else "passenger"
    marks = _reference_marks(kind)
    names = [row["railroad"] for row in marks]
    rr = (railroad or "").strip().upper()
    if rr not in names:
        rr = names[0] if names else ""
    rows = _reference_table(kind, rr) if rr else []
    needle = (query or "").strip().lower()
    if needle:
        rows = [row for row in rows if any(needle in str(cell).lower() for cell in row)]
    book = passenger_book() if kind == "passenger" else freight_book()
    return {
        "kind": kind,
        "railroad": rr,
        "railroads": marks,
        "built": book.get("built", ""),
        "source": book.get("source", ""),
        "total": len(rows),
        "rows": rows[: max(1, limit)],
    }


def entry_reference(entry: Dict[str, Any]) -> Dict[str, str]:
    rr = entry.get("railroad") or ""
    found = {}
    symbol = read_symbol(rr, entry.get("train_symbol") or "", entry.get("train_number") or "") if entry.get("train_symbol") else None
    if symbol:
        found["symbol_info"] = symbol["text"]
    number = decode_train_number(rr, entry.get("train_number") or "") if entry.get("train_number") else None
    if number:
        found["train_number_info"] = number["text"]
    return found
