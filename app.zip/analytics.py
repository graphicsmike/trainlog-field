"""Deeper Log Stats: streaks, milestones, collection progress, running totals,
gaps between trains, averages by group, repeat lead locos, and sightings by milepost."""
from __future__ import annotations

import re
from collections import defaultdict
from datetime import date as _date, timedelta
from typing import Any, Dict, List, Optional, Tuple

TRAIN_MILESTONES = (1, 10, 25, 50, 100, 250, 500, 750, 1000, 1500, 2000, 2500, 3000, 4000, 5000, 7500, 10000)
DAY_MILESTONES = (1, 10, 25, 50, 100, 200, 300, 500, 750, 1000)
GAP_BUCKETS = ((0, 10, "Under 10 min"), (10, 20, "10–19 min"), (20, 30, "20–29 min"), (30, 45, "30–44 min"),
               (45, 60, "45–59 min"), (60, 120, "1–2 hours"), (120, 241, "2–4 hours"))
SESSION_BREAK = 240
MONTH_NAMES = ("Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec")


def _get(entry: Any, field: str) -> str:
    return str(getattr(entry, field, "") or "").strip()


def _minutes(time_str: str) -> Optional[int]:
    match = re.match(r"^(\d{1,2}):(\d{2})", time_str or "")
    if not match:
        return None
    hour, minute = int(match.group(1)), int(match.group(2))
    if hour > 23 or minute > 59:
        return None
    return hour * 60 + minute


def _parse(day: str) -> Optional[_date]:
    try:
        return _date.fromisoformat(day)
    except (TypeError, ValueError):
        return None


def _order(entry: Any) -> Tuple[str, str, int]:
    return (_get(entry, "date"), _get(entry, "time"), int(getattr(entry, "id", 0) or 0))


def _lead_mark(lead: str) -> str:
    match = re.match(r"^([A-Z&]+)", lead.upper())
    return match.group(1) if match else ""


def _car_total(text: str) -> int:
    return sum(int(part) for part in re.findall(r"\d+", text or ""))


def _ordinal(n: int) -> str:
    suffix = "th" if 10 <= n % 100 <= 20 else {1: "st", 2: "nd", 3: "rd"}.get(n % 10, "th")
    return "{:,}{}".format(n, suffix)


def _sighting(entry: Any) -> Dict[str, Any]:
    return {
        "date": _get(entry, "date"),
        "time": _get(entry, "time"),
        "railroad": _get(entry, "railroad"),
        "lead": _get(entry, "lead_locomotive"),
        "location": _get(entry, "location_spot"),
        "id": getattr(entry, "id", None),
    }


def streaks(days: List[str], today: Optional[_date] = None) -> Dict[str, Any]:
    """Longest run of days in a row trackside, and the run that is still going."""
    parsed = sorted({d for d in (_parse(day) for day in days) if d})
    empty = {"days": 0, "from": "", "to": ""}
    if not parsed:
        return {"longest": dict(empty), "current": dict(empty)}
    runs = []
    start = prev = parsed[0]
    for day in parsed[1:]:
        if day - prev == timedelta(days=1):
            prev = day
            continue
        runs.append((start, prev))
        start = prev = day
    runs.append((start, prev))
    best = max(runs, key=lambda run: ((run[1] - run[0]).days, run[1]))
    last = runs[-1]
    today = today or _date.today()
    alive = (today - last[1]).days <= 1

    def pack(run: Tuple[_date, _date]) -> Dict[str, Any]:
        return {"days": (run[1] - run[0]).days + 1, "from": run[0].isoformat(), "to": run[1].isoformat()}

    return {"longest": pack(best), "current": pack(last) if alive else dict(empty)}


def milestones(entries: List[Any]) -> List[Dict[str, Any]]:
    """The 1st, 10th, 100th… train and day trackside, oldest first."""
    rows: List[Dict[str, Any]] = []
    ordered = sorted(entries, key=_order)
    for n in TRAIN_MILESTONES:
        if n <= len(ordered):
            rows.append(dict(_sighting(ordered[n - 1]), label="{} train".format(_ordinal(n)), kind="train", n=n))
    first_of_day: Dict[str, Any] = {}
    for entry in ordered:
        day = _get(entry, "date")
        if day and day not in first_of_day:
            first_of_day[day] = entry
    days = sorted(first_of_day)
    for n in DAY_MILESTONES:
        if n <= len(days):
            rows.append(dict(_sighting(first_of_day[days[n - 1]]), label="{} day trackside".format(_ordinal(n)), kind="day", n=n))
    firsts: Dict[str, Any] = {}
    for entry in ordered:
        rr = _get(entry, "railroad")
        if rr and rr not in firsts:
            firsts[rr] = entry
    for rr, entry in firsts.items():
        rows.append(dict(_sighting(entry), label="First {} train".format(rr), kind="first", n=0))
    rows.sort(key=lambda row: (row["date"], row["time"], row["id"] or 0))
    return rows


def gaps(entries: List[Any]) -> Dict[str, Any]:
    """Minutes between trains at the same spot on the same day.

    A wait over four hours counts as leaving and coming back, so it starts a new
    session instead of stretching the average.
    """
    sessions: Dict[Tuple[str, str], List[Tuple[int, int]]] = defaultdict(list)
    for entry in entries:
        minute = _minutes(_get(entry, "time"))
        day = _get(entry, "date")
        if minute is None or not day:
            continue
        sessions[(day, _get(entry, "location_spot").lower())].append((minute, int(getattr(entry, "id", 0) or 0)))
    labels: Dict[int, str] = {}
    counts: Dict[str, int] = defaultdict(int)
    waits: List[int] = []
    longest: Optional[Tuple[int, str]] = None
    span_minutes = 0
    span_trains = 0
    by_spot: Dict[str, List[int]] = defaultdict(lambda: [0, 0])
    spot_names: Dict[str, str] = {}
    for entry in entries:
        spot = _get(entry, "location_spot")
        if spot:
            spot_names.setdefault(spot.lower(), spot)
    for (day, spot), stamps in sessions.items():
        stamps.sort()
        times = [minute for minute, _id in stamps]
        ids = [entry_id for _minute, entry_id in stamps]
        run_start = times[0]
        run_count = 1
        prev = times[0]
        for index, minute in enumerate(times[1:] + [None], start=1):
            if minute is not None and minute - prev <= SESSION_BREAK:
                wait = minute - prev
                waits.append(wait)
                for low, high, label in GAP_BUCKETS:
                    if low <= wait < high:
                        counts[label] += 1
                        labels[ids[index]] = label
                        break
                if longest is None or wait > longest[0]:
                    longest = (wait, day)
                prev = minute
                run_count += 1
                continue
            if run_count > 1 and prev > run_start:
                span_minutes += prev - run_start
                span_trains += run_count - 1
                by_spot[spot][0] += run_count - 1
                by_spot[spot][1] += prev - run_start
            if minute is not None:
                run_start = prev = minute
                run_count = 1
    per_hour = [
        {"location": spot_names.get(spot, spot) or "No location", "per_hour": round(trains * 60 / minutes, 1),
         "waits": trains, "hours": round(minutes / 60, 1)}
        for spot, (trains, minutes) in by_spot.items()
        if minutes >= 30 and trains >= 2
    ]
    per_hour.sort(key=lambda row: (-row["per_hour"], row["location"]))
    return {
        "buckets": [{"gap": label, "trains": counts[label]} for _low, _high, label in GAP_BUCKETS if counts.get(label)],
        "average": round(sum(waits) / len(waits)) if waits else None,
        "longest": {"minutes": longest[0], "date": longest[1]} if longest else None,
        "per_hour": round(span_trains * 60 / span_minutes, 1) if span_minutes else None,
        "per_hour_locations": per_hour[:25],
        "labels": labels,
    }


def gap_labels(entries: List[Any]) -> Dict[int, str]:
    """For each train that ended a wait, the wait band it falls in (by entry id)."""
    return gaps(entries)["labels"]


def month_label(day: str) -> str:
    parsed = _parse(day)
    return "{} {}".format(MONTH_NAMES[parsed.month - 1], parsed.year) if parsed else ""


def first_leads(entries: List[Any]) -> Dict[int, str]:
    """The train each numbered lead loco was first seen leading, with that month (by entry id)."""
    seen = set()
    firsts: Dict[int, str] = {}
    for entry in sorted(entries, key=_order):
        lead = _get(entry, "lead_locomotive").upper()
        month = month_label(_get(entry, "date"))
        if not month or not re.search(r"\d", lead) or lead in seen:
            continue
        seen.add(lead)
        firsts[int(getattr(entry, "id", 0) or 0)] = month
    return firsts


def new_leads_by_month(entries: List[Any]) -> List[Dict[str, Any]]:
    counts: Dict[str, int] = defaultdict(int)
    order: List[str] = []
    for month in first_leads(entries).values():
        if month not in counts:
            order.append(month)
        counts[month] += 1
    return [{"month": month, "trains": counts[month]} for month in order]


def _wait_text(minutes: Optional[int]) -> str:
    if minutes is None:
        return "—"
    if minutes < 60:
        return "{} min".format(minutes)
    return "{} hr {} min".format(minutes // 60, minutes % 60) if minutes % 60 else "{} hr".format(minutes // 60)


def running_totals(entries: List[Any]) -> List[Dict[str, Any]]:
    """Month by month: trains so far, and different lead locos, railroads, and locations seen so far."""
    locos, roads, spots = set(), set(), set()
    trains = 0
    rows: List[Dict[str, Any]] = []
    for entry in sorted(entries, key=_order):
        month = _get(entry, "date")[:7]
        if not month:
            continue
        trains += 1
        lead = _get(entry, "lead_locomotive").upper()
        if re.search(r"\d", lead):
            locos.add(lead)
        if _get(entry, "railroad"):
            roads.add(_get(entry, "railroad").upper())
        if _get(entry, "location_spot"):
            spots.add(_get(entry, "location_spot").lower())
        point = {"month": month, "trains": trains, "locos": len(locos), "railroads": len(roads), "locations": len(spots)}
        if rows and rows[-1]["month"] == month:
            rows[-1] = point
        else:
            rows.append(point)
    return rows


def averages(entries: List[Any]) -> Dict[str, List[Dict[str, Any]]]:
    """Per railroad and per train type: average cars and head-end units, and how often DP and photos happen."""
    def blank() -> Dict[str, Any]:
        return {"trains": 0, "cars": [], "units": [], "dp": 0, "consists": 0, "photos": 0}

    buckets: Dict[str, Dict[str, Dict[str, Any]]] = {"railroad": defaultdict(blank), "type": defaultdict(blank)}
    for entry in entries:
        cars = _car_total(_get(entry, "car_counts"))
        parts = [int(p) for p in _get(entry, "power_consist").split("x") if p.isdigit()]
        types = [t for t in (getattr(entry, "train_types", None) or []) if t]
        keys = {"railroad": [_get(entry, "railroad") or "Unknown"], "type": types or ["No type"]}
        for group, names in keys.items():
            for name in names:
                row = buckets[group][name]
                row["trains"] += 1
                if cars:
                    row["cars"].append(cars)
                if parts:
                    row["consists"] += 1
                    row["units"].append(parts[0])
                    if sum(parts[1:]):
                        row["dp"] += 1
                if getattr(entry, "photographed", False):
                    row["photos"] += 1

    def finish(name: str, row: Dict[str, Any]) -> Dict[str, Any]:
        return {
            "name": name,
            "trains": row["trains"],
            "avg_cars": round(sum(row["cars"]) / len(row["cars"])) if row["cars"] else None,
            "avg_units": round(sum(row["units"]) / len(row["units"]), 1) if row["units"] else None,
            "dp_pct": round(100 * row["dp"] / row["consists"]) if row["consists"] else None,
            "photo_pct": round(100 * row["photos"] / row["trains"]) if row["trains"] else None,
        }

    return {
        group: sorted((finish(name, row) for name, row in rows.items()), key=lambda r: (-r["trains"], r["name"]))
        for group, rows in buckets.items()
    }


def lead_repeats(entries: List[Any]) -> List[Dict[str, Any]]:
    """Numbered lead locos seen leading more than once, with the days and places."""
    seen: Dict[str, List[Any]] = defaultdict(list)
    for entry in entries:
        lead = _get(entry, "lead_locomotive").upper()
        if re.search(r"\d", lead):
            seen[lead].append(entry)
    rows = []
    for lead, items in seen.items():
        if len(items) < 2:
            continue
        items.sort(key=_order)
        rows.append({
            "lead": lead,
            "trains": len(items),
            "days": len({_get(e, "date") for e in items if _get(e, "date")}),
            "first": _get(items[0], "date"),
            "last": _get(items[-1], "date"),
            "places": sorted({_get(e, "location_spot") for e in items if _get(e, "location_spot")})[:4],
        })
    rows.sort(key=lambda row: (-row["trains"], row["lead"]))
    return rows


def collection(entries: List[Any]) -> Dict[str, Any]:
    """How much of each list has been seen: heritage units, America 250, steam, railroads, and stations."""
    import railroads as rr_mod
    import special_power
    import stations

    logged_units = {"heritage": set(), "steam": set()}
    for entry in entries:
        special = special_power.normalize_special_power(getattr(entry, "special_power", None) or "")
        for item in special["heritage"]:
            if item["unit"]:
                logged_units["heritage"].add(special_power.unit_key(item["unit"]))
        for item in special["steam"]:
            if item["engine"]:
                logged_units["steam"].add(special_power.unit_key(item["engine"]))
    heritage = special_power.list_rows("heritage")
    steam = special_power.list_rows("steam")
    plain = [row for row in heritage if row.get("era") != "a250"]
    a250 = [row for row in heritage if row.get("era") == "a250"]

    def have(rows: List[Dict[str, Any]], field: str, kind: str) -> int:
        return sum(1 for row in rows if special_power.unit_key(row.get(field, "")) in logged_units[kind])

    known = list(rr_mod.KNOWN_RAILROADS)
    seen_roads = {_get(entry, "railroad").upper() for entry in entries}
    def missing(rows, field, kind):
        out = []
        for row in rows:
            key = special_power.unit_key(row.get(field, ""))
            if key and key not in logged_units[kind]:
                label = row.get(field) or key
                extra = row.get("scheme") or row.get("name") or ""
                out.append({"name": label, "detail": extra})
        out.sort(key=lambda row: row["name"].upper())
        return out

    lists = [
        {"name": "Heritage units", "have": have(plain, "unit", "heritage"), "total": len(plain), "id": "heritage"},
        {"name": "America 250 units", "have": have(a250, "unit", "heritage"), "total": len(a250), "id": "a250"},
        {"name": "Steam engines", "have": have(steam, "engine", "steam"), "total": len(steam), "id": "steam"},
        {"name": "Railroads on your list", "have": sum(1 for rr in known if rr in seen_roads), "total": len(known), "id": "railroads"},
    ]
    lists = [row for row in lists if row["total"]]
    hunt = {
        "heritage": missing(plain, "unit", "heritage"),
        "a250": missing(a250, "unit", "heritage"),
        "steam": missing(steam, "engine", "steam"),
        "railroads": [{"name": rr, "detail": ""} for rr in sorted(known) if rr not in seen_roads],
    }

    stations.ensure_loaded()
    book: Dict[str, set] = defaultdict(set)
    original_of: Dict[str, str] = {}
    for _owners, display, original, spot, _mp in stations.STATIONS:
        book[display].add(stations.spot_name(spot).lower())
        original_of[display] = original
    visited: Dict[str, set] = defaultdict(set)
    for entry in entries:
        sub = _get(entry, "location_subdivision")
        spot = stations.spot_name(_get(entry, "location_spot")).lower()
        if not sub or not spot:
            continue
        target = sub if sub in book else next((d for d, o in original_of.items() if o == sub), "")
        if target and spot in book[target]:
            visited[target].add(spot)
    subs = [
        {"name": sub, "have": len(spots), "total": len(book[sub])}
        for sub, spots in visited.items()
    ]
    subs.sort(key=lambda row: (-row["have"] / max(row["total"], 1), -row["have"], row["name"]))
    return {"lists": lists, "subdivisions": subs, "hunt": hunt}


def along_the_line(entries: List[Any]) -> List[Dict[str, Any]]:
    """For each logged subdivision, every station by milepost with the trains logged there."""
    import stations

    stations.ensure_loaded()
    counts: Dict[str, Dict[str, int]] = defaultdict(lambda: defaultdict(int))
    for entry in entries:
        sub = _get(entry, "location_subdivision")
        spot = stations.spot_name(_get(entry, "location_spot")).lower()
        if sub and spot:
            counts[sub][spot] += 1
    lines = []
    for sub, logged in counts.items():
        stops: Dict[str, Dict[str, Any]] = {}
        for _owners, display, original, spot, mp in stations.STATIONS:
            if sub not in (display, original):
                continue
            value = stations.milepost_value(mp)
            name = stations.spot_name(spot)
            if value is None or name.lower() in stops:
                continue
            stops[name.lower()] = {"name": name, "mp": value, "trains": logged.get(name.lower(), 0)}
        if not stops:
            continue
        ordered = sorted(stops.values(), key=lambda stop: stop["mp"])
        lines.append({"subdivision": sub, "trains": sum(logged.values()), "stations": ordered})
    lines.sort(key=lambda line: (-line["trains"], line["subdivision"]))
    return lines


MEET_WINDOW = 3
OPPOSITE = {"North": "South", "South": "North", "East": "West", "West": "East"}
WEEKDAY_NAMES = ("Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun")


def _direction(entry: Any) -> str:
    from models import DIRECTION_ALIASES

    raw = _get(entry, "direction")
    return DIRECTION_ALIASES.get(raw.upper(), raw)


def _clock(minute: int) -> str:
    return "{:02d}:{:02d}".format(minute // 60, minute % 60)


def _hour_text(hour: int) -> str:
    return "{} {}".format(hour % 12 or 12, "AM" if hour < 12 else "PM")


def _train_text(entry: Any) -> str:
    name = _get(entry, "train_symbol") or _get(entry, "lead_locomotive")
    road = _get(entry, "railroad")
    if road and name.upper().split(" ")[0] == road.upper():
        road = ""
    return " ".join(part for part in (road, name) if part) or "Train"


def _sessions(entries: List[Any]) -> List[Tuple[str, str, List[Tuple[int, Any]]]]:
    """Visits: trains at one spot on one day, split where a wait runs past four hours."""
    by_spot: Dict[Tuple[str, str], List[Tuple[int, int, Any]]] = defaultdict(list)
    for entry in entries:
        minute = _minutes(_get(entry, "time"))
        day = _get(entry, "date")
        if minute is None or not day:
            continue
        by_spot[(day, _get(entry, "location_spot").lower())].append((minute, int(getattr(entry, "id", 0) or 0), entry))
    visits: List[Tuple[str, str, List[Tuple[int, Any]]]] = []
    for (day, spot), stamps in sorted(by_spot.items()):
        stamps.sort(key=lambda item: (item[0], item[1]))
        run: List[Tuple[int, Any]] = []
        for minute, _id, entry in stamps:
            if run and minute - run[-1][0] > SESSION_BREAK:
                visits.append((day, spot, run))
                run = []
            run.append((minute, entry))
        visits.append((day, spot, run))
    return visits


def meets(entries: List[Any], window: int = MEET_WINDOW) -> Dict[str, Any]:
    """Opposing trains at the same spot on the same day within a few minutes of each other."""
    by_spot: Dict[Tuple[str, str], List[Tuple[int, int, Any]]] = defaultdict(list)
    names: Dict[str, str] = {}
    for entry in entries:
        minute = _minutes(_get(entry, "time"))
        day = _get(entry, "date")
        spot = _get(entry, "location_spot")
        if minute is None or not day or not spot or _direction(entry) not in OPPOSITE:
            continue
        names.setdefault(spot.lower(), spot)
        by_spot[(day, spot.lower())].append((minute, int(getattr(entry, "id", 0) or 0), entry))
    pairs: List[Dict[str, Any]] = []
    per_spot: Dict[str, Dict[str, Any]] = defaultdict(lambda: {"meets": 0, "days": set()})
    for (day, spot), stamps in by_spot.items():
        stamps.sort(key=lambda item: (item[0], item[1]))
        for i, (minute, _id, entry) in enumerate(stamps):
            for other_minute, _other_id, other in stamps[i + 1:]:
                if other_minute - minute > window:
                    break
                if _direction(other) != OPPOSITE[_direction(entry)]:
                    continue
                pairs.append({
                    "date": day,
                    "time": _clock(minute),
                    "location": names[spot],
                    "apart": other_minute - minute,
                    "first": "{} {}".format(_train_text(entry), _direction(entry).lower() + "bound"),
                    "second": "{} {}".format(_train_text(other), _direction(other).lower() + "bound"),
                    "ids": [getattr(entry, "id", None), getattr(other, "id", None)],
                })
                per_spot[spot]["meets"] += 1
                per_spot[spot]["days"].add(day)
    pairs.sort(key=lambda row: (row["date"], row["time"]), reverse=True)
    locations = [
        {"location": names[spot], "meets": row["meets"], "days": len(row["days"])}
        for spot, row in per_spot.items()
    ]
    locations.sort(key=lambda row: (-row["meets"], row["location"]))
    return {
        "window": window,
        "total": len(pairs),
        "days": len({row["date"] for row in pairs}),
        "locations": locations[:25],
        "recent": [{k: v for k, v in row.items() if k != "ids"} for row in pairs[:25]],
        "all_ids": [{"location": row["location"], "ids": row["ids"]} for row in pairs],
    }


def meet_labels(entries: List[Any]) -> Dict[int, str]:
    """For each train in a meet or pass, the spot it happened at (by entry id)."""
    labels: Dict[int, str] = {}
    for row in meets(entries)["all_ids"]:
        for entry_id in row["ids"]:
            labels[int(entry_id or 0)] = row["location"]
    return labels


def symbol_timetable(entries: List[Any]) -> List[Dict[str, Any]]:
    """For symbols seen on two or more days at one spot: the usual time and how much it varies."""
    from reference import symbol_stats_parts

    groups: Dict[Tuple[str, str, str], List[Tuple[str, int, str]]] = defaultdict(list)
    shown: Dict[Tuple[str, str, str], Tuple[str, str, str]] = {}
    for entry in entries:
        symbol = _get(entry, "train_symbol").upper()
        minute = _minutes(_get(entry, "time"))
        day = _get(entry, "date")
        spot = _get(entry, "location_spot")
        if not symbol or minute is None or not day or not spot:
            continue
        railroad = _get(entry, "railroad")
        base = symbol_stats_parts(railroad, symbol)["base"] or symbol
        key = (railroad.upper(), base, spot.lower())
        shown.setdefault(key, (railroad, base, spot))
        groups[key].append((day, minute, _direction(entry)))
    rows = []
    for key, items in groups.items():
        days = {day for day, _m, _d in items}
        if len(days) < 2:
            continue
        times = sorted(minute for _day, minute, _d in items)
        mid = len(times) // 2
        usual = times[mid] if len(times) % 2 else (times[mid - 1] + times[mid]) // 2
        heading: Dict[str, int] = defaultdict(int)
        for _day, _minute, way in items:
            if way in OPPOSITE:
                heading[way] += 1
        railroad, base, spot = shown[key]
        rows.append({
            "symbol": base,
            "railroad": railroad,
            "location": spot,
            "days": len(days),
            "trains": len(items),
            "usual": _clock(usual),
            "earliest": _clock(times[0]),
            "latest": _clock(times[-1]),
            "spread": times[-1] - times[0],
            "direction": max(heading, key=lambda way: (heading[way], way)) if heading else "",
        })
    rows.sort(key=lambda row: (-row["days"], row["spread"], row["symbol"], row["location"]))
    return rows


def loco_travels(entries: List[Any]) -> List[Dict[str, Any]]:
    """Numbered lead locos seen on two or more days: every day and place, with the days in between."""
    seen: Dict[str, List[Any]] = defaultdict(list)
    for entry in entries:
        lead = _get(entry, "lead_locomotive").upper()
        if re.search(r"\d", lead) and _parse(_get(entry, "date")):
            seen[lead].append(entry)
    rows = []
    for lead, items in seen.items():
        items.sort(key=_order)
        stops: List[Dict[str, Any]] = []
        for entry in items:
            day = _get(entry, "date")
            spot = _get(entry, "location_spot")
            if stops and stops[-1]["date"] == day and stops[-1]["location"].lower() == spot.lower():
                continue
            prev = _parse(stops[-1]["date"]) if stops else None
            stops.append({
                "date": day,
                "time": _get(entry, "time"),
                "location": spot,
                "state": _get(entry, "location_state").upper(),
                "railroad": _get(entry, "railroad"),
                "symbol": _get(entry, "train_symbol"),
                "after": (_parse(day) - prev).days if prev else None,
            })
        days = {stop["date"] for stop in stops}
        if len(days) < 2:
            continue
        places = {stop["location"].lower() for stop in stops if stop["location"]}
        waits = [stop["after"] for stop in stops if stop["after"]]
        rows.append({
            "lead": lead,
            "days": len(days),
            "places": len(places),
            "first": stops[0]["date"],
            "last": stops[-1]["date"],
            "span": (_parse(stops[-1]["date"]) - _parse(stops[0]["date"])).days,
            "longest_gap": max(waits) if waits else 0,
            "stops": stops,
        })
    rows.sort(key=lambda row: (-row["places"], -row["days"], -row["span"], row["lead"]))
    return rows[:150]


def best_times(entries: List[Any]) -> List[Dict[str, Any]]:
    """For each spot: the clock hour with the most trains per visit, and the best weekday."""
    names: Dict[str, str] = {}
    for entry in entries:
        spot = _get(entry, "location_spot")
        if spot:
            names.setdefault(spot.lower(), spot)
    per_spot: Dict[str, Dict[str, Any]] = defaultdict(lambda: {
        "trains": 0, "visits": 0, "hour_trains": defaultdict(int), "hour_visits": defaultdict(int),
        "day_trains": defaultdict(int), "day_days": defaultdict(set),
    })
    for day, spot, run in _sessions(entries):
        if not spot:
            continue
        row = per_spot[spot]
        row["visits"] += 1
        row["trains"] += len(run)
        for hour in range(run[0][0] // 60, run[-1][0] // 60 + 1):
            row["hour_visits"][hour] += 1
        for minute, _entry in run:
            row["hour_trains"][minute // 60] += 1
        parsed = _parse(day)
        if parsed:
            row["day_trains"][parsed.weekday()] += len(run)
            row["day_days"][parsed.weekday()].add(day)
    rows = []
    for spot, row in per_spot.items():
        if row["trains"] < 3:
            continue
        hour = max(
            row["hour_visits"],
            key=lambda h: (row["hour_trains"][h] / row["hour_visits"][h], row["hour_trains"][h], -h),
        )
        weekday = max(
            row["day_days"],
            key=lambda d: (row["day_trains"][d] / len(row["day_days"][d]), row["day_trains"][d], -d),
        ) if row["day_days"] else None
        rows.append({
            "location": names.get(spot, spot),
            "trains": row["trains"],
            "visits": row["visits"],
            "best_hour": "{}–{}".format(_hour_text(hour), _hour_text((hour + 1) % 24)),
            "hour_rate": round(row["hour_trains"][hour] / row["hour_visits"][hour], 1),
            "best_day": WEEKDAY_NAMES[weekday] if weekday is not None else "",
            "day_rate": round(row["day_trains"][weekday] / len(row["day_days"][weekday]), 1) if weekday is not None else None,
            "hours": [
                {"hour": h, "rate": round(row["hour_trains"][h] / row["hour_visits"][h], 2)}
                for h in sorted(row["hour_visits"])
            ],
        })
    rows.sort(key=lambda row: (-row["trains"], row["location"]))
    return rows[:50]


FIRST_KINDS = (
    ("railroads", "Railroads"),
    ("heritage", "Heritage units"),
    ("a250", "America 250"),
    ("steam", "Steam engines"),
    ("states", "States"),
    ("types", "Train types"),
    ("symbols", "Train symbols"),
    ("subdivisions", "Subdivisions"),
)


def _first_ids(entries: List[Any]) -> Dict[str, Dict[str, Any]]:
    """For railroads, heritage units, states, train types and lead locos: the train each was first seen on."""
    import special_power

    firsts: Dict[str, Dict[str, Any]] = {kind: {} for kind, _label in FIRST_KINDS}
    firsts["leads"] = {}
    for entry in sorted(entries, key=_order):
        if not _parse(_get(entry, "date")):
            continue
        special = special_power.normalize_special_power(getattr(entry, "special_power", None) or "")
        heritage_items = [item for item in special["heritage"] if item.get("unit")]
        from reference import symbol_stats_parts

        symbol = _get(entry, "train_symbol").upper()
        symbol_base = symbol_stats_parts(_get(entry, "railroad"), symbol)["base"] if symbol else ""
        found = {
            "railroads": [_get(entry, "railroad")],
            "states": [_get(entry, "location_state").upper()],
            "types": [t for t in (getattr(entry, "train_types", None) or []) if t],
            "heritage": [item["unit"] for item in heritage_items if item.get("era") != "a250"],
            "a250": [item["unit"] for item in heritage_items if item.get("era") == "a250"],
            "steam": [item["engine"] for item in special["steam"] if item.get("engine")],
            "symbols": [symbol_base] if symbol_base else [],
            "subdivisions": [_get(entry, "location_subdivision")] if _get(entry, "location_subdivision") else [],
            "leads": [_get(entry, "lead_locomotive").upper()] if re.search(r"\d", _get(entry, "lead_locomotive")) else [],
        }
        for kind, names in found.items():
            for name in names:
                if kind in ("heritage", "a250", "steam"):
                    key = special_power.unit_key(name)
                else:
                    key = name.upper()
                if name and key not in firsts[kind]:
                    firsts[kind][key] = {"name": name, "date": _get(entry, "date"), "id": getattr(entry, "id", None)}
    return firsts


def firsts_by_month(all_entries: List[Any], shown: Optional[List[Any]] = None) -> List[Dict[str, Any]]:
    """Month by month, the railroads, heritage units, states and train types seen for the first time ever."""
    keep = None if shown is None else {getattr(e, "id", None) for e in shown}
    firsts = _first_ids(all_entries)
    months: Dict[str, Dict[str, List[str]]] = defaultdict(lambda: {kind: [] for kind, _label in FIRST_KINDS})
    for kind, _label in FIRST_KINDS:
        for item in sorted(firsts[kind].values(), key=lambda row: (row["date"], row["name"])):
            if keep is None or item["id"] in keep:
                months[item["date"][:7]][kind].append(item["name"])
    return [
        dict(names, month=month_label(month + "-01"), key=month, count=sum(len(v) for v in names.values()))
        for month, names in sorted(months.items(), reverse=True)
    ]


def traffic_flow(entries: List[Any]) -> Dict[str, Any]:
    """Loads and empties by direction, for every spot and all spots together."""
    names: Dict[str, str] = {}
    counts: Dict[str, Dict[str, Dict[str, int]]] = defaultdict(lambda: defaultdict(lambda: {"loads": 0, "empties": 0, "mixed": 0}))
    for entry in entries:
        way = _direction(entry)
        parts = [p for p in _get(entry, "load_status").split("/") if p]
        if way not in OPPOSITE or not parts:
            continue
        status = "mixed" if "Loads" in parts and "Empties" in parts else "loads" if "Loads" in parts else "empties" if "Empties" in parts else ""
        if not status:
            continue
        spot = _get(entry, "location_spot")
        for key in ("", spot.lower()) if spot else ("",):
            counts[key][way][status] += 1
        if spot:
            names.setdefault(spot.lower(), spot)

    def table(by_way: Dict[str, Dict[str, int]]) -> List[Dict[str, Any]]:
        rows = []
        for way in ("North", "South", "East", "West"):
            row = by_way.get(way)
            if not row:
                continue
            known = row["loads"] + row["empties"]
            rows.append(dict(row, direction=way, trains=known + row["mixed"],
                             loaded_pct=round(100 * row["loads"] / known) if known else None))
        return rows

    spots = [
        {"location": names[key], "trains": sum(r["trains"] for r in table(by_way)), "rows": table(by_way)}
        for key, by_way in counts.items() if key
    ]
    spots.sort(key=lambda row: (-row["trains"], row["location"]))
    return {"all": table(counts.get("", {})), "locations": spots}


def trip_reports(entries: List[Any], all_entries: Optional[List[Any]] = None) -> List[Dict[str, Any]]:
    """One report per named trip: trains, time trackside, top railroads and places, and firsts."""
    import special_power

    firsts = _first_ids(all_entries if all_entries is not None else entries)
    first_by_id: Dict[Any, Dict[str, List[str]]] = defaultdict(lambda: defaultdict(list))
    for kind in ("railroads", "leads", "heritage", "states"):
        for item in firsts[kind].values():
            first_by_id[item["id"]][kind].append(item["name"])
    trips: Dict[str, List[Any]] = defaultdict(list)
    for entry in entries:
        name = _get(entry, "trip_name")
        if name:
            trips[name].append(entry)

    def top(counter: Dict[str, int]) -> List[Dict[str, Any]]:
        ranked = sorted(counter.items(), key=lambda kv: (-kv[1], kv[0]))
        return [{"name": name, "trains": n} for name, n in ranked[:3]]

    reports = []
    for name, items in trips.items():
        items.sort(key=_order)
        dates = sorted({_get(e, "date") for e in items if _get(e, "date")})
        minutes = sum(run[-1][0] - run[0][0] for _day, _spot, run in _sessions(items))
        roads: Dict[str, int] = defaultdict(int)
        spots: Dict[str, int] = defaultdict(int)
        per_day: Dict[str, int] = defaultdict(int)
        heritage, steam = set(), 0
        new: Dict[str, List[str]] = defaultdict(list)
        longest = 0
        for entry in items:
            roads[_get(entry, "railroad") or "Unknown"] += 1
            if _get(entry, "location_spot"):
                spots[_get(entry, "location_spot")] += 1
            if _get(entry, "date"):
                per_day[_get(entry, "date")] += 1
            special = special_power.normalize_special_power(getattr(entry, "special_power", None) or "")
            heritage.update(item["unit"] for item in special["heritage"] if item["unit"])
            steam += 1 if special["steam"] else 0
            longest = max(longest, _car_total(_get(entry, "car_counts")))
            for kind, found in first_by_id.get(getattr(entry, "id", None), {}).items():
                new[kind].extend(found)
        busiest = max(per_day.items(), key=lambda kv: (kv[1], kv[0])) if per_day else None
        reports.append({
            "trip": name,
            "trains": len(items),
            "days": len(dates),
            "first": dates[0] if dates else "",
            "last": dates[-1] if dates else "",
            "hours": round(minutes / 60, 1),
            "per_hour": round(len(items) * 60 / minutes, 1) if minutes >= 30 else None,
            "railroads": top(roads),
            "locations": top(spots),
            "states": sorted({_get(e, "location_state").upper() for e in items if _get(e, "location_state")}),
            "heritage": sorted(heritage),
            "steam": steam,
            "longest": longest or None,
            "busiest": {"date": busiest[0], "trains": busiest[1]} if busiest else None,
            "new_railroads": new["railroads"],
            "new_states": new["states"],
            "new_heritage": new["heritage"],
            "new_leads": len(new["leads"]),
        })
    reports.sort(key=lambda row: (row["last"], row["trip"]), reverse=True)
    return reports



def field_charts(entries: List[Any]) -> Dict[str, Any]:
    """Night flag, coal marks, and media capture rate by month — fields already on each train."""
    night = sum(1 for e in entries if getattr(e, "night", False))
    not_night = len(entries) - night
    coal: Dict[str, int] = defaultdict(int)
    for entry in entries:
        mark = _get(entry, "coal_mark")
        if mark:
            coal[mark] += 1
    months: Dict[str, Dict[str, int]] = defaultdict(lambda: {"trains": 0, "photo": 0, "video": 0, "notes": 0, "media": 0})
    for entry in entries:
        when = _get(entry, "date")
        if not when or len(when) < 7:
            continue
        bucket = months[when[:7]]
        bucket["trains"] += 1
        photo = bool(getattr(entry, "photographed", False))
        video = bool(getattr(entry, "videoed", False))
        notes = bool((_get(entry, "notes")))
        if photo:
            bucket["photo"] += 1
        if video:
            bucket["video"] += 1
        if notes:
            bucket["notes"] += 1
        if photo or video:
            bucket["media"] += 1
    media_rate = []
    for key, row in sorted(months.items(), reverse=True):
        trains = row["trains"] or 1
        media_rate.append({
            "month": month_label(key + "-01"),
            "key": key,
            "trains": row["trains"],
            "photo_pct": round(100 * row["photo"] / trains),
            "video_pct": round(100 * row["video"] / trains),
            "notes_pct": round(100 * row["notes"] / trains),
            "media_pct": round(100 * row["media"] / trains),
            "photo": row["photo"],
            "video": row["video"],
            "notes": row["notes"],
            "media": row["media"],
        })
    coal_rows = [{"mark": name, "trains": n} for name, n in sorted(coal.items(), key=lambda kv: (-kv[1], kv[0]))]
    return {
        "night_flag": [
            {"name": "Night", "trains": night},
            {"name": "Day / unset", "trains": not_night},
        ] if entries else [],
        "coal_marks": coal_rows,
        "media_rate": media_rate,
    }


def glance(entries: List[Any], days: List[str], all_entries: Optional[List[Any]] = None) -> Dict[str, Any]:
    """Compact Log Stats strip: last sighting, open trip, streak, collection %."""
    everything = all_entries if all_entries is not None else entries
    ordered = sorted(entries, key=_order)
    last = ordered[-1] if ordered else None
    last_sighting = None
    if last:
        bits = [
            _get(last, "lead_locomotive") or _get(last, "railroad"),
            _get(last, "direction"),
            _get(last, "location_spot"),
            _get(last, "date"),
            _get(last, "time"),
        ]
        last_sighting = {
            "label": " · ".join(p for p in bits if p),
            "date": _get(last, "date"),
            "id": getattr(last, "id", None),
            "trip": _get(last, "trip_name"),
        }
    open_trip = ""
    if last_sighting and last_sighting.get("trip"):
        open_trip = last_sighting["trip"]
    else:
        # most recent named trip in full log
        for entry in sorted(everything, key=_order, reverse=True):
            name = _get(entry, "trip_name")
            if name:
                open_trip = name
                break
    streak = streaks(days if days else sorted({_get(e, "date") for e in entries if _get(e, "date")}))
    coll = collection(everything)
    lists = coll.get("lists") or []
    have = sum(row["have"] for row in lists)
    total = sum(row["total"] for row in lists)
    hunt_left = sum(len(coll.get("hunt", {}).get(key) or []) for key in ("heritage", "a250", "steam", "railroads"))
    return {
        "last_sighting": last_sighting,
        "open_trip": open_trip,
        "streak_days": streak.get("current", {}).get("days") or 0,
        "streak_from": streak.get("current", {}).get("from") or "",
        "collection_have": have,
        "collection_total": total,
        "collection_pct": round(100 * have / total) if total else 0,
        "hunt_left": hunt_left,
    }


def seen_before(entries: List[Any], lead: str = "", symbol: str = "", exclude_id: Any = None) -> Dict[str, Any]:
    """Prior sightings of a lead loco or train symbol for the pad hint."""
    lead_key = lead.strip().upper()
    symbol_key = symbol.strip().upper()
    out = {"lead": None, "symbol": None}
    if not lead_key and not symbol_key:
        return out
    lead_hits = []
    symbol_hits = []
    for entry in sorted(entries, key=_order):
        if exclude_id is not None and getattr(entry, "id", None) == exclude_id:
            continue
        if lead_key and _get(entry, "lead_locomotive").upper() == lead_key:
            lead_hits.append(entry)
        if symbol_key and _get(entry, "train_symbol").upper() == symbol_key:
            symbol_hits.append(entry)

    def pack(hits, label):
        if not hits:
            return None
        last = hits[-1]
        return {
            "count": len(hits),
            "label": label,
            "last_date": _get(last, "date"),
            "last_location": _get(last, "location_spot"),
            "last_railroad": _get(last, "railroad"),
        }

    if lead_key:
        out["lead"] = pack(lead_hits, lead.strip())
    if symbol_key:
        out["symbol"] = pack(symbol_hits, symbol.strip())
    return out


def extra_stats(entries: List[Any], days: List[str], all_entries: Optional[List[Any]] = None) -> Dict[str, Any]:
    everything = entries if all_entries is None else all_entries
    run = streaks(days)
    wait = gaps(entries)
    repeats = lead_repeats(entries)
    facts = [
        {"name": "Longest streak of days trackside", "value": "{} ({} to {})".format(run["longest"]["days"], run["longest"]["from"], run["longest"]["to"]) if run["longest"]["days"] > 1 else str(run["longest"]["days"])},
        {"name": "Current streak", "value": "{} day{}".format(run["current"]["days"], "" if run["current"]["days"] == 1 else "s") if run["current"]["days"] else "—"},
        {"name": "Average wait between trains", "value": _wait_text(wait["average"])},
        {"name": "Longest wait between trains", "value": "{} on {}".format(_wait_text(wait["longest"]["minutes"]), wait["longest"]["date"]) if wait["longest"] else "—"},
        {"name": "Trains per hour trackside", "value": str(wait["per_hour"]) if wait["per_hour"] is not None else "—"},
        {"name": "Lead locos seen more than once", "value": str(len(repeats))},
    ]
    charts = field_charts(entries)
    coll = collection(entries)
    return {
        "streaks": run,
        "milestones": milestones(entries),
        "gaps": wait["buckets"],
        "per_hour_locations": wait["per_hour_locations"],
        "running_totals": running_totals(entries),
        "new_leads": new_leads_by_month(entries),
        "averages": averages(entries),
        "lead_repeats": repeats,
        "collection": coll,
        "along_line": along_the_line(entries),
        "meets": {k: v for k, v in meets(entries).items() if k != "all_ids"},
        "symbol_timetable": symbol_timetable(entries),
        "loco_travels": loco_travels(entries),
        "best_times": best_times(entries),
        "firsts": firsts_by_month(everything, entries),
        "traffic_flow": traffic_flow(entries),
        "trip_reports": trip_reports(entries, everything),
        "night_flag": charts["night_flag"],
        "coal_marks": charts["coal_marks"],
        "media_rate": charts["media_rate"],
        "glance": glance(entries, days, everything),
        "extra_facts": facts,
    }


def period_choices(entries: List[Any]) -> List[Dict[str, Any]]:
    """Trips, years, and months that can go side by side, newest first within each group."""
    trips: Dict[str, str] = {}
    years, months = set(), set()
    for entry in entries:
        day = _get(entry, "date")
        trip = _get(entry, "trip_name")
        if trip:
            trips[trip] = max(trips.get(trip, ""), day)
        if day:
            years.add(day[:4])
            months.add(day[:7])

    def month_label(month: str) -> str:
        parsed = _parse(month + "-01")
        return parsed.strftime("%B %Y") if parsed else month

    return (
        [{"value": "all", "label": "Everything", "group": "All"}]
        + [{"value": "trip:" + name, "label": name, "group": "Trips"} for name in sorted(trips, key=lambda n: trips[n], reverse=True)]
        + [{"value": "year:" + year, "label": year, "group": "Years"} for year in sorted(years, reverse=True)]
        + [{"value": "month:" + month, "label": month_label(month), "group": "Months"} for month in sorted(months, reverse=True)]
    )


def period_entries(entries: List[Any], pick: str) -> List[Any]:
    kind, _sep, value = (pick or "").partition(":")
    if kind == "trip":
        return [e for e in entries if _get(e, "trip_name") == value]
    if kind == "year":
        return [e for e in entries if _get(e, "date")[:4] == value]
    if kind == "month":
        return [e for e in entries if _get(e, "date")[:7] == value]
    if kind == "all":
        return list(entries)
    raise ValueError("Pick a trip, year, or month")


def period_summary(entries: List[Any], pick: str) -> Dict[str, Any]:
    """The numbers that matter for one period, so two can be read side by side."""
    from catalog import log_stats

    chosen = period_entries(entries, pick)
    log = log_stats(chosen)
    totals = log["totals"]
    facts = {row["name"]: row["value"] for row in log["facts"]}

    def top(rows: List[Dict[str, Any]], key: str) -> List[Dict[str, Any]]:
        return [{"name": row[key], "trains": row["trains"]} for row in rows if row.get("trains")][:5]

    roads = sorted((r for r in log["railroads"] if r["trains"]), key=lambda r: (-r["trains"], r["railroad"]))
    return {
        "pick": pick,
        "rows": [
            {"name": "Trains", "value": totals["trains"]},
            {"name": "Days trackside", "value": totals["days"]},
            {"name": "Average trains per day", "value": facts.get("Average trains per day trackside", "0")},
            {"name": "First and last day", "value": "{} to {}".format(totals["first_date"], totals["last_date"]) if totals["first_date"] else "—"},
            {"name": "Railroads", "value": totals["unique_railroads"]},
            {"name": "Locations", "value": totals["unique_locations"]},
            {"name": "Lead locos", "value": totals["unique_leads"]},
            {"name": "Loads / Empties", "value": "{} / {}".format(totals["loads"], totals["empties"])},
            {"name": "Photos / Videos", "value": "{} / {}".format(totals["photos"], totals["videos"])},
            {"name": "Busiest hour", "value": facts.get("Busiest hour", "—")},
            {"name": "Trains per hour trackside", "value": facts.get("Trains per hour trackside", "—")},
            {"name": "Average cars", "value": facts.get("Average cars (when counted)", "—")},
            {"name": "Foreign power leading", "value": facts.get("Foreign power leading", "0")},
            {"name": "Heritage units", "value": facts.get("Heritage units seen", "0")},
        ],
        "railroads": [{"name": r["railroad"], "trains": r["trains"]} for r in roads[:5]],
        "types": top(log["types"], "type"),
        "locations": top(log["locations"], "location"),
    }
