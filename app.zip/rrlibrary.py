"""Railroad library: name, mark, class, states, time zone, and more for each railroad.

The shipped list is assets/reference/railroad_library.csv (a data update can replace it).
Additions, edits, and removals made on this Mac are kept in railroad_library.json in
Application Support, so a new shipped list never overwrites them.
"""
from __future__ import annotations

import csv
import io
import json
import re
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

from paths import support_dir

FIELDS = (
    "name", "mark", "aliases", "group", "rr_class", "operation", "region",
    "states", "time_zone", "miles", "mark_status", "notes", "timetables",
)
HEADERS = {
    "name": "Railroad Name", "mark": "Reporting Mark", "aliases": "Aliases", "group": "Group",
    "rr_class": "Class", "operation": "Operation", "region": "Region", "states": "States",
    "time_zone": "Time Zone", "miles": "Track Mileage", "mark_status": "Mark Status", "notes": "Notes",
    "timetables": "Timetables",
}
GROUPS = ("Freight", "Passenger / Commuter", "Tourist")
REGIONS = ("National", "Western & Mountain", "Midwest & Central", "Southern", "Northeast & Mid-Atlantic")
STATUSES = ("listed", "verified", "check", "no AAR mark")
_OLD_STATUSES = {"likely": "verified", "likelyright": "verified"}
ZONE_LABELS = {
    "America/New_York": "Eastern", "America/Chicago": "Central", "America/Denver": "Mountain",
    "America/Phoenix": "Arizona", "America/Los_Angeles": "Pacific", "America/Anchorage": "Alaska",
    "Pacific/Honolulu": "Hawaii",
}

_N = re.compile(r"[^a-z0-9]+")
_HEADER_KEYS = {
    "railroadname": "name", "railroad": "name", "name": "name",
    "reportingmark": "mark", "mark": "mark", "reportingmarks": "mark",
    "aliases": "aliases", "alias": "aliases", "othermarks": "aliases",
    "group": "group", "category": "group",
    "class": "rr_class", "type": "rr_class",
    "operation": "operation", "typeofoperation": "operation", "operationtype": "operation",
    "region": "region",
    "states": "states", "state": "states",
    "timezone": "time_zone", "zone": "time_zone",
    "trackmileage": "miles", "mileage": "miles", "miles": "miles", "routemiles": "miles",
    "markstatus": "mark_status", "status": "mark_status",
    "notes": "notes", "note": "notes",
    "timetables": "timetables", "timetable": "timetables", "etts": "timetables", "ett": "timetables",
}
_YES = ("yes", "y", "true", "1", "x", "on")


def _n(text: Any) -> str:
    return _N.sub("", str(text or "").lower())


def shipped_path() -> Path:
    from data_updates import reference_path

    return reference_path("railroad_library.csv")


def extra_path() -> Path:
    from data_updates import reference_path

    return reference_path("railroad_library_extra.csv")


def user_path() -> Path:
    return support_dir() / "railroad_library.json"


def row_id(row: Dict[str, Any]) -> str:
    mark = str(row.get("mark") or "").strip().upper()
    return mark if mark else "N:" + _n(row.get("name"))


def _group(raw: Any) -> str:
    key = _n(raw)
    if key in ("freight", "frt"):
        return "Freight"
    if key in ("passengercommuter", "passcomm", "passenger", "commuter"):
        return "Passenger / Commuter"
    if key in ("tourist", "scenic", "heritage", "excursion"):
        return "Tourist"
    return ""


def _region(raw: Any) -> str:
    key = _n(raw)
    for region in REGIONS:
        if key and key == _n(region):
            return region
    for region in REGIONS:
        if key and _n(region).startswith(key):
            return region
    return str(raw or "").strip()


def _states(raw: Any) -> str:
    from states import normalize_state

    text = str(raw or "").strip()
    if not text or text.lower().startswith("multiple"):
        return text
    parts = [p.strip() for p in re.split(r"\s*(?:/|,|;|&|\band\b)\s*", text) if p.strip()]
    codes = [normalize_state(p) for p in parts]
    if all(codes):
        return " / ".join(dict.fromkeys(codes))
    return text


def zone_for_states(states: str) -> str:
    from states import STATE_ZONES

    codes = [c for c in re.split(r"\s*/\s*", states or "") if c in STATE_ZONES]
    if not codes:
        return "Multiple" if (states or "").lower().startswith("multiple") else ""
    labels = list(dict.fromkeys(ZONE_LABELS.get(STATE_ZONES[c], "") for c in codes))
    return " / ".join(label for label in labels if label)


def _miles(raw: Any) -> Optional[float]:
    text = str(raw or "").strip().replace(",", "")
    match = re.search(r"\d+(?:\.\d+)?", text)
    if not match:
        return None
    value = round(float(match.group()), 2)
    if value == int(value):
        return int(value)
    return value


def clean_row(raw: Dict[str, Any]) -> Dict[str, Any]:
    """One library row with every field tidied. Raises ValueError when it can't be kept."""
    import railroads as rr_mod

    row = {field: str(raw.get(field) or "").strip() for field in FIELDS}
    if not row["name"] and not row["mark"]:
        raise ValueError("Give the railroad a name or a mark.")
    row["mark"] = row["mark"].upper()
    if row["mark"] and not re.fullmatch(r"[A-Z0-9][A-Z0-9 .&/-]{0,11}", row["mark"]):
        raise ValueError("Marks use letters and numbers, like BNSF or GCRX.")
    row["aliases"] = " / ".join(
        dict.fromkeys(a.upper() for a in re.split(r"\s*[/,;]\s*", row["aliases"]) if a and a.upper() != row["mark"])
    )
    row["group"] = _group(row["group"]) or "Freight"
    if row["rr_class"]:
        row["rr_class"] = rr_mod.class_label(row["rr_class"], row["group"]) or row["rr_class"]
    row["region"] = _region(row["region"])
    row["states"] = _states(row["states"])
    if not row["time_zone"]:
        row["time_zone"] = zone_for_states(row["states"])
    miles = _miles(row["miles"])
    row["miles"] = miles
    status = _OLD_STATUSES.get(_n(row["mark_status"]), row["mark_status"])
    match = [s for s in STATUSES if _n(s) == _n(status)]
    row["mark_status"] = match[0] if match else ("check" if row["mark"] else "no AAR mark")
    row["timetables"] = "yes" if _n(row["timetables"]) in _YES else ""
    row["id"] = row_id(row)
    return row


def _read_csv_text(text: str) -> List[Dict[str, Any]]:
    reader = csv.reader(io.StringIO(text))
    rows = [r for r in reader if any(cell.strip() for cell in r)]
    if not rows:
        return []
    keys = [_HEADER_KEYS.get(_n(cell), "") for cell in rows[0]]
    out = []
    for cells in rows[1:]:
        item = {key: cells[i] for i, key in enumerate(keys) if key and i < len(cells)}
        if item.get("rr_class") and not item.get("group"):
            item["group"] = _group_from_class(item["rr_class"])
        out.append(item)
    return out


def _group_from_class(rr_class: str) -> str:
    key = _n(rr_class)
    if key in ("commuter", "nationwide", "lightrail", "intercity"):
        return "Passenger / Commuter"
    if key in ("heritage", "scenic", "dinnertrain", "dinner"):
        return "Tourist"
    return "Freight"


def _rows_from(path: Path) -> List[Dict[str, Any]]:
    try:
        text = path.read_text(encoding="utf-8-sig")
    except OSError:
        return []
    rows = []
    for raw in _read_csv_text(text):
        try:
            rows.append(clean_row(raw))
        except ValueError:
            continue
    return rows


def _shipped_rows() -> List[Dict[str, Any]]:
    return _rows_from(shipped_path())


def _extra_rows() -> List[Dict[str, Any]]:
    return _rows_from(extra_path())


def _sidecar_ids() -> set:
    """Marks that live only on the optional list, never the shipped 385."""
    shipped = {row["id"] for row in _shipped_rows()}
    return {row["id"] for row in _extra_rows()} - shipped


def _empty_overlay() -> Dict[str, Any]:
    return {"rows": {}, "removed": [], "extra": False, "extra_rows": {}}


def _overlay() -> Dict[str, Any]:
    path = user_path()
    if not path.is_file():
        return _empty_overlay()
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return _empty_overlay()
    if not isinstance(data, dict):
        return _empty_overlay()
    rows = data.get("rows") if isinstance(data.get("rows"), dict) else {}
    extra_rows = data.get("extra_rows") if isinstance(data.get("extra_rows"), dict) else {}
    removed = [str(x) for x in data.get("removed") or []]
    return {"rows": rows, "removed": removed, "extra": bool(data.get("extra")), "extra_rows": extra_rows}


def _write_overlay(overlay: Dict[str, Any]) -> None:
    import railroads as rr_mod

    path = user_path()
    overlay.setdefault("extra", False)
    overlay.setdefault("extra_rows", {})
    if not overlay["rows"] and not overlay["removed"] and not overlay["extra_rows"] and not overlay["extra"]:
        if path.exists():
            path.unlink()
    else:
        path.write_text(json.dumps(overlay, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    rr_mod.reload_railroads()


def library_rows(include_extra: bool = True) -> List[Dict[str, Any]]:
    overlay = _overlay()
    removed = set(overlay["removed"])
    shipped = {row["id"]: row for row in _shipped_rows()}
    merged: Dict[str, Dict[str, Any]] = {}
    for rid, row in shipped.items():
        if rid not in removed:
            merged[rid] = dict(row, custom=False, extra=False)
    for rid, raw in overlay["rows"].items():
        try:
            row = clean_row(raw)
        except ValueError:
            continue
        merged[row["id"]] = dict(row, custom=True, extra=False)
    if include_extra and overlay["extra"]:
        sidecar = _sidecar_ids()
        for row in _extra_rows():
            if row["id"] in removed or row["id"] not in sidecar or row["id"] in merged:
                continue
            merged[row["id"]] = dict(row, custom=False, extra=True)
        for rid, raw in overlay["extra_rows"].items():
            if rid in removed:
                continue
            try:
                row = clean_row(raw)
            except ValueError:
                continue
            if row["id"] not in sidecar:
                continue
            merged[row["id"]] = dict(row, custom=True, extra=True)
    group_order = {g: i for i, g in enumerate(GROUPS)}
    return sorted(merged.values(), key=lambda r: (group_order.get(r["group"], 9), (r["name"] or r["mark"]).lower()))


def find(mark_or_id: str) -> Optional[Dict[str, Any]]:
    key = str(mark_or_id or "").strip().upper()
    if not key:
        return None
    for row in library_rows():
        if row["id"].upper() == key or row["mark"] == key or key in row["aliases"].split(" / "):
            return row
    return None


_BY_MARK: Dict[str, Any] = {"key": None, "map": {}}


def by_mark() -> Dict[str, Dict[str, Any]]:
    """Primary mark and each other mark, pointing at the one library row. A primary mark wins over an alias."""
    watched = (shipped_path(), user_path(), extra_path())
    key = tuple((str(path), path.stat().st_mtime_ns if path.is_file() else 0) for path in watched)
    if _BY_MARK["key"] == key:
        return _BY_MARK["map"]
    rows = library_rows()
    index: Dict[str, Dict[str, Any]] = {}
    for row in rows:
        mark = (row.get("mark") or "").upper()
        if mark:
            index.setdefault(mark, row)
    for row in rows:
        for alias in filter(None, (row.get("aliases") or "").split(" / ")):
            index.setdefault(alias.upper(), row)
    _BY_MARK["key"] = key
    _BY_MARK["map"] = index
    return index


def save_row(raw: Dict[str, Any], original_id: str = "") -> Dict[str, Any]:
    row = clean_row(raw)
    overlay = _overlay()
    taken = {r["id"]: r for r in library_rows()}
    if row["id"] != original_id and row["id"] in taken:
        raise ValueError("{} is already in the library.".format(row["mark"] or row["name"]))
    sidecar = _sidecar_ids()
    if original_id and original_id != row["id"]:
        overlay["rows"].pop(original_id, None)
        overlay["extra_rows"].pop(original_id, None)
        shipped_ids = {r["id"] for r in _shipped_rows()}
        if original_id in shipped_ids | sidecar and original_id not in overlay["removed"]:
            overlay["removed"].append(original_id)
    stored = {field: row[field] for field in FIELDS}
    if row["id"] in sidecar:
        overlay["extra_rows"][row["id"]] = stored
        overlay["rows"].pop(row["id"], None)
    else:
        overlay["rows"][row["id"]] = stored
        overlay["extra_rows"].pop(row["id"], None)
    if row["id"] in overlay["removed"]:
        overlay["removed"].remove(row["id"])
    _write_overlay(overlay)
    return dict(row, custom=True, extra=row["id"] in sidecar)


def remove_row(rid: str) -> bool:
    overlay = _overlay()
    found = overlay["rows"].pop(rid, None) is not None or overlay["extra_rows"].pop(rid, None) is not None
    listed = {r["id"] for r in _shipped_rows()} | _sidecar_ids()
    if rid in listed:
        if rid not in overlay["removed"]:
            overlay["removed"].append(rid)
        found = True
    _write_overlay(overlay)
    return found


def restore_shipped() -> int:
    overlay = _overlay()
    count = len(overlay["rows"]) + len(overlay["removed"]) + len(overlay["extra_rows"]) + (1 if overlay["extra"] else 0)
    _write_overlay(_empty_overlay())
    return count


def set_extra(on: bool) -> None:
    """Show or hide the optional railroad list. Edits to those rows stay for next time."""
    overlay = _overlay()
    overlay["extra"] = bool(on)
    _write_overlay(overlay)


def extra_count() -> int:
    """How many optional roads are not already in the shipped list or removed here."""
    overlay = _overlay()
    removed = set(overlay["removed"])
    base = {row["id"] for row in library_rows(include_extra=False)}
    return sum(1 for rid in _sidecar_ids() if rid not in removed and rid not in base)


_RTF_SKIP = ("fonttbl", "colortbl", "stylesheet", "info", "pict", "expandedcolortbl", "listtable", "listoverridetable")


def rtf_to_text(rtf: str) -> str:
    """Plain text from a simple RTF file, like one saved by TextEdit."""
    out: List[str] = []
    stack: List[bool] = []
    skip = False
    i, n = 0, len(rtf)
    while i < n:
        ch = rtf[i]
        if ch == "{":
            stack.append(skip)
            i += 1
            continue
        if ch == "}":
            skip = stack.pop() if stack else False
            i += 1
            continue
        if ch == "\\":
            nxt = rtf[i + 1] if i + 1 < n else ""
            if nxt in "\\{}":
                if not skip:
                    out.append(nxt)
                i += 2
                continue
            if nxt == "'":
                if not skip:
                    try:
                        out.append(bytes([int(rtf[i + 2:i + 4], 16)]).decode("cp1252"))
                    except ValueError:
                        pass
                i += 4
                continue
            if nxt == "*":
                skip = True
                i += 2
                continue
            if nxt in "\n\r":
                if not skip:
                    out.append("\n")
                i += 2
                continue
            match = re.match(r"\\([a-zA-Z]+)(-?\d+)? ?", rtf[i:])
            if not match:
                i += 2
                continue
            word, arg = match.group(1), match.group(2)
            i += match.end()
            if word in _RTF_SKIP:
                skip = True
            elif skip:
                continue
            elif word in ("par", "line"):
                out.append("\n")
            elif word == "tab":
                out.append("\t")
            elif word == "u" and arg:
                code = int(arg)
                out.append(chr(code + 65536 if code < 0 else code))
                if i < n and rtf[i] == "?":
                    i += 1
            continue
        if ch in "\r\n":
            i += 1
            continue
        if not skip:
            out.append(ch)
        i += 1
    return "".join(out)


def parse_list(text: str, group: str = "") -> List[Dict[str, Any]]:
    """Rows from a pasted or imported list.

    Reads a CSV with a header row, or lines like "Name | State | Type of operation"
    under region headings (a line with no "|" starts a new region). RTF is read as text.
    """
    if (text or "").lstrip().startswith("{\\rtf"):
        text = rtf_to_text(text)
    text = (text or "").replace("\r\n", "\n").replace("\r", "\n")
    lines = [line for line in text.split("\n") if line.strip()]
    if not lines:
        return []
    if "|" not in text:
        rows = _read_csv_text("\n".join(lines))
    else:
        rows = []
        region = ""
        for line in lines:
            if "|" not in line:
                region = re.sub(r"^[\s•·*\-–]+", "", line).strip().rstrip(":")
                region = re.sub(r"\s+Region$", "", region, flags=re.I)
                continue
            parts = [p.strip() for p in line.split("|")]
            item = {"name": re.sub(r"^[\s•·*\-–]+", "", parts[0]), "region": region}
            if len(parts) > 1:
                item["states"] = parts[1]
            if len(parts) > 2:
                item["operation"] = parts[2]
            if len(parts) > 3:
                item["mark"] = parts[3]
            rows.append(item)
    for item in rows:
        if group and not item.get("group"):
            item["group"] = group
    return rows


_RAIL_WORDS = re.compile(r"\b(rail ?road|railway|rail ?way|company|co|inc|the)\b", re.I)


def name_keys(name: str) -> List[str]:
    """Ways a name can match another: the whole name and each part split by "/" or
    parentheses, ignoring words like Railroad and Railway."""
    text = str(name or "")
    parts = [text] + re.split(r"\s*/\s*|\s*\(\s*|\s*\)\s*", text)
    keys = []
    for part in parts:
        key = _n(_RAIL_WORDS.sub(" ", part))
        if len(key) >= 3 and key not in keys:
            keys.append(key)
    return keys


def import_rows(text: str, group: str = "") -> Dict[str, Any]:
    """Add a list to the library. A railroad already there (same mark, alias, or name)
    only gets its blank fields filled in; nothing already set is changed."""
    incoming = parse_list(text, group)
    if not incoming:
        raise ValueError("Nothing to import. Paste a CSV with a header row, or lines like Name | State | Type.")
    current = library_rows()
    by_mark: Dict[str, Dict[str, Any]] = {}
    by_name: Dict[str, Dict[str, Any]] = {}
    for row in current:
        if row["mark"]:
            by_mark[row["mark"]] = row
        for alias in filter(None, row["aliases"].split(" / ")):
            by_mark[alias] = row
        for key in name_keys(row["name"]):
            by_name.setdefault(key, row)
    added, filled, same, skipped = [], [], [], []
    for raw in incoming:
        try:
            row = clean_row(raw)
        except ValueError as err:
            skipped.append({"name": raw.get("name") or raw.get("mark") or "", "why": str(err)})
            continue
        match = by_mark.get(row["mark"]) if row["mark"] else None
        if match is None:
            match = next((by_name[k] for k in name_keys(row["name"]) if k in by_name), None)
        if match is None:
            saved = save_row(row)
            by_mark[saved["mark"]] = saved
            for key in name_keys(saved["name"]):
                by_name.setdefault(key, saved)
            added.append(saved["mark"] or saved["name"])
            continue
        given = {k for k in FIELDS if str(raw.get(k) or "").strip()}
        merged = dict(match)
        changed = False
        for field in FIELDS:
            if field in given and not match.get(field) and row.get(field):
                merged[field] = row[field]
                changed = True
        if changed:
            save_row(merged, match["id"])
            filled.append(match["mark"] or match["name"])
        else:
            same.append(match["mark"] or match["name"])
    return {"added": added, "filled": filled, "same": same, "skipped": skipped}


def library_csv(rows: Optional[List[Dict[str, Any]]] = None) -> str:
    """The shipped list plus this Mac's own edits. The optional extra list stays out,
    so a release build does not fold it into the 385."""
    if rows is None:
        skip = _sidecar_ids()
        rows = [row for row in library_rows(include_extra=False) if row["id"] not in skip]
    out = io.StringIO()
    writer = csv.writer(out, lineterminator="\n")
    writer.writerow([HEADERS[f] for f in FIELDS])
    for row in rows:
        writer.writerow(["" if row.get(f) is None else row.get(f) for f in FIELDS])
    return out.getvalue()


def summary() -> Dict[str, Any]:
    import railroads as rr_mod

    rows = library_rows()
    overlay = _overlay()
    on_menu = set(rr_mod.grouped_railroads()["all"])
    for row in rows:
        row["on_menu"] = bool(row["mark"]) and row["mark"] in on_menu
    return {
        "rows": rows,
        "groups": list(GROUPS),
        "regions": list(REGIONS),
        "statuses": list(STATUSES),
        "class_choices": {k: list(v) for k, v in rr_mod.CLASS_CHOICES.items()},
        "custom": any(row["custom"] and not row.get("extra") for row in rows) or bool(overlay["removed"]) or overlay["extra"] or bool(overlay["extra_rows"]),
        "extra": overlay["extra"],
        "extra_count": extra_count(),
    }


def add_to_menu(rid: str) -> Tuple[Dict[str, Any], Dict[str, Any]]:
    """Put a library railroad on the Railroad menu with its group, class, and full name."""
    import acronyms
    import railroads as rr_mod

    row = find(rid)
    if row is None:
        raise ValueError("That railroad isn't in the library.")
    if not row["mark"]:
        raise ValueError("Give it a mark first. The Railroad menu lists railroads by mark.")
    rr_class = rr_mod.class_label(row["rr_class"], row["group"])
    result = rr_mod.add_railroad(row["mark"], row["group"], rr_class)
    meanings = acronyms.list_meanings()["railroads"]
    if row["name"] and not meanings.get(row["mark"]):
        acronyms.save_meanings({"railroads": {row["mark"]: row["name"]}})
    return row, result
