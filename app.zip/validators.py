"""Input validation and duplicate detection for train log entries."""
from __future__ import annotations

import re
from datetime import date, datetime, timedelta
from typing import Any, Dict, List, Optional, Tuple

from dateutil import parser as date_parser

from models import (
    DEFAULT_REGION,
    DIRECTION_ALIASES,
    CREW_WORDS,
    NO_CREW_WORDS,
    SIDING_WORDS,
    STOPPED_WORDS,
    DIRECTIONS,
    LEAD_STATUSES,
    LOAD_ALIASES,
    LOAD_STATUSES,
    parse_types_value,
)
from reference import reference_text
from special_power import special_power_storage
from states import normalize_state
from stations import resolve_location_fields, spot_name, station_state, with_milepost
import railroads as rr_mod

DUPLICATE_WINDOW_MINUTES = 1


class ValidationError(ValueError):
    def __init__(self, message: str, field: Optional[str] = None) -> None:
        super().__init__(message)
        self.field = field
        self.message = message

    def to_dict(self) -> Dict[str, str]:
        payload = {"error": self.message}
        if self.field:
            payload["field"] = self.field
        return payload


def _window_text() -> str:
    return "{} minute{}".format(DUPLICATE_WINDOW_MINUTES, "" if DUPLICATE_WINDOW_MINUTES == 1 else "s")


def duplicate_window_message(match_id: Optional[int] = None) -> str:
    if match_id is not None:
        return "Same train/location within {} of entry #{}".format(_window_text(), match_id)
    return "Same train and location logged within {}".format(_window_text())


_CAR_COUNTS_RE = re.compile(r"^\d+(?:\s*/\s*\d+)*$")
_CONSIST_RE = re.compile(r"^\s*\d+(?:\s*[xX×]\s*\d+)*\s*$")
_TIME_24_RE = re.compile(r"^([01]?\d|2[0-3]):([0-5]\d)$")
_TIME_12_RE = re.compile(
    r"^\s*(\d{1,2}):([0-5]\d)\s*(AM|PM|am|pm)?\s*$"
)
_SYMBOL_RE = re.compile(r"^[A-Z0-9-]+$")
TRAIN_NUMBER_MAX = 10


def normalize_symbol(value: Any) -> str:
    """Train symbol: capital letters, digits, and hyphens only."""
    text = str(value or "").strip().upper()
    if not text:
        return ""
    if not _SYMBOL_RE.match(text):
        raise ValidationError("Symbol can only use letters, numbers, and hyphens", "train_symbol")
    return text


def normalize_train_number(value: Any, field: str = "train_number") -> str:
    """Passenger or coal train number: letters, digits, and hyphens, an optional leading # dropped."""
    text = str(value or "").strip().upper().lstrip("#").strip()
    if not text:
        return ""
    if not _SYMBOL_RE.match(text):
        raise ValidationError("Train # can only use letters, numbers, and hyphens", field)
    if len(text) > TRAIN_NUMBER_MAX:
        raise ValidationError("Train # can be at most {} characters".format(TRAIN_NUMBER_MAX), field)
    return text


_COAL_MARK_RE = re.compile(r"^[A-Z]{1,4}$")
_LEAD_STATUS_KEYS = {
    "missed": "Missed",
    "hidden": "Hidden",
    "toodarktosee": "Too dark to see",
    "toodark": "Too dark to see",
    "dark": "Too dark to see",
    "toofar": "Too far",
    "toofaraway": "Too far",
    "far": "Too far",
    "weather": "Weather",
}


def normalize_coal_mark(value: Any) -> str:
    text = re.sub(r"\s+", "", str(value or "")).upper()
    if not text:
        return ""
    if not _COAL_MARK_RE.match(text):
        raise ValidationError("Coal car mark is up to 4 letters, like CEFX", "coal_mark")
    return text


def normalize_lead_status(value: Any) -> str:
    """One or more of Missed, Hidden, Too dark to see, Too far, Weather, stored in that order as "Missed, Hidden"."""
    found = set()
    for part in re.split(r"[,;/&+]|\band\b", str(value or ""), flags=re.I):
        key = re.sub(r"[^a-z]", "", part.lower())
        if not key:
            continue
        status = _LEAD_STATUS_KEYS.get(key)
        if not status:
            raise ValidationError("Lead loco status must be Missed, Hidden, Too dark to see, Too far, or Weather", "lead_status")
        found.add(status)
    return ", ".join(status for status in LEAD_STATUSES if status in found)


def _flag(value: Any) -> bool:
    if isinstance(value, str):
        return value.strip().lower() in ("1", "true", "yes", "on", "y")
    return bool(value)


def normalize_railroad(value: Any) -> str:
    text = str(value or "").strip()
    if not text:
        return ""
    for known in rr_mod.KNOWN_RAILROADS:
        if text.upper() == known:
            return known
    return text


def normalize_loco_number(value: Any) -> str:
    text = str(value or "").strip()
    text = re.sub(r"\s+", " ", text)
    return text


def compose_lead_locomotive(lead: str, loco_mark: str = "", train_railroad: str = "") -> str:
    lead = normalize_loco_number(lead)
    if not lead:
        return ""

    def strip_mark(text: str, mark: str) -> str:
        prefix = mark.upper() + " "
        while text.upper().startswith(prefix):
            text = text[len(prefix):].strip()
        return text

    for known in rr_mod.KNOWN_RAILROADS:
        if lead.upper() == known.upper():
            return known
        if lead.upper().startswith(known.upper() + " "):
            rest = strip_mark(lead, known)
            return "{} {}".format(known, rest) if rest else known
    mark = normalize_railroad(loco_mark) or normalize_railroad(train_railroad)
    if mark:
        if lead.upper() == mark.upper():
            return mark
        rest = strip_mark(lead, mark)
        return "{} {}".format(mark, rest) if rest else mark
    return lead


def normalize_direction(value: Any) -> str:
    text = str(value or "").strip()
    if not text:
        return ""
    mapped = DIRECTION_ALIASES.get(text.upper())
    if mapped:
        return mapped
    return text


def _map_load_token(token: str) -> str:
    text = str(token or "").strip()
    if not text:
        return ""
    mapped = LOAD_ALIASES.get(text.upper())
    if mapped:
        return mapped
    for known in LOAD_STATUSES:
        if text.lower() == known.lower():
            return known
    return ""


def normalize_load_status(value: Any) -> str:
    if isinstance(value, (list, tuple)):
        parts = [str(part) for part in value]
    else:
        text = str(value or "").strip()
        if not text:
            return ""
        parts = re.split(r"[,/&+]|\band\b", text, flags=re.I)
    found = []
    for part in parts:
        mapped = _map_load_token(part)
        if mapped and mapped not in found:
            found.append(mapped)
    return "/".join(status for status in LOAD_STATUSES if status in found)


def normalize_car_counts(value: Any, extra: Any = None) -> str:
    if extra is not None and str(extra).strip() != "":
        left = str(value or "").strip().replace(" ", "")
        right = str(extra).strip().replace(" ", "")
        if left and right:
            return "{}/{}".format(left, right)
        return left or right
    if isinstance(value, (list, tuple)) and len(value) >= 1:
        parts = [str(part).strip().replace(" ", "") for part in value if str(part).strip() != ""]
        return "/".join(parts)
    text = str(value or "").strip().replace(" ", "")
    return text


_TZ_ALIASES = {
    "ET": "America/New_York", "EST": "America/New_York", "EDT": "America/New_York", "EASTERN": "America/New_York",
    "CT": "America/Chicago", "CST": "America/Chicago", "CDT": "America/Chicago", "CENTRAL": "America/Chicago",
    "MT": "America/Denver", "MDT": "America/Denver", "MOUNTAIN": "America/Denver",
    "MST": "America/Phoenix", "AZ": "America/Phoenix", "ARIZONA": "America/Phoenix",
    "PT": "America/Los_Angeles", "PST": "America/Los_Angeles", "PDT": "America/Los_Angeles", "PACIFIC": "America/Los_Angeles",
    "AK": "America/Anchorage", "AKST": "America/Anchorage", "AKDT": "America/Anchorage", "ALASKA": "America/Anchorage",
    "HI": "Pacific/Honolulu", "HST": "Pacific/Honolulu", "HAWAII": "Pacific/Honolulu",
}


def normalize_time_zone(value: Any) -> str:
    text = str(value or "").strip()
    if not text:
        return ""
    alias = _TZ_ALIASES.get(text.upper())
    if alias:
        return alias
    if not re.fullmatch(r"[A-Za-z_]+(?:/[A-Za-z0-9_+\-]+){1,2}", text) or len(text) > 64:
        raise ValidationError("Time zone must be a name like America/Phoenix or a code like PDT", "time_zone")
    return text


def normalize_consist(value: Any) -> str:
    text = str(value or "").strip()
    if not text:
        return ""
    if not _CONSIST_RE.match(text):
        return text
    parts = [int(part) for part in re.split(r"\s*[xX×]\s*", text)]
    if len(parts) == 1:
        return "{}x0".format(parts[0])
    while len(parts) > 3 and parts[-1] == 0:
        parts.pop()
    if len(parts) == 3 and parts[1] == 0:
        parts = [parts[0], parts[2]]
    return "x".join(str(part) for part in parts)


def parse_date(value: Any) -> str:
    if value is None or str(value).strip() == "":
        raise ValidationError("Date is required", "date")
    try:
        parsed = date_parser.parse(str(value), yearfirst=True).date()
        if parsed.year < 100:
            next_year = date.today().year + 1
            century = 2000 if 2000 + parsed.year <= next_year else 1900
            parsed = parsed.replace(year=century + parsed.year)
    except (ValueError, OverflowError, TypeError):
        raise ValidationError("Date must be a valid calendar date", "date")
    if parsed.year < 1900:
        raise ValidationError("Date year looks wrong; use a four-digit year like 2025", "date")
    return parsed.isoformat()


def parse_time_to_24h(value: Any, ampm: Optional[str] = None) -> str:
    if value is None or str(value).strip() == "":
        raise ValidationError("Time is required", "time")
    text = str(value).strip()
    period = (ampm or "").strip().upper()
    match12 = _TIME_12_RE.match(text)
    if match12:
        hour = int(match12.group(1))
        minute = int(match12.group(2))
        found_period = (match12.group(3) or period or "").upper()
        if found_period:
            if hour < 1 or hour > 12:
                raise ValidationError("Hour must be 1–12 with AM/PM", "time")
            if found_period == "AM":
                hour = 0 if hour == 12 else hour
            else:
                hour = hour if hour == 12 else hour + 12
        elif hour > 23:
            raise ValidationError("Time must be HH:MM", "time")
        if minute > 59:
            raise ValidationError("Minutes must be 00–59", "time")
        return "{:02d}:{:02d}".format(hour, minute)
    match24 = _TIME_24_RE.match(text)
    if match24:
        return "{:02d}:{:02d}".format(int(match24.group(1)), int(match24.group(2)))
    raise ValidationError("Time must be HH:MM", "time")


def combine_datetime(date_str: str, time_str: str) -> datetime:
    return datetime.strptime("{} {}".format(date_str, time_str), "%Y-%m-%d %H:%M")


_UID_RE = re.compile(r"[0-9a-f]{32}")


def normalize_uid(value: Any) -> str:
    """A sighting's permanent ID: 32 lowercase hex digits, dashes dropped. Anything else is ignored."""
    text = str(value or "").strip().lower().replace("-", "")
    return text if _UID_RE.fullmatch(text) else ""


def validate_entry(raw: Dict[str, Any], require_all: bool = True) -> Dict[str, Any]:
    """Return a cleaned entry dict or raise ValidationError."""
    railroad = normalize_railroad(raw.get("railroad"))
    if require_all and not railroad:
        raise ValidationError("Railroad is required", "railroad")

    lead_raw = normalize_loco_number(raw.get("lead_locomotive"))
    lead = compose_lead_locomotive(
        lead_raw,
        loco_mark=raw.get("lead_mark") or raw.get("loco_mark") or "",
        train_railroad=railroad,
    ) if lead_raw else ""

    direction = normalize_direction(raw.get("direction"))
    stopped = _flag(raw.get("stopped"))
    in_siding = _flag(raw.get("in_siding"))
    crew_change = _flag(raw.get("crew_change"))
    no_crew = _flag(raw.get("no_crew"))
    if direction.upper() in STOPPED_WORDS:
        direction, stopped = "", True
    elif direction.upper() in SIDING_WORDS:
        direction, in_siding = "", True
    elif direction.upper() in CREW_WORDS:
        direction, crew_change = "", True
    elif direction.upper() in NO_CREW_WORDS:
        direction, no_crew = "", True
    if require_all and not direction and not (stopped or in_siding or crew_change or no_crew):
        raise ValidationError("Direction is required, unless Stopped, In Siding, Crew Change, or No Crew Onboard is on", "direction")
    if direction and direction not in DIRECTIONS:
        raise ValidationError("Direction must be North, South, East, or West", "direction")

    consist = normalize_consist(raw.get("power_consist"))
    if consist and not re.fullmatch(r"\d+(?:x\d+)*", consist):
        raise ValidationError("Consist must be numbers joined by x, like 2x1, 3x0, or 4x2x1", "power_consist")

    types = parse_types_value(raw.get("train_types"))
    if require_all and not types:
        raise ValidationError("At least one train type is required", "train_types")

    load_status = normalize_load_status(
        raw.get("load_status") if raw.get("load_status") not in (None, "") else raw.get("loads_or_empties")
    )

    cars = normalize_car_counts(raw.get("car_counts"), raw.get("car_counts_b"))
    if cars and not _CAR_COUNTS_RE.match(cars):
        raise ValidationError("Car counts must be numeric, like 65 or 105/99", "car_counts")

    location = str(raw.get("location_spot") or "").strip()
    subdivision = str(raw.get("location_subdivision") or "").strip()
    location, subdivision = resolve_location_fields(location, subdivision, railroad)
    if require_all and not location:
        raise ValidationError("Location is required", "location_spot")
    location = with_milepost(location, railroad, subdivision)
    state_raw = raw.get("location_state") if raw.get("location_state") not in (None, "") else raw.get("state")
    state = normalize_state(state_raw)
    if str(state_raw or "").strip() and not state:
        raise ValidationError("State must be a two-letter code like AZ", "location_state")
    if not state and location:
        state = station_state(location, railroad, subdivision)

    date_str = parse_date(raw.get("date")) if (require_all or raw.get("date")) else ""
    if require_all and not date_str:
        raise ValidationError("Date is required", "date")

    time_str = ""
    if require_all or raw.get("time"):
        time_str = parse_time_to_24h(raw.get("time"), raw.get("ampm"))

    region = str(raw.get("location_region") or "").strip() or DEFAULT_REGION
    notes = str(raw.get("notes") or "").strip()
    symbol_raw = raw.get("train_symbol") if raw.get("train_symbol") not in (None, "") else raw.get("symbol")
    symbol = normalize_symbol(symbol_raw)
    train_number = normalize_train_number(raw.get("train_number")) if "PASS" in types else ""
    coal_mark = normalize_coal_mark(raw.get("coal_mark")) if "COAL" in types else ""
    con_on = "CON" in types
    con_overseas = _flag(raw.get("con_overseas")) if con_on else False
    con_domestic = _flag(raw.get("con_domestic")) if con_on else False
    lead_status = normalize_lead_status(raw.get("lead_status"))
    if lead_status and not lead:
        lead = normalize_railroad(raw.get("lead_mark") or raw.get("loco_mark") or "")
    train_info = reference_text(railroad, symbol, train_number)
    if not train_info and (symbol or train_number):
        train_info = re.sub(r"\s+", " ", str(raw.get("train_info") or "")).strip()[:300]
    coords = raw.get("location_coordinates")
    if isinstance(coords, str) and not coords.strip():
        coords = None
    if coords is not None and not isinstance(coords, str):
        import json

        coords = json.dumps(coords)

    photographed = raw.get("photographed")
    videoed = raw.get("videoed")
    if isinstance(photographed, str):
        photographed = photographed.lower() in ("1", "true", "yes", "on")
    if isinstance(videoed, str):
        videoed = videoed.lower() in ("1", "true", "yes", "on")

    trip_name = str(raw.get("trip_name") or raw.get("trip") or "").strip()
    trip_from_raw = raw.get("trip_date_from") or raw.get("trip_from") or ""
    trip_to_raw = raw.get("trip_date_to") or raw.get("trip_to") or ""
    trip_date_from = ""
    trip_date_to = ""
    if str(trip_from_raw).strip():
        try:
            trip_date_from = parse_date(trip_from_raw)
        except ValidationError:
            raise ValidationError("Trip from must be a valid calendar date", "trip_date_from")
    if str(trip_to_raw).strip():
        try:
            trip_date_to = parse_date(trip_to_raw)
        except ValidationError:
            raise ValidationError("Trip to must be a valid calendar date", "trip_date_to")
    if trip_date_from and trip_date_to and trip_date_from > trip_date_to:
        trip_date_from, trip_date_to = trip_date_to, trip_date_from

    time_zone = normalize_time_zone(raw.get("time_zone") or raw.get("timezone") or raw.get("tz"))

    return {
        "date": date_str,
        "time": time_str,
        "time_zone": time_zone,
        "railroad": railroad,
        "lead_locomotive": lead,
        "direction": direction,
        "power_consist": consist,
        "train_types": types,
        "load_status": load_status,
        "car_counts": cars,
        "location_spot": location,
        "location_subdivision": subdivision,
        "location_state": state,
        "location_region": region,
        "location_coordinates": coords,
        "notes": notes,
        "train_symbol": symbol,
        "train_number": train_number,
        "train_info": train_info,
        "special_power": special_power_storage(raw.get("special_power")),
        "photographed": bool(photographed),
        "videoed": bool(videoed),
        "trip_name": trip_name,
        "trip_date_from": trip_date_from,
        "trip_date_to": trip_date_to,
        "lead_status": lead_status,
        "night": _flag(raw.get("night")),
        "stopped": stopped,
        "in_siding": in_siding,
        "crew_change": crew_change,
        "no_crew": no_crew,
        "coal_mark": coal_mark,
        "con_overseas": con_overseas,
        "con_domestic": con_domestic,
        "special_power": special_power_storage(raw.get("special_power")),
        "photographed": bool(photographed),
        "videoed": bool(videoed),
        "trip_name": trip_name,
        "trip_date_from": trip_date_from,
        "trip_date_to": trip_date_to,
        "uid": normalize_uid(raw.get("uid")),
        "force": bool(raw.get("force")),
        "row": raw.get("row"),
    }


def is_within_window(
    left: datetime, right: datetime, minutes: int = DUPLICATE_WINDOW_MINUTES
) -> bool:
    delta = abs(left - right)
    return delta <= timedelta(minutes=minutes)


def duplicate_key(entry: Dict[str, Any]) -> Tuple[str, str, str]:
    return (
        (entry.get("railroad") or "").upper(),
        (entry.get("lead_locomotive") or "").upper(),
        spot_name(entry.get("location_spot") or "").upper(),
    )


def same_train_location(a: Dict[str, Any], b: Dict[str, Any]) -> bool:
    return duplicate_key(a) == duplicate_key(b)


_EXACT_FIELDS = (
    "date", "time", "direction", "power_consist", "load_status", "car_counts",
    "location_subdivision", "notes", "train_symbol", "train_number",
)


def exact_duplicate(a: Dict[str, Any], b: Dict[str, Any]) -> bool:
    if not same_train_location(a, b):
        return False
    for field in _EXACT_FIELDS:
        if str(a.get(field) or "").strip().lower() != str(b.get(field) or "").strip().lower():
            return False
    types_a = sorted(str(t).upper() for t in (a.get("train_types") or []))
    types_b = sorted(str(t).upper() for t in (b.get("train_types") or []))
    return types_a == types_b
