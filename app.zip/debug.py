"""Error log and debug report for TRAIN LOG."""
from __future__ import annotations

import json
import os
import platform
import sys
import threading
import traceback
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional

from paths import resource_root, support_dir
from version import APP_VERSION

_MAX_LOG_BYTES = 512 * 1024
_lock = threading.Lock()


def debug_log_path() -> Path:
    return support_dir() / "debug-log.jsonl"


def _now() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def record(kind: str, message: str, detail: Optional[Dict[str, Any]] = None) -> None:
    line = json.dumps(
        {"at": _now(), "kind": kind, "message": str(message)[:2000], "detail": detail or {}},
        default=str,
    )
    path = debug_log_path()
    with _lock:
        try:
            if path.is_file() and path.stat().st_size > _MAX_LOG_BYTES:
                keep = path.read_text(encoding="utf-8", errors="replace").splitlines()[-400:]
                path.write_text("\n".join(keep) + "\n", encoding="utf-8")
            with path.open("a", encoding="utf-8") as handle:
                handle.write(line + "\n")
        except OSError:
            pass


def record_exception(where: str, exc: BaseException) -> None:
    record(
        "server.error",
        "{}: {}".format(type(exc).__name__, exc),
        {"where": where, "traceback": "".join(traceback.format_exception(type(exc), exc, exc.__traceback__))[-6000:]},
    )


def recent(limit: int = 200) -> List[Dict[str, Any]]:
    path = debug_log_path()
    if not path.is_file():
        return []
    items = []
    with _lock:
        lines = path.read_text(encoding="utf-8", errors="replace").splitlines()[-limit:]
    for line in lines:
        try:
            items.append(json.loads(line))
        except json.JSONDecodeError:
            continue
    items.reverse()
    return items


def clear() -> None:
    with _lock:
        try:
            debug_log_path().unlink()
        except FileNotFoundError:
            pass


def _tail(path: Path, lines: int = 200) -> List[str]:
    if not path.is_file():
        return []
    try:
        return path.read_text(encoding="utf-8", errors="replace").splitlines()[-lines:]
    except OSError as exc:
        return ["(could not read: {})".format(exc)]


def _listing(folder: Path) -> List[Dict[str, Any]]:
    if not folder.is_dir():
        return []
    out = []
    for path in sorted(folder.iterdir()):
        try:
            stat = path.stat()
        except OSError:
            continue
        out.append(
            {
                "name": path.name + ("/" if path.is_dir() else ""),
                "bytes": stat.st_size if path.is_file() else None,
                "modified": datetime.fromtimestamp(stat.st_mtime, timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
            }
        )
    return out


def _safe(fn, fallback=None):
    try:
        return fn()
    except Exception as exc:  # the report must never fail because one section did
        return {"error": "{}: {}".format(type(exc).__name__, exc)} if fallback is None else fallback


def build_report(db, client: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    from stations import catalog_items, hidden_filenames, inbound_status, user_subdivisions_dir

    def station_book():
        items = catalog_items()
        by_source: Dict[str, int] = {}
        for item in items:
            by_source[item["source"]] = by_source.get(item["source"], 0) + 1
        return {
            "files": len(items),
            "locations": sum(item["locations"] for item in items),
            "by_source": by_source,
            "added_or_edited": [
                {"file": item["filename"], "source": item["source"], "locations": item["locations"]}
                for item in items
                if item["source"] in ("user", "edited")
            ],
            "hidden": sorted(hidden_filenames()),
        }

    def recent_activity():
        rows = db.list_activity(40)
        slim = []
        for row in rows:
            row = dict(row)
            detail = row.get("detail")
            if isinstance(detail, (dict, list)) and len(json.dumps(detail, default=str)) > 800:
                row["detail"] = "(trimmed)"
            slim.append(row)
        return slim

    support = support_dir()
    return {
        "report": "TRAIN LOG debug report",
        "generated_at": _now(),
        "app": {
            "version": APP_VERSION,
            "packaged": bool(getattr(sys, "frozen", False)),
            "resource_root": str(resource_root()),
        },
        "system": {
            "macos": platform.mac_ver()[0] or platform.platform(),
            "machine": platform.machine(),
            "python": sys.version.split()[0],
            "executable": sys.executable,
        },
        "paths": {
            "support_dir": str(support),
            "subdivisions_dir": str(_safe(user_subdivisions_dir, "")),
            "env_overrides": {k: v for k, v in os.environ.items() if k.startswith("TRAINS_")},
        },
        "database": _safe(db.info),
        "station_book": _safe(station_book),
        "watch_folder": _safe(inbound_status),
        "support_files": _safe(lambda: _listing(support), []),
        "errors": _safe(lambda: recent(200), []),
        "recent_activity": _safe(recent_activity, []),
        "desktop_log_tail": _safe(lambda: _tail(support / "desktop.log", 200), []),
        "client": client or {},
    }
