"""Project folder, or the PyInstaller bundle, where static files live."""
from __future__ import annotations

import json
import os
import sys
from pathlib import Path
from typing import Any


def resource_root() -> Path:
    if getattr(sys, "frozen", False):
        meipass = getattr(sys, "_MEIPASS", None)
        if meipass:
            return Path(meipass)
        return Path(sys.executable).resolve().parent.parent / "Resources"
    return Path(__file__).resolve().parent


def shipped_path(folder: str, name: str) -> Path:
    """A default list built into the app. scripts/prepare_release.py writes this Mac's edits here before a build."""
    return resource_root() / "assets" / folder / name


def shipped_json(folder: str, name: str) -> Any:
    try:
        return json.loads(shipped_path(folder, name).read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return None


def support_dir() -> Path:
    override = os.environ.get("TRAINS_SUPPORT_DIR")
    if override:
        path = Path(override).expanduser()
    else:
        path = Path.home() / "Library" / "Application Support" / "RailroadTrainLog"
    path.mkdir(parents=True, exist_ok=True)
    return path
