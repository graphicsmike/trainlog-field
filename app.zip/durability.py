"""Offline durability helpers: disk pressure, integrity, scheduled log snapshots."""
from __future__ import annotations

import json
import time
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional

from paths import support_dir


SNAPSHOT_KEEP_DEFAULT = 5
SNAPSHOT_KEEP_MIN = 3
SNAPSHOT_KEEP_MAX = 12
# Soft nag when clips/snapshots/watch folders pass this many bytes.
DISK_SOFT_BYTES = 500 * 1024 * 1024
# Auto-write a Mac snapshot when the newest is older than this.
SNAPSHOT_STALE_SECONDS = 24 * 60 * 60


def _dir_bytes(path: Path) -> int:
    if not path.exists():
        return 0
    total = 0
    if path.is_file():
        try:
            return int(path.stat().st_size)
        except OSError:
            return 0
    for child in path.rglob("*"):
        if child.is_file():
            try:
                total += int(child.stat().st_size)
            except OSError:
                pass
    return total


def _settings_path() -> Path:
    return support_dir() / "durability.json"


def load_settings() -> Dict[str, Any]:
    path = _settings_path()
    defaults = {
        "snapshot_keep": SNAPSHOT_KEEP_DEFAULT,
        "snapshot_auto": True,
        "last_snapshot_nag": "",
        "disk_banner_dismissed_at": "",
        "disk_banner_dismissed_bytes": 0,
    }
    if not path.is_file():
        return dict(defaults)
    try:
        raw = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return dict(defaults)
    if not isinstance(raw, dict):
        return dict(defaults)
    out = dict(defaults)
    out.update({k: raw[k] for k in defaults if k in raw})
    keep = int(out.get("snapshot_keep") or SNAPSHOT_KEEP_DEFAULT)
    out["snapshot_keep"] = max(SNAPSHOT_KEEP_MIN, min(SNAPSHOT_KEEP_MAX, keep))
    out["snapshot_auto"] = bool(out.get("snapshot_auto", True))
    return out


def save_settings(patch: Dict[str, Any]) -> Dict[str, Any]:
    current = load_settings()
    if "snapshot_keep" in patch:
        try:
            keep = int(patch["snapshot_keep"])
        except (TypeError, ValueError):
            keep = SNAPSHOT_KEEP_DEFAULT
        current["snapshot_keep"] = max(SNAPSHOT_KEEP_MIN, min(SNAPSHOT_KEEP_MAX, keep))
    if "snapshot_auto" in patch:
        current["snapshot_auto"] = bool(patch["snapshot_auto"])
    if "last_snapshot_nag" in patch:
        current["last_snapshot_nag"] = str(patch.get("last_snapshot_nag") or "")
    if "disk_banner_dismissed_at" in patch:
        current["disk_banner_dismissed_at"] = str(patch.get("disk_banner_dismissed_at") or "")
    if "disk_banner_dismissed_bytes" in patch:
        try:
            current["disk_banner_dismissed_bytes"] = int(patch.get("disk_banner_dismissed_bytes") or 0)
        except (TypeError, ValueError):
            current["disk_banner_dismissed_bytes"] = 0
    path = _settings_path()
    path.write_text(json.dumps(current, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    return current


def prune_log_snapshots(keep: Optional[int] = None) -> int:
    """Delete oldest log-*.json beyond keep. Returns how many were removed."""
    from paths import support_dir as _support

    limit = keep if keep is not None else load_settings()["snapshot_keep"]
    limit = max(SNAPSHOT_KEEP_MIN, min(SNAPSHOT_KEEP_MAX, int(limit)))
    folder = _support() / "log-snapshots"
    if not folder.is_dir():
        return 0
    older = sorted(folder.glob("log-*.json"))
    removed = 0
    for stale in older[:-limit] if limit else older:
        try:
            stale.unlink()
            removed += 1
        except OSError:
            pass
    return removed


def storage_report(db_path: Optional[Path] = None) -> Dict[str, Any]:
    """Sizes for soft disk-pressure banners. Clips live in the browser; client adds those."""
    from stations import inbound_dir

    base = support_dir()
    snapshots = base / "log-snapshots"
    watch = inbound_dir()
    parts = {
        "snapshots": _dir_bytes(snapshots),
        "watch": _dir_bytes(watch),
        "support_other": 0,
    }
    db_bytes = 0
    if db_path and Path(db_path).is_file():
        try:
            db_bytes = int(Path(db_path).stat().st_size)
        except OSError:
            db_bytes = 0
    parts["database"] = db_bytes
    # Count other support files lightly (exclude the big named folders above).
    skip = {snapshots.resolve(), watch.resolve()}
    other = 0
    if base.is_dir():
        for child in base.iterdir():
            try:
                resolved = child.resolve()
            except OSError:
                continue
            if resolved in skip:
                continue
            if child.name.endswith(".db") or child.name.endswith(".db-wal") or child.name.endswith(".db-shm"):
                continue
            other += _dir_bytes(child)
    parts["support_other"] = other
    total = sum(parts.values())
    settings = load_settings()
    return {
        "parts": parts,
        "total_bytes": total,
        "soft_limit_bytes": DISK_SOFT_BYTES,
        "over_soft": total >= DISK_SOFT_BYTES,
        "snapshots_path": str(snapshots),
        "watch_path": str(watch),
        "settings": settings,
    }


def integrity_report(db: Any) -> Dict[str, Any]:
    """Lightweight open checks: trip windows vs sightings, upgrade backup note, empty menus."""
    from version import APP_VERSION

    notes: List[Dict[str, str]] = []
    trips_bad: List[Dict[str, Any]] = []

    try:
        entries = db.list_entries()
    except Exception as exc:  # noqa: BLE001 — surface as a note, don't crash open
        return {
            "ok": False,
            "notes": [{"kind": "error", "text": "Could not read the log for integrity checks: {}.".format(exc)}],
            "trips": [],
            "app_version": APP_VERSION,
        }

    # Trip date window vs sighting dates on that trip.
    by_trip: Dict[str, List[Any]] = {}
    for entry in entries:
        name = (entry.trip_name or "").strip()
        if not name:
            continue
        by_trip.setdefault(name, []).append(entry)

    for name, rows in sorted(by_trip.items()):
        dates = sorted(r.date for r in rows if r.date)
        if not dates:
            continue
        # Trip window lives on the sightings (shared trip_date_from / trip_date_to).
        win_from = ""
        win_to = ""
        for row in rows:
            win_from = win_from or (row.trip_date_from or "").strip()
            win_to = win_to or (row.trip_date_to or "").strip()
        if not win_from and not win_to:
            continue
        lo = min(dates)
        hi = max(dates)
        problems = []
        if win_from and lo < win_from:
            problems.append("earliest sighting {} is before trip start {}".format(lo, win_from))
        if win_to and hi > win_to:
            problems.append("latest sighting {} is after trip end {}".format(hi, win_to))
        if problems:
            trips_bad.append({"trip": name, "from": win_from, "to": win_to, "sighting_from": lo, "sighting_to": hi, "problems": problems})
            notes.append({"kind": "trip", "text": "Trip “{}”: {}.".format(name, "; ".join(problems))})

    # Schema / upgrade backup note.
    upgrade = getattr(db, "upgrade_backup", None)
    if upgrade:
        notes.append({
            "kind": "migrate",
            "text": "A copy of the log was saved before opening with TRAIN LOG {} ({}).".format(APP_VERSION, upgrade),
        })
    try:
        meta_ver = None
        with db._lock:
            row = db._conn.execute("SELECT value FROM app_meta WHERE key = 'app_version'").fetchone()
            meta_ver = row["value"] if row else None
        if meta_ver and meta_ver != APP_VERSION:
            notes.append({
                "kind": "migrate",
                "text": "Log last stamped with app {} · running {}.".format(meta_ver, APP_VERSION),
            })
    except Exception:  # noqa: BLE001
        pass

    # Cold-start menu presence (railroads / stations shipped).
    try:
        from railroads import grouped_railroads

        roads = grouped_railroads()
        count = 0
        if isinstance(roads, dict):
            for group in roads.get("groups") or []:
                if isinstance(group, dict):
                    count += len(group.get("railroads") or [])
        if count == 0:
            notes.append({"kind": "cold", "text": "Railroad menu is empty — reinstall or restore shipped railroads."})
    except Exception:  # noqa: BLE001
        notes.append({"kind": "cold", "text": "Could not read the railroad menu for a cold-start check."})

    try:
        from stations import list_subdivisions

        subs = list_subdivisions() or []
        if not subs:
            notes.append({"kind": "cold", "text": "Station book has no subdivisions — field pad places will be blank offline."})
    except Exception:  # noqa: BLE001
        pass

    return {
        "ok": not any(n.get("kind") == "error" for n in notes),
        "notes": notes,
        "trips": trips_bad,
        "entry_count": len(entries),
        "app_version": APP_VERSION,
        "checked_at": datetime.now().strftime("%Y-%m-%d %H:%M"),
    }


def dismiss_disk_banner(bytes_now: int = 0) -> Dict[str, Any]:
    return save_settings({
        "disk_banner_dismissed_at": datetime.now().strftime("%Y-%m-%dT%H:%M:%S"),
        "disk_banner_dismissed_bytes": int(bytes_now or 0),
    })


def snapshot_status(db: Any) -> Dict[str, Any]:
    settings = load_settings()
    snaps = db.log_snapshots() if hasattr(db, "log_snapshots") else []
    newest = snaps[0] if snaps else None
    age = None
    stale = True
    if newest and newest.get("saved"):
        try:
            when = datetime.strptime(newest["saved"], "%Y-%m-%d %H:%M")
            age = max(0, int(time.time() - when.timestamp()))
            stale = age >= SNAPSHOT_STALE_SECONDS
        except ValueError:
            stale = True
    return {
        "settings": settings,
        "snapshots": snaps,
        "newest": newest,
        "age_seconds": age,
        "stale": stale,
        "stale_after_seconds": SNAPSHOT_STALE_SECONDS,
        "keep": settings["snapshot_keep"],
        "auto": settings["snapshot_auto"],
    }


def maybe_auto_snapshot(db: Any) -> Optional[str]:
    """Write a snapshot when auto is on and the newest is stale (or missing)."""
    status = snapshot_status(db)
    if not status["auto"]:
        return None
    if not status["stale"]:
        return None
    # Don't snapshot an empty log.
    try:
        if not db.export_rows():
            return None
    except Exception:  # noqa: BLE001
        return None
    name = db.write_log_snapshot()
    prune_log_snapshots(status["keep"])
    return name or None
